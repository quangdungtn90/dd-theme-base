<?php

/**
 * Include function files
 */
define( 'TP_BASE_TOOLKIT_VER', '1.0' );
define( 'TP_BASE_TOOLKIT_URL', plugin_dir_url( __FILE__ ) );
define( 'TP_BASE_TOOLKIT_DIR', plugin_dir_path( __FILE__ ) );

include TP_BASE_TOOLKIT_DIR . 'includes/sanitize.php';
include TP_BASE_TOOLKIT_DIR . 'includes/helpers.php';

/**
 * Make TP_Base\\Toolkit\\Toolkit as TP_Base_Toolkit alias.
 */
class_alias( 'TP_Base\\Toolkit\\Toolkit', 'TP_Base_Toolkit' );

