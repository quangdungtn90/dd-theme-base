<?php
/**
 * Plugin Name: TP Base Toolkit
 * Description: An extension plugin for TP Base theme to provide features, including post types, widgets, megamenu, visual composer add-on, extended customizer.
 * Version: 2.0
 * Author: ThemesPond
 * Author URI: https://www.themespond.com/
 * License: GNU General Public License v3 or later
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * Requires at least: 4.5
 * Tested up to: 4.8
 * Text Domain: tp-base-toolkit
 * Domain Path: /languages/
 *
 * @package TP_Base
 */

/**
 * First, we need autoload via Composer to make everything works.
 */
require trailingslashit( __DIR__ ) . '/vendor/autoload.php';

/**
 * Next, load the bootstrap file.
 */
require trailingslashit( __DIR__ ) . '/bootstrap.php';

/**
 * Init Toolkit
 */
$GLOBALS['tp_base_toolkit'] = new TP_Base_Toolkit();


function tp_base_toolkit( $make = null ) {

	if ( is_null( $make ) ) {
		return TP_Base_Toolkit::get_instance();
	}

	return TP_Base_Toolkit::get_instance()->factory( $make );
}
