<div class="tp_posts">

	<div class="row">
		<?php
		if ( $query->have_posts() ):
			while ( $query->have_posts() ):
				$query->the_post();
				?>
				<div class="col-md-4">


					<?php if ( ( get_the_post_thumbnail() != '' ) || ( (!empty( $display[0] ) ) && ( $display[0] == 'show_thumb' ) ) ): ?>
						<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'thumbnail' ); ?></a>
					<?php endif; ?>

					<?php printf( '<h4 class="tp_posts__title"><a href="%1$s" title="%2$s" class="post-title">%2$s</a></h4>', get_the_permalink(), get_the_title() ); ?>

					<div class="tp_posts__meta">
						<span class="post-date"><?php echo esc_html( get_the_date() ) ?></span>
						<span class="post-comment"><?php echo esc_html( get_comments_number() ); ?></span>
					</div>
						
					<div class="tp_posts__summary">
						<?php echo wp_trim_words( get_the_excerpt(), 20, '...' ) ?>
					</div>
				</div>
				<?php
			endwhile;
			wp_reset_postdata();
		endif;
		?>
	</div>
</div>