<?php
$mapReponsive = empty( $height ) ? 'map--reponsive' : '';
?>
<div class="map <?php echo esc_attr( $mapReponsive ) ?>">

	<?php if ( $title ): ?>
        <h2 class="map__title"><?php echo esc_html( $title ) ?></h2>
	<?php endif; ?>

    <div id="<?php echo uniqid( 'map-' ) ?>" class="map__canvas" <?php echo implode( ' ', $data ) ?>></div>
</div>