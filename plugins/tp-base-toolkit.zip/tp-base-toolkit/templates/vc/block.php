<div class="tp_base__block">
	<h2><?php echo esc_html( $title) ?></h2>
	<p><?php echo esc_html( $description) ?></p>
	<?php echo wp_get_attachment_image( $image) ?>
</div>