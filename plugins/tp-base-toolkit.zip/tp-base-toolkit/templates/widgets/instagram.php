<?php
/**
 * Instagram template
 * 
 * @author      ThemesPond
 * @package		TP_Base
 * @subpackage  TP_Base\Toolkit
 * @since       1.0
 */
?>
<ul>
	<?php foreach ( $feeds as $feed ): ?>
		<li>
			<a href="<?php echo esc_url( $feed->images->standard_resolution->url ); ?>" data-rel="prettyPhoto[pp_gal]"> 
				<img src="<?php echo esc_url( $feed->images->thumbnail->url ); ?>" alt='<?php echo!empty( $feed->caption->text ) ? esc_html( $feed->caption->text ) : ''; ?>'>
			</a>
		</li>
	<?php endforeach; ?>
</ul>
