<?php
/**
 * Template for Widget Posts - Style standard
 *
 * @author      ThemesPond
 * @package        TP_Base
 * @subpackage  TP_Base\Toolkit
 * @since       1.0
 */
?>

<ul>
	<?php
	$display = explode( ",", $display );
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			?>
			<li>
				<?php if ( ( get_the_post_thumbnail() != '' ) || ( (!empty( $display[0] ) ) && ( $display[0] == 'show_thumb' ) ) ): ?>
					<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'thumbnail' ); ?></a>
				<?php endif; ?>
				<div class="post-box">
					<div class="meta-post">
						<span class="post-date"><?php echo esc_html( get_the_date() ) ?></span>
						<span class="post-comment"><?php echo esc_html( get_comments_number() ); ?></span>
					</div>
					<?php printf( '<a href="%1$s" title="%2$s" class="post-title">%2$s</a>', get_the_permalink(), get_the_title() ); ?>
				</div>
			</li>
			<?php
		}
		wp_reset_postdata();
	}
	?>
</ul>