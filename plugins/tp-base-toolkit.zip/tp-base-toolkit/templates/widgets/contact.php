<?php
/**
 * Template for Contact widget
 * 
 * @author      ThemesPond
 * @package		TP_Base
 * @subpackage  TP_Base\Toolkit
 * @since       1.0
 */
?>


<div class="widget-content">
	<div class="logo">
		<?php echo wp_get_attachment_image( $image, 'full' ); ?>
	</div>
	<ul>
		<?php if ( !empty( $address ) ): ?>
	        <li>
	            <span>
					<?php echo esc_html( $address ); ?>
	            </span>
	        </li>
		<?php endif; ?>
		<?php if ( !empty( $phone ) ): ?>
	        <li>
	            <a href="tel:<?php echo tp_base_toolkit_sanitize_phone_number( $phone ); ?>">
					<?php echo esc_html( $phone ); ?>
	            </a>
	        </li>
		<?php endif; ?>
		<?php if ( !empty( $email ) ): ?>
	        <li>
	            <a href="mailto:<?php echo esc_attr( $email ); ?>">
					<?php echo esc_html( $email ); ?>
	            </a>
	        </li>
		<?php endif; ?>
	</ul>
</div>