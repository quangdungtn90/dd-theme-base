<div class="event__list-date text-center">
    <div class="event-day__start"><?php echo esc_html( $date_starts->format( 'd' ) ) ?></div>
    <div class="event-month__start"><?php echo esc_html( $date_starts->format( 'F' ) ) ?></div>
</div>

