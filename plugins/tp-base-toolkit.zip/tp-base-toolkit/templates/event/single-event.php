<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package TP_Base
 * @since 1.0
 */
get_header();


/**
 * @hooked: tp_base_breadcrumb - 5
 * @hooked: tp_base_before_main_content - 10
 */
do_action( 'tp_base\before_main_content' );
?>

    <div class="content-area">
        <main id="main" class="site-main">

			<?php
			global $wp_query;
			/* Start the Loop */
			while ( have_posts() ) : the_post();

				tp_base_toolkit_template( 'event/content-single-event' );

				tp_base_toolkit_event_single_related();

			endwhile; // End of the loop.
			?>

        </main><!-- #main -->
    </div><!-- .content-area -->

<?php
/**
 * @hooked: tp_base_after_main_content - 15
 */
do_action( 'tp_base\after_main_content' );

get_footer();
