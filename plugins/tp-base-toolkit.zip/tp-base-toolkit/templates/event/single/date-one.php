<?php

if (strtotime($date_end->format('d-m-Y')) - strtotime($date_start->format('d-m-Y')) == 0){
	$inday = true;
}else{
	$inday = false;
}
?>
<?php if ($inday):?>
    <div class="event-date">
        <div class="event-date__summary">

            <span class="event-date"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo esc_html( $date_start->format('M d, Y')) ?></span> <?php echo esc_html__('at','tp-base-toolkit')?>
            <span class="event-time"><i class="fa fa-clock-o"></i> <span><?php echo esc_html( $date_start->format('H:i A') ) ?></span><span> - <?php echo esc_html( $date_end->format('H:i A') ) ?></span></span>
        </div>

    </div>
<?php else:?>
    <div class="event-date">
        <div class="event-date__summary">
            <i class="fa fa-clock-o"></i>
            <span class="event-start"><?php echo esc_html( $date_start->format('M d')) ?></span> <?php echo esc_html('at','tp-base-toolkit')?> <?php echo esc_html( $date_start->format('H:i A') )?> <?php echo esc_html__('to','tp-base-toolkit')?>

            <span class="event-end"><?php echo esc_html( $date_end->format('M d')) ?></span> <?php echo esc_html('at','tp-base-toolkit')?> <?php echo esc_html( $date_end->format('H:i A') )?>
        </div>

    </div>

<?php endif;?>