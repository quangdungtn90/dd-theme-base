<?php
/**
 * Template part for displaying related event
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package TP_Base
 * @since 1.0
 */
$related_args = tp_base_toolkit_event_related_args();
$query = new WP_Query( $related_args );

if ( $query->have_posts() ):
	?>

	<div class="releated_posts">

		<h3 class="releated_posts__title"><?php echo esc_html__( 'Maybe you are interested', 'tp-base' ) ?></h3>

		<div class="row">
			<?php while ( $query->have_posts() ): $query->the_post(); ?>
				<div class="col-md-6 col-sm-6 margin-element">
					<div <?php post_class() ?>>

						<?php if ( '' !== get_the_post_thumbnail() ): ?>
							<div class="post-thumbnail">
								<a href="<?php the_permalink() ?>">
									<?php the_post_thumbnail( 'tp-base-related-post' ) ?>
								</a>
							</div>
						<?php endif; ?>

						<div class="entry-header"><h3 class="entry-title"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h3></div>
					</div>
				</div>
			<?php endwhile; ?>
		</div>

	</div>

	<?php
	wp_reset_postdata();
endif;

