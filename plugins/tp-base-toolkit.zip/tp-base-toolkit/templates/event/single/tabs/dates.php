<?php

global $tp_base_event;

$frequency = $tp_base_event->get_frequency();

switch ( $frequency ) {
	case 'daily':
		$tp_base_event->output_date_daily();
		break;
	case 'weekly':
		$tp_base_event->output_date_weekly();
		break;
	case 'custom':
		$tp_base_event->output_date_custom();
		break;
	default:
		$tp_base_event->output_date_one();
		break;
}