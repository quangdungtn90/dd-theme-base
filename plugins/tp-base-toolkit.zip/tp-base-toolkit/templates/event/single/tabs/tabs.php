<?php
/**
 * Single Room type tabs
 *
 * his template can be overridden by copying it to yourtheme/template-parts/toolkit/event/single/tabs/tabs.php.
 *
 * @author  ThemesPond
 * @package TP_Base\Templates
 * @version 1.0
 */

/**
 * Filter tabs and allow third parties to add their own.
 *
 * Each tab is an array containing title, callback and priority.
 * @see tp_base_toolkit_get_event_single_tabs()
 */
$tabs = apply_filters( 'tp_base\toolkit\event_single_tabs', array() );

if ( ! empty( $tabs ) ) : ?>

	<div class="event-tab">
		<ul class="event-tab__controls">
			<?php foreach ( $tabs as $key => $tab ) : ?>
				<li class="<?php echo esc_attr( $key ); ?>_tab" id="tab-title-<?php echo esc_attr( $key ); ?>" role="tab" aria-controls="tab-<?php echo esc_attr( $key ); ?>">
					<a href="#tab-<?php echo esc_attr( $key ); ?>"><?php echo apply_filters( 'event_room_type_' . $key . '_tab_title', esc_html( $tab['title'] ), $key ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>

		<div class="event-tab__wrapper">
			<?php foreach ( $tabs as $key => $tab ) : ?>
				<div class="event-tab__content entry-content wc-tab" id="tab-<?php echo esc_attr( $key ); ?>" role="tabpanel" aria-labelledby="tab-title-<?php echo esc_attr( $key ); ?>">
					<?php call_user_func( $tab['callback'], $key, $tab ); ?>
				</div>
			<?php endforeach; ?>
		</div>
	</div>

<?php endif; ?>
