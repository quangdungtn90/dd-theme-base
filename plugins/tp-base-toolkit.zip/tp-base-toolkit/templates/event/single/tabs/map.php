<?php
global $tp_base_event;
$map = $tp_base_event->get_map();
?>
<div id="event-map" class="event-map"
     data-address="<?php echo esc_attr( $tp_base_event->get_location() ) ?>"
     data-lat="<?php echo esc_attr( $map['lat'] ) ?>"
     data-lng="<?php echo esc_attr( $map['lng'] ) ?>"
     data-zoom="<?php echo esc_attr( $map['zoom'] ) ?>">
    <div class="map_canvas"></div>
</div>