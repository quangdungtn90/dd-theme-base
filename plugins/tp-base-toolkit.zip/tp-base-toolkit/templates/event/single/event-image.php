<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $post, $tp_base_event;

$attachment_ids = $tp_base_event->get_image_ids();

?>
<div class="event__media">

<?php
if ( !empty( $attachment_ids ) ) :?>


    <div id="event-slider">
        <div class="slides event-slider-single">
			<?php
			foreach ( $attachment_ids as $attachment_id ) {
				echo '<div class="image">';
				echo wp_get_attachment_image( $attachment_id, 'tp-base-event-single' );
				echo '</div>';
			}
			?>
        </div>
    </div>

<?php else:?>
    <div class="event-room-type__image">
		<?php if (has_post_thumbnail()):?>
			<?php the_post_thumbnail('full');?>
		<?php else:?>
            <img src="<?php echo esc_url( tp_base_toolkit_event_placeholder_img_src() ) ?>" alt="<?php echo esc_html__( 'Awaiting event image', 'tp-base-toolkit' ) ?>" class="wp-post-image" />
		<?php endif;?>
    </div>
<?php endif;?>

<?php do_action( 'tp_base\toolkit\event_single_thumbnails' );?>
</div>
