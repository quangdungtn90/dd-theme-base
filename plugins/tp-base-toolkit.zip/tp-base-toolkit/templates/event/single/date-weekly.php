<div class="event-date event-date--weekly">

	<?php if ( $items ): ?>

        <div class="event-date__list">
			<?php foreach ( $items as $date ): ?>
                <div class="event-date__item">

                    <span class="item-date" title="<?php echo esc_attr( $date->format( 'l, F m' ) ) ?>">
                        <div class="item-weekday"><?php echo esc_html( $date->format( 'D' ) ) ?></div>
                        <div class="item-day"><?php echo esc_html( $date->format( 'j' ) ) ?></div>
                    </span>

                    <div class="item-time">
	                    <?php echo esc_attr( $date->format( 'l, F jS, Y' ) ) ?>
	                    <?php echo esc_html__('at','tp-base-toolkit')?>
                        <span><?php echo esc_html( $time_start->format( 'H:i A' ) ) ?></span>
                        <span>- <?php echo esc_html( $time_end->format( 'H:i A' ) ) ?></span>
                    </div>

                </div>
			<?php endforeach; ?>
        </div>

	<?php endif; ?>

</div>