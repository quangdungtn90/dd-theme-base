<div class="event-date event-date--custom">
    <div class="event-date__summary">

        <i class="fa fa-clock-o"></i>

		<?php if ( $day_number == 0 ): ?>
            <span class="event-date__end">
                <?php echo esc_html( $date_ends->format( 'M d, Y' ) ) ?>
            </span>
		<?php else: ?>
            <span class="event-date__start">
            <?php
            if ( $year_number == 0 ) {
	            echo esc_html( $date_starts->format( 'M d' ) );
            } else {
	            echo esc_html( $date_starts->format( 'M d, Y' ) );
            }
            ?>
        </span> -
            <span class="event-date__end">
            <?php echo esc_html( $date_ends->format( 'M d, Y' ) ) ?>
        </span>
		<?php endif; ?>


    </div>
</div>