<div class="event-date event-date-weekly">

    <div class="event-date__summary">
        <i class="fa fa-clock-o"></i>
        <span class="event-date__frequency">
		<?php

		if ( isset( $day ) ) {
			printf( esc_html__( 'Every %s', 'tp-base-toolkit' ), $day->format( 'l' ) );
		}

		?>
	</span>,
        <span class="event-date__start">
            <?php

            $format = $year_number == 0 ? 'M d' : 'M d, Y';
            echo esc_html( $date_starts->format( $format ) );
            ?>
        </span> -
        <span class="event-date__end"><?php echo esc_html( $date_ends->format( 'M d, Y' ) ) ?></span>
    </div>
</div>