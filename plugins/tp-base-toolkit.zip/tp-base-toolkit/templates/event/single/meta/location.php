<div class="event--address">
    <div class="title"><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo esc_html( $location ) ?> </div>
</div>