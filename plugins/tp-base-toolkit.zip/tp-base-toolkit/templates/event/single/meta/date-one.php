<div class="event-date event-date--one">

    <div class="event-date__summary">
        <i class="fa fa-clock-o"></i>

        <?php if (is_single()):?>
            <span class="event-date__start">
            <?php

            $format = $year_number == 0 ? 'M d' : 'M d, Y';
            printf( esc_html__( '%s at %s', 'tp-base-toolkit' ), $date_starts->format( $format ), $date_starts->format( 'H:i A' ) );
            ?>
        </span>
	        <?php echo esc_html__( 'to', 'tp-base-toolkit' ) ?>
            <span class="event-date__end">
            <?php printf( esc_html__( '%s at %s', 'tp-base-toolkit' ), $date_ends->format( 'M d, Y' ), esc_html( $date_ends->format( 'H:i A' ) ) ); ?>
        </span>
        <?php else:?>
            <span class="event-date__start">
            <?php

            $format = $year_number == 0 ? 'M d' : 'M d, Y';
            printf( esc_html__( '%s', 'tp-base-toolkit' ), $date_starts->format( $format ));
            ?>
        </span>
	        <?php echo esc_html__( 'to', 'tp-base-toolkit' ) ?>
            <span class="event-date__end">
            <?php printf( esc_html__( '%s', 'tp-base-toolkit' ), $date_ends->format( 'M d, Y' ));?>
        </span>
        <?php endif;?>

    </div>
</div>