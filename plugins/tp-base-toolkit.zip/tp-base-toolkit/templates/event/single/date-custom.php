<div class="event-date event-date--custom">

    <div class="event-date__list">
		<?php foreach ( $items as $date ): ?>
            <div class="event-date__item">


                <span class="item-date" title="<?php echo esc_attr( $date['date']->format( 'l, F m' ) ) ?>">
                    <div class="item-weekday"><?php echo esc_html( $date['date']->format( 'D' ) ) ?></div>
                    <div class="item-day"><?php echo esc_html( $date['date']->format( 'j' ) ) ?></div>
                </span>

                <div class="item-time">
                    <div class="item-time__hours">
                        <span><?php echo esc_html( $date['time_start']->format( 'H:i A' ) ) ?></span>
                        <span>- <?php echo esc_html( $date['time_end']->format( 'H:i A' ) ) ?></span>
                    </div>
                    <div class="item-time__date">
						<?php echo esc_attr( $date['date']->format( 'l, F jS, Y' ) ) ?>
                    </div>
                </div>
            </div>
		<?php endforeach; ?>
    </div>


</div>