<?php
/**
 * Single Event Thumbnails
 *
 * This template can be overridden by copying it to yourtheme/template-parts/toolkit/event/single/event-image-thumbnails.php.
 *
 * @author        ThemesPond
 * @package    TP_Base\Templates
 * @version     1.0
 */

global $post, $tp_base_event;

$attachment_ids = $tp_base_event->get_image_ids();

if ( empty( $attachment_ids ) ) {
	return;
}
?>
<div id="event-carousel">
    <div class="event-carousel-nav">
		<?php
		foreach ( $attachment_ids as $attachment_id ) {
			echo '<div class="item">';
			echo wp_get_attachment_image( $attachment_id, 'tp-base-event-thumbnail' );
			echo '</div>';
		}
		?>

    </div>
</div>