<?php
/**
 * Template part for displaying list event
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package TP_Base
 * @since 1.0
 */


?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="row">
        <div class="col-lg-4 thumbnail">
            <a href="<?php the_permalink() ?>">
				<?php if ( has_post_thumbnail() ): ?>
					<?php the_post_thumbnail( 'tp-base-blog' ); ?>
				<?php else: ?>
                    <img src="<?php echo TP_BASE_TOOLKIT_URL . '/assets/images/member-default' ?>" alt="no-thumbnail">
				<?php endif; ?>
            </a>
        </div>

        <div class="col-sm-3 col-md-3 col-lg-2 align-self-center">
            <?php tp_base_toolkit_event_loop_date_start() ?>
        </div>

        <div class="col-sm-9 col-md-9 col-lg-6 inner">
            <div class="entry-title">
                <a href="<?php the_permalink() ?>"><?php the_title( '<h3 class="title">', '</h3>' ) ?></a>
            </div>
            <div class="entry-content">
				<?php the_excerpt() ?>
            </div>
            <div class="event-meta">

				<?php
				/**
				 * tp_base\toolkit\even_meta hook.
				 *
				 * @hooked tp_base_toolkit_event_single_datetime_meta() - 5
				 * @hooked tp_base_toolkit_event_get_location() - 10
				 */
				do_action( 'tp_base\toolkit\event_meta' );
				?>

            </div>

        </div>
    </div>

</article>