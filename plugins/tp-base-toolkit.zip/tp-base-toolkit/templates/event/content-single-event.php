<?php
/**
 * The template part for displaying single posts
 *
 * @package TP_Base
 * @since 1.0
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <div class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
        <div class="event-meta">
        <?php
		/**
		 * tp_base\toolkit\even_meta hook.
		 *
		 * @hooked tp_base_toolkit_event_single_datetime_meta() - 5
         * @hooked tp_base_toolkit_event_get_location() - 10
		 */
        do_action('tp_base\toolkit\event_meta');
        ?>
        </div>
    </div><!-- .entry-header -->

	<?php tp_base_toolkit_event_single_image() ?>

	<?php
	/**
	 * @hooked tp_base_toolkit_event_single_tabs() - 10
	 */
	do_action( 'tp_base\toolkit\event_single_content' ) ?>

</article><!-- #post-## -->
