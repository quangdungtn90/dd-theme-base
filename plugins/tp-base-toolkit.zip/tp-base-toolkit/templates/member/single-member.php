<?php
/**
 * The template for displaying all single members
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package TP_Base
 * @since 1.0
 */
get_header();

/**
 * @hooked: tp_base_breadcrumb - 5
 * @hooked: tp_base_before_main_content - 10
 */
do_action( 'tp_base\before_main_content' );
?>
    <div class="content-area">
        <main id="main" class="site-main">

			<?php while ( have_posts() ) : the_post(); ?>

				<?php tp_base_toolkit_template( 'member/content-single-member' ); ?>

				<?php
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;
				?>

			<?php endwhile; // end of the loop. ?>

        </main>
    </div>
<?php

/**
 * @hooked: tp_base_after_main_content - 15
 */
do_action( 'tp_base\after_main_content' );

get_footer();
