<?php
/**
 * The template part for displaying single posts
 *
 * @package TP_Base
 * @since 1.0
 */
global $tp_base_member;
?>

<article id="member-<?php the_ID(); ?>" <?php post_class(); ?>>



	<div class="post-thumbnail">
		<?php the_post_thumbnail(); ?>
	</div><!-- .post-thumbnail -->

	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

		<ul class="entry-meta">

			<?php if ( $firstname = $tp_base_member->get_firstname() ): ?>
				<li>
					<strong><?php echo esc_html__( 'First name', 'tp-base-toolkit' ) ?>:</strong>
					<span><?php echo esc_html( $firstname ) ?></span>
				</li>
			<?php endif; ?>

			<?php if ( $lastname = $tp_base_member->get_lastname() ): ?>
				<li>
					<strong><?php echo esc_html__( 'Last name', 'tp-base-toolkit' ) ?>:</strong>
					<span><?php echo esc_html( $lastname ) ?></span>
				</li>
			<?php endif; ?>

			<?php if ( $gender = $tp_base_member->get_gender_text() ): ?>
				<li>
					<strong><?php echo esc_html__( 'Gender', 'tp-base-toolkit' ) ?>:</strong>
					<span><?php echo esc_html( $gender ) ?></span>
				</li>
			<?php endif; ?>

			<?php if ( $email = $tp_base_member->get_email() ): ?>
				<li>
					<strong><?php echo esc_html__( 'Email', 'tp-base-toolkit' ) ?>:</strong>
					<a href="mailto:<?php echo esc_attr( $email ) ?>"><?php echo esc_html( $email ) ?></a>
				</li>
			<?php endif; ?>

			<?php if ( $phone = $tp_base_member->get_phone() ): ?>
				<li>
					<strong><?php echo esc_html__( 'Phone', 'tp-base-toolkit' ) ?>:</strong>
					<a href="tel:<?php echo tp_base_toolkit_sanitize_phone_number( $phone ) ?>"><?php echo esc_html( $phone ) ?></a>
				</li>
			<?php endif; ?>

			<?php if ( $address = $tp_base_member->get_address() ): ?>
				<li>
					<strong><?php echo esc_html__( 'Address', 'tp-base-toolkit' ) ?>:</strong>
					<span>
						<?php echo esc_html( $address ) ?>
					</span>
				</li>
			<?php endif; ?>

			<?php
			if ( $socials = $tp_base_member->get_contacts() ):?>	
				<li>
					<strong><?php echo esc_html__( 'Socials', 'tp-base-toolkit' ) ?>:</strong>
					<?php print $tp_base_member->get_contacts_html() ?>
				</li>
			<?php endif; ?>
				
		</ul>
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php the_content(); ?>
	</div><!-- .entry-content -->

</article>
