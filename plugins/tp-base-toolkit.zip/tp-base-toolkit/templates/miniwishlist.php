<?php
/*
 * @Global from wish list plugin
 * @yith-woocommerce-wishlist
 */
global $wishlist_items;
global $wishlist_meta;

$wishlist_token = '';
if ( ! empty( $wishlist_meta['wishlist_token'] ) && is_user_logged_in() ) {
	$wishlist_token = $wishlist_meta['wishlist_token'];
}
?>
<div>
	<?php if ( count( $wishlist_items ) > 0 ) : ?>

        <ul class="miniwishlist__products"
            data-token="<?php echo esc_attr( $wishlist_token ) ?>"
            data-id="<?php echo ( is_user_logged_in() ) ? esc_attr( $wishlist_meta['ID'] ) : '' ?>">
			<?php
			global $wpdb, $woocommerce;

			foreach ( $wishlist_items as $item ) :

				$product = wc_get_product( $item['prod_id'] );

				if ( $product !== false && $product->exists() ) :
					$availability = $product->get_availability();
					$stock_status = $availability['class'];
					?>

                    <li class="miniwishlist__item" data-id="<?php echo esc_attr( $item['prod_id'] ) ?>">

                        <a href="<?php echo esc_url( add_query_arg( 'remove_from_wishlist', $item['prod_id'] ) ) ?>"
                           class="remove"
                           title="<?php echo esc_attr__( 'Remove this product', 'tp-base-toolkit' ) ?>">×</a>

                        <a href="<?php echo esc_url( get_permalink( $item['prod_id'] ) ) ?>">
							<?php echo get_the_post_thumbnail( $item['prod_id'], 'thumbnail' ) ?>
							<?php print $product->get_title() ?>
                        </a>

						<?php print $product->get_price_html(); ?>
                    </li>

					<?php
				endif;
			endforeach;
			?>
        </ul>

        <div class="buttons">
            <a href="<?php echo esc_url( YITH_WCWL()->get_wishlist_url() ) ?>" class="button wc-forward">
				<?php echo esc_html__( 'View detail', 'tp-base-toolkit' ) ?>
            </a>
        </div>

		<?php else:?>
        <div class="miniwishlist__item-empty">
            <i class="fa fa-heart-o"></i>
			<?php echo esc_html__( 'No products were added to the wishlist', 'tp-base-toolkit' ) ?>
        </div>
	<?php endif; ?>
</div>