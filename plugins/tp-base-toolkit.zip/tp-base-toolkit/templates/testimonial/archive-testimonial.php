<?php
/**
 * The testimonial list template file
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package TP_Base
 * @since 1.0
 */
get_header();

/**
 * @hooked: tp_base_breadcrumb - 5
 * @hooked: tp_base_before_main_content - 10
 */
do_action( 'tp_base\before_main_content' );
?>

<div class="content-area">
	<main id="main" class="site-main">

		<?php
		if ( have_posts() ) :
			echo '<div class="row">';
			/* Start the Loop */
			while ( have_posts() ) : the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				echo '<div class="col-md-4">';
				tp_base_toolkit_template( 'testimonial/content-testimonial' );
				echo '</div>';
			endwhile;
			echo '</div>';
		else :

			get_template_part( 'template-parts/post/content', 'none' );

		endif;
		?>

	</main><!-- #main -->
</div><!-- .content-area -->

<?php
/**
 * @hooked: tp_base_pagination - 10
 * @hooked: tp_base_after_main_content - 15
 */
do_action( 'tp_base\after_main_content' );

get_footer();
