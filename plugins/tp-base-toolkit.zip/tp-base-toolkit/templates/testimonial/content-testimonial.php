<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to tp-base/template-parts/toolkit/content-testimonial.php.
 *
 * @package TP_Base
 * @version 1.0
 */
global $tp_base_testimonial;
?>

<article id="testimonial-<?php the_ID(); ?>" <?php post_class(); ?>>

	<?php if ( has_post_thumbnail() ): ?>
		<div class="post-thumbnail">
			<a href="<?php the_permalink() ?>"><?php the_post_thumbnail(); ?></a>
		</div><!-- .post-thumbnail -->
	<?php endif; ?>

	<header class="entry-header">
		<?php the_title( sprintf( '<h3 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>

		<?php if ( $job = $tp_base_testimonial->get_job() ): ?>
			<div class="testimonial-job"><?php echo esc_html( $job ) ?></div>
		<?php endif; ?>

		<?php print $tp_base_testimonial->get_rate_html() ?>
    </header><!-- .entry-header -->


    <div class="entry-content">
		<?php the_excerpt(); ?>
		<a href="<?php the_permalink() ?>" class="morelink"><?php echo esc_html__( 'Read more', 'tp-base-toolkit' ) ?></a>
    </div><!-- .entry-content -->
</article>
