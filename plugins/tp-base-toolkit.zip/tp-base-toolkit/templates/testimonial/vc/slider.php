<div class="testimonial_slider">

	<?php if ( !empty( $title ) ): ?>
		<h2 class="testimonial_slider__title"><?php echo esc_html( $title ) ?></h2>
	<?php endif; ?>
		
    <div class="testimonial_slider__image">
		<?php
		if ( $query->have_posts() ):
			$index = 0;
			while ( $query->have_posts() ):
				$query->the_post();
				?>
				<div class="testimonial_slider__image-item">
					<span><?php the_post_thumbnail( 'thumbnail' ) ?></span>
				</div>
				<?php
				$index++;
			endwhile;
			wp_reset_postdata();
		endif;
		?>
    </div>

    <div class="testimonial_slider__info">
		<?php
		if ( $query->have_posts() ):
			$index = 0;
			while ( $query->have_posts() ):
				$query->the_post();
				global $tp_base_testimonial;
				?>
				<div class="testimonial_slider__item">

					<?php if ( $description = $tp_base_testimonial->get_description() ) : ?>
						<div class="testimonial_slider__item-description">
							<?php echo esc_html( $description ) ?>
						</div>
					<?php endif; ?>

					<div class="testimonial_slider__item-heading">

						<div class="testimonial_slider__item-name">
							<?php
							if ( $href = $tp_base_testimonial->get_website() ) {
								printf( '<a href="%1$s" target="_blank" title="%2$s">%2$s</a>', $href, $tp_base_testimonial->get_fullname() );
							} else {
								echo esc_html( $tp_base_testimonial->get_fullname() );
							}
							?>
							<?php ?>
						</div>

						<?php if ( $job = $tp_base_testimonial->get_job() ) : ?>
							- 
							<div class="testimonial_slider__item-position">
								<?php echo esc_html( $job ) ?>
							</div>
						<?php endif; ?>

						<?php
						print $tp_base_testimonial->get_rate_html();
						?>

					</div>
				</div>
				<?php
				$index++;
			endwhile;
			wp_reset_postdata();
		endif;
		?>
    </div>
</div>
