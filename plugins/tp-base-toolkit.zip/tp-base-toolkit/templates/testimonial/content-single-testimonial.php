<?php
/**
 * The template part for displaying single posts
 *
 * @package TP_Base
 * @since 1.0
 */
global $tp_base_testimonial;
?>

<article id="testimonial-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="post-thumbnail">
		<?php the_post_thumbnail( 'thumbnail' ); ?>
	</div><!-- .post-thumbnail -->

	<header class="entry-header">
		<h1 class="entry-title"><?php echo esc_html( $tp_base_testimonial->get_fullname() ); ?></h1>
		<ul class="entry-meta">
			<?php if ( $job = $tp_base_testimonial->get_job() ): ?>
				<li>
					<strong><?php echo esc_html__( 'Job', 'tp-base-toolkit' ) ?>:</strong>
					<span><?php echo esc_html( $job ) ?></span>
				</li>
			<?php endif; ?>

			<?php if ( $email = $tp_base_testimonial->get_email() ): ?>
				<li>
					<strong><?php echo esc_html__( 'Email', 'tp-base-toolkit' ) ?>:</strong>
					<a href="mailto:<?php echo esc_attr( $email ) ?>"><?php echo esc_html( $email ) ?></a>
				</li>
			<?php endif; ?>

			<?php if ( $website = $tp_base_testimonial->get_website() ): ?>
				<li>
					<strong><?php echo esc_html__( 'Website Url', 'tp-base-toolkit' ) ?>:</strong>
					<a href="<?php echo esc_url( $website ); ?>"><?php echo esc_html( $website ) ?></a>
				</li>
			<?php endif; ?>

			<li>
				<strong><?php echo esc_html__( 'Rate', 'tp-base-toolkit' ) ?>:</strong>
				<?php print $tp_base_testimonial->get_rate_html() ?>
			</li>

		</ul>
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php the_content() ?>
	</div><!-- .entry-content -->

</article>
