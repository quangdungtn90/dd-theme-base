<?php

namespace TP_Base\Toolkit\Testimonial\Vc;

/**
 * Testimonial Slider Visual Addon
 * 
 * @package     TP_Base
 * @subpackage  TP_Base\Toolkit
 * @author      ThemesPond
 * @license     GPLv3
 * 
 * @since 1.0
 */
class Slider {

	public $id = 'tp_base_testimonial_slider';

	public function __construct() {

		add_shortcode( $this->id, array( $this, 'render' ) );
		add_action( 'tp_base\toolkit\vc_map', array( $this, 'form' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueueScripts' ) );

		// Search post
		add_filter( 'vc_autocomplete_' . $this->id . '_ids_callback', array( $this, 'idsCallback' ), 10, 1 );
		add_filter( 'vc_autocomplete_' . $this->id . '_ids_render', array( $this, 'idsRender' ), 10, 1 );
	}

	/**
	 * Display form in admin
	 */
	public function form( $action, $tag ) {

		if ( $action == 'vc_edit_form' && $tag != $this->id ) {
			return;
		}

		vc_map( array(
			'name' => esc_html__( '[TP Base] Testimonial Slider', 'tp-base-toolkit' ),
			'base' => $this->id,
			'category' => esc_html__( 'TP Base', 'tp-base-toolkit' ),
			'icon' => '',
			'admin_enqueue_js' => '',
			'admin_enqueue_css' => '',
			"params" => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'tp-base-toolkit' ),
					'param_name' => 'title',
					'value' => '',
					'admin_label' => true
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Data source', 'tp-base-toolkit' ),
					'param_name' => 'datasource',
					'admin_label' => true,
					'value' => array(
						esc_attr__( 'Custom Query', 'tp-base-toolkit' ) => 'query',
						esc_attr__( 'Select manually', 'tp-base-toolkit' ) => 'id'
					),
					'save_always' => true,
				),
				array(
					'type' => 'autocomplete',
					'heading' => esc_html__( 'Select manually:', 'tp-base-toolkit' ),
					'param_name' => 'ids',
					'admin_label' => true,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'id',
					)
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Order by', 'tp-base-toolkit' ),
					'param_name' => 'orderby',
					'admin_label' => true,
					'value' => array(
						esc_attr__( 'Date', 'tp-base-toolkit' ) => 'date',
						esc_attr__( 'ID', 'tp-base-toolkit' ) => 'ID',
						esc_attr__( 'Rate', 'tp-base-toolkit' ) => 'rate',
						esc_attr__( 'Random', 'tp-base-toolkit' ) => 'rand',
					),
					'save_always' => true,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Order', 'tp-base-toolkit' ),
					'param_name' => 'order',
					"admin_label" => true,
					'value' => array(
						esc_attr__( "DESC", 'tp-base-toolkit' ) => 'desc',
						esc_attr__( "ASC", 'tp-base-toolkit' ) => 'asc',
					),
					'save_always' => true,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of displayed posts', 'tp-base-toolkit' ),
					'param_name' => 'posts_per_page',
					'value' => 5,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of offset posts', 'tp-base-toolkit' ),
					'param_name' => 'offset',
					'value' => 0,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
					'edit_field_class' => 'vc_col-sm-6',
				),
			)
		) );
	}

	/**
	 * Render output
	 */
	public function render( $atts ) {

		$atts = wp_parse_args( $atts, array(
			'title' => '',
			'datasource' => 'query',
			'ids' => '',
			'orderby' => 'date',
			'order' => 'DESC',
			'posts_per_page' => 6,
			'offset' => 0
				) );

		$args = tp_base_toolkit_query( 'testimonial', $atts );

		$atts['query'] = new \WP_Query( $args );

		return tp_base_toolkit_get_template( 'testimonial/vc/slider', $atts );
	}

	public function enqueueScripts() {
		global $post;
		if ( $post && $post->post_type == 'page' && has_shortcode( $post->post_content, $this->id ) ) {
			wp_enqueue_script( 'slick' );
			wp_enqueue_style( 'slick' );
			wp_enqueue_style( 'slick-theme' );
		}
	}

	/**
	 * Function product attributes search
	 * For Visual Composer Autocomplete Param
	 *
	 * @param string $search_string
	 *
	 * @return array  - tags suggestion result
	 */
	public function idsRender( $query ) {

		if ( $post = get_post( $query['value'] ) ) {
			$query['label'] = $post->post_title;
		}

		return $query;
	}

	/**
	 * Function product attributes render
	 * For Visual Composer Autocomplete Param
	 *
	 * @param string $query
	 *
	 * @return array attributes( value, label ) selected by user
	 */
	public function idsCallback( $search_string ) {

		$posts = get_posts( array(
			's' => $search_string,
			'post_type' => 'testimonial',
			'post_status' => 'published',
			'posts_per_page' => 10 ) );

		$results = array();

		foreach ( $posts as $post ) {
			$results[] = array(
				'label' => $post->post_title,
				'value' => $post->ID,
				'group' => 'testimonial'
			);
		}

		return $results;
	}

}
