<?php

namespace TP_Base\Toolkit\Testimonial;

class Hooks {

	public function __construct() {

		new Register();

		new Admin\Customizer();
		new Admin\Metabox();

		new Query\Customizer();
		new Query\Metabox();

		add_filter( 'template_include', array( $this, 'templateLoader' ) );
		add_action( 'the_post', array( $this, 'setupData' ) );
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function init() {
		if ( class_exists( '\Vc_Manager' ) ) {
			new Vc\Slider();
		}
	}

	/**
	 * Load a template.
	 *
	 * Handles template usage so that we can use our own templates instead of the themes.
	 *
	 * Templates are in the 'templates' folder. toolkit looks for theme.
	 * overrides in /theme/toolkit/ by default.
	 *
	 * @param mixed $template
	 *
	 * @return string
	 */
	public static function templateLoader( $template ) {

		if ( is_embed() ) {
			return $template;
		}

		if ( is_singular( 'testimonial' ) ) {
			$template = tp_base_toolkit_template_path( 'testimonial/single-testimonial' );
		} else if ( is_post_type_archive( 'testimonial' ) ) {
			$template = tp_base_toolkit_template_path( 'testimonial/archive-testimonial' );
		}

		return $template;
	}

	/**
	 * When the_post is called, put product data into a global.
	 *
	 * @param mixed $post Post Object.
	 *
	 * @return Event
	 */
	public function setupData( $post ) {
		unset( $GLOBALS['tp_base_testimonial'] );

		if ( is_int( $post ) ) {
			$the_post = get_post( $post );
		} else {
			$the_post = $post;
		}

		if ( empty( $the_post->post_type ) || $the_post->post_type !== 'testimonial' ) {
			return;
		}

		$GLOBALS['tp_base_testimonial'] = new Testimonial( $the_post );

		return $GLOBALS['tp_base_testimonial'];
	}

}
