<?php

namespace TP_Base\Toolkit\Testimonial;

use TP_Base\Toolkit\Admin\Metabox;

class Register extends Metabox {

	public function __construct() {

		add_action( 'init', array( $this, 'postType' ) );
		add_action( 'tpfw_metabox_init', array( $this, 'fields' ) );
	}

	public function postType() {

		$labels = array(
			'name' => esc_html_x( 'Testimonials', 'Post Type General Name', 'tp-base-toolkit' ),
			'singular_name' => esc_html_x( 'Testimonial', 'Post Type Singular Name', 'tp-base-toolkit' ),
			'menu_name' => esc_html__( 'Testimonials', 'tp-base-toolkit' ),
			'name_admin_bar' => esc_html__( 'Testimonial', 'tp-base-toolkit' ),
			'archives' => esc_html__( 'Testimonial Archives', 'tp-base-toolkit' ),
			'attributes' => esc_html__( 'Testimonial Attributes', 'tp-base-toolkit' ),
			'parent_item_colon' => esc_html__( 'Parent Testimonial:', 'tp-base-toolkit' ),
			'all_items' => esc_html__( 'All Items', 'tp-base-toolkit' ),
			'add_new_item' => esc_html__( 'Add New Item', 'tp-base-toolkit' ),
			'add_new' => esc_html__( 'Add Testimonial', 'tp-base-toolkit' ),
			'new_item' => esc_html__( 'New Testimonial', 'tp-base-toolkit' ),
			'edit_item' => esc_html__( 'Edit Testimonial', 'tp-base-toolkit' ),
			'update_item' => esc_html__( 'Update Testimonial', 'tp-base-toolkit' ),
			'view_item' => esc_html__( 'View Testimonial', 'tp-base-toolkit' ),
			'view_items' => esc_html__( 'View Testimonials', 'tp-base-toolkit' ),
			'search_items' => esc_html__( 'Search Testimonial', 'tp-base-toolkit' ),
			'not_found' => esc_html__( 'Not found', 'tp-base-toolkit' ),
			'not_found_in_trash' => esc_html__( 'Not found in Trash', 'tp-base-toolkit' ),
			'featured_image' => esc_html__( 'Image avatar', 'tp-base-toolkit' ),
			'set_featured_image' => esc_html__( 'Set Image avatar', 'tp-base-toolkit' ),
			'remove_featured_image' => esc_html__( 'Remove Image avatar', 'tp-base-toolkit' ),
			'use_featured_image' => esc_html__( 'Use as Image avatar', 'tp-base-toolkit' ),
			'insert_into_item' => esc_html__( 'Insert into Testimonial', 'tp-base-toolkit' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to the Testimonial', 'tp-base-toolkit' ),
			'items_list' => esc_html__( 'Testimonial list', 'tp-base-toolkit' ),
			'items_list_navigation' => esc_html__( 'Testimonial list navigation', 'tp-base-toolkit' ),
			'filter_items_list' => esc_html__( 'Filter Testimonial list', 'tp-base-toolkit' ),
		);


		$args = array(
			'menu_icon' => 'dashicons-groups',
			'label' => esc_html__( 'Testimonial', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Team Testimonials', 'tp-base-toolkit' ),
			'labels' => $labels,
			'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
			'taxonomies' => array(),
			'rewrite' => array( 'slug' => 'testimonial' ),
			'hierarchical' => false,
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'menu_position' => null,
			'show_in_admin_bar' => true,
			'show_in_nav_menus' => true,
			'can_export' => true,
			'has_archive' => true,
			'exclude_from_search' => false,
			'publicly_queryable' => true,
			'capability_type' => 'page',
		);

		register_post_type( 'testimonial', $args );
	}

	/**
	 * Declare Testimonials meta fields
	 *
	 * @since 1.0
	 *
	 * @param array $fields Form fields
	 *
	 * @return array Form fields
	 */
	public function fields() {

		$fields = array(
			array(
				'name' => '_testimonial_name',
				'type' => 'textfield',
				'heading' => esc_html__( 'Full Name', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
				'desc' => esc_html__( 'Customer name, leave empty to use default name from post title.', 'tp-base-toolkit' )
			),
			array(
				'name' => '_testimonial_job',
				'type' => 'textfield',
				'heading' => esc_html__( 'Job Name', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
				'desc' => esc_html__( 'Name of job or position.', 'tp-base-toolkit' )
			),
			array(
				'name' => '_testimonial_email',
				'type' => 'textfield',
				'heading' => esc_html__( 'Email', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_email',
			),
			array(
				'name' => '_testimonial_website',
				'type' => 'textfield',
				'heading' => esc_html__( 'Website Url', 'tp-base-toolkit' ),
				'sanitize_callback' => 'esc_url',
			),
			array(
				'name' => '_testimonial_rate',
				'type' => 'select',
				'heading' => esc_html__( 'Ratings', 'tp-base-toolkit' ),
				'options' => array(
					1 => esc_attr__( '1 Star', 'tp-base-toolkit' ),
					2 => esc_attr__( '2 Stars', 'tp-base-toolkit' ),
					3 => esc_attr__( '3 Stars', 'tp-base-toolkit' ),
					4 => esc_attr__( '4 Stars', 'tp-base-toolkit' ),
					5 => esc_attr__( '5 Stars', 'tp-base-toolkit' ),
				),
				'sanitize_callback' => 'absint',
				'value' => 5
			)
		);

		new \Tpfw_Metabox( array(
			'id' => '_testimonial_settings',
			'screens' => array( 'testimonial' ),
			'heading' => esc_html__( 'Testimonial Info', 'tp-base-toolkit' ),
			'context' => 'side', //side,advanced
			'priority' => 'low',
			'manage_box' => false,
			'fields' => $fields
				) );
	}

}
