<?php

namespace TP_Base\Toolkit\Testimonial\Admin;


class Customizer {
	public function __construct() {
		add_action( 'customize_register', array( $this, 'init' ), 11 );
	}

	public $wp_customizer;
	public $sidebars;

	public function init( $wp_customizer ) {

		$this->wp_customizer = $wp_customizer;

		$nonce = array( '' => esc_attr__( '-- Select sidebar --', 'tp-base-toolkit' ) );

		$this->sidebars = tp_base_toolkit_get_sidebars( $nonce );

		$this->archive();

		$this->single();

	}

	public function archive() {
		$testimonial = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'testimonial',
			'heading'     => esc_html__( 'Testimonial list', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Setting for page testimonial list', 'tp-base-toolkit' ),
			'fields'      => array(
				array(
					'name'              => 'testimonial_breadcrumb',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
				),
				array(
					'name'       => 'testimonial_breadcrumb_image',
					'type'       => 'image',
					'heading'    => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'dependency' => array(
						'testimonial_breadcrumb' => array( 'values' => 'yes' )
					)
				),

				array(
					'name'              => 'testimonial_sidebar_position',
					'type'              => 'image_select',
					'heading'           => esc_html__( 'Sidebar Position', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'left'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
						'none'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
						'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'right',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
				),
				array(
					'name'       => 'testimonial_sidebar',
					'type'       => 'select',
					'heading'    => esc_attr__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar',
					'dependency' => array(
						'testimonial_sidebar_position' => array( 'values' => array( 'left', 'right' ) )
					)
				),
			)
		) );
	}

	public function single() {
		$testimonial = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'testimonial-single',
			'heading'     => esc_html__( 'Testimonial single', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Setting for page testimonial single', 'tp-base-toolkit' ),
			'fields'      => array(
				array(
					'name'              => 'testimonial_single_breadcrumb',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
				),
				array(
					'name'       => 'testimonial_single_breadcrumb_image',
					'type'       => 'image',
					'heading'    => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'value'      => get_theme_mod( 'testimonial_breadcrumb_image' ),
					'dependency' => array(
						'testimonial_breadcrumb' => array( 'values' => 'yes' )
					)
				),

				array(
					'name'              => 'testimonial_single_sidebar_position',
					'type'              => 'image_select',
					'heading'           => esc_html__( 'Sidebar Position', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'left'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
						'none'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
						'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'right',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
				),
				array(
					'name'       => 'testimonial_single_sidebar',
					'type'       => 'select',
					'heading'    => esc_html__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar',
					'dependency' => array(
						'testimonial_single_sidebar_position' => array( 'values' => array( 'left', 'right' ) )
					)
				),
				array(
					'name'       => 'testimonial_single_sidebar',
					'type'       => 'select',
					'heading'    => esc_html__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar',
					'dependency' => array(
						'testimonial_single_sidebar_position' => array( 'values' => array( 'left', 'right' ) )
					)
				),
			)
		) );
	}

}