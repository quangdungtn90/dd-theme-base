<?php

namespace TP_Base\Toolkit\Testimonial\Admin;

use TP_Base\Toolkit\Admin\Metabox as TP_Base_Metabox;

class Metabox extends TP_Base_Metabox {
	
	public function __construct() {
		add_action( 'tpfw_metabox_init', array( $this, 'single' ) );
	}
	
	/**
	 * Advanded box settings for Testimonial
	 * @since 1.0
	 * @return void
	 */
	public function single() {
		new \Tpfw_Metabox( array(
			'id' => '_advanced_settings',
			'screens' => array( 'testimonial' ),
			'heading' => esc_html__( 'Advanced Settings', 'tp-base-toolkit' ),
			'context' => 'advanced', //side
			'priority' => 'low',
			'manage_box' => true,
			'fields' => $this->footerArgs()
				) );
	}

}
