<?php

namespace TP_Base\Toolkit\Testimonial;

class Testimonial {

	/**
	 * ID for this object.
	 *
	 * @since 1.0
	 * @var int
	 */
	protected $id = 0;

	/**
	 * Post type.
	 * @var string
	 */
	protected $post_type = 'testimonial';

	/**
	 * Stores testimonial data.
	 *
	 * @var array
	 */
	protected $data = array(
		'name' => '',
		'slug' => '',
		'date_created' => null,
		'date_modified' => null,
		'status' => false,
		'featured' => false,
		'description' => '',
		'content' => '',
		'image_id' => '',
		'comment_allowed' => false,
		'fullname' => '',
		'job' => '',
		'email' => '',
		'website' => '',
		'rate' => ''
	);

	/**
	 * Get the testimonial if ID is passed, otherwise the testimonial is new and empty.
	 * This class should NOT be instantiated, but the tp_base_toolkit_get_testimonial() function
	 * should be used.
	 *
	 * @param int|Testimonial|object $testimonial Testimonial to init.
	 */
	public function __construct( $testimonial = 0 ) {

		$this->setup( $testimonial );
	}

	public function __set( $name, $value ) {
		if ( isset( $this->data[$name] ) ) {
			$this->data[$name] = $value;
		}
	}

	public function __get( $name ) {
		return isset( $this->data[$name] ) ? $this->data[$name] : '';
	}

	/**
	 * Get testimonial id
	 * @return int
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Get testimonial name.
	 * @return string
	 */
	public function get_name() {
		return $this->__get( 'name' );
	}

	/**
	 * Get created date
	 * @return string
	 */
	public function get_date_created() {
		return $this->__get( 'date_created' );
	}

	/**
	 * Get modified date
	 * @return string
	 */
	public function get_date_modified() {
		return $this->__get( 'date_modified' );
	}

	/**
	 * Get status
	 * @return string
	 */
	public function get_status() {
		return $this->__get( 'status' );
	}

	/**
	 * Get is featured
	 * @return string
	 */
	public function get_featured() {
		return $this->__get( 'featured' );
	}

	/**
	 * Get description
	 * @return string
	 */
	public function get_description() {
		return $this->__get( 'description' );
	}

	/**
	 * Get content
	 * @return string
	 */
	public function get_content() {
		return $this->__get( 'content' );
	}

	/**
	 * Get thumbnail id
	 * @return string
	 */
	public function get_image_id() {
		return $this->__get( 'image_id' );
	}

	/**
	 * Get testimonial slug.
	 * @return string
	 */
	public function get_slug() {
		return $this->__get( 'slug' );
	}

	/**
	 * Get is comment allowed
	 * @return bool
	 */
	public function get_comment_allowed() {
		return $this->__get( 'comment_allowed' );
	}

	/**
	 * Get fullname
	 * @return string
	 */
	public function get_fullname() {

		if ( !empty( $this->__get( 'fullname' ) ) ) {
			return $this->__get( 'fullname' );
		}

		return $this->get_name();
	}

	/**
	 * Get job
	 * @return array
	 */
	public function get_job() {
		return $this->__get( 'job' );
	}

	/**
	 * Get email
	 * @return string
	 */
	public function get_email() {
		return $this->__get( 'email' );
	}

	/**
	 * Get website url
	 * @return string
	 */
	public function get_website() {
		return $this->__get( 'website' );
	}

	/**
	 * Get address
	 * @return string
	 */
	public function get_rate() {
		return $this->__get( 'rate' );
	}

	/**
	 * Method to read a testimonial from the database.
	 *
	 * @param Event|WP_Post $testimonial
	 *
	 * @throws Exception
	 */
	public function setup( $post ) {

		if ( is_numeric( $post ) ) {
			$post = get_post( $post );
		}

		if ( !$post ) {
			throw new \Exception( __( 'Invalid testimonial.', 'tp-base-toolkit' ) );
		}

		$this->id = $post->ID;

		$this->__set( 'name', $post->post_title );
		$this->__set( 'slug', $post->post_name );
		$this->__set( 'date_created', $post->post_date_gmt );
		$this->__set( 'date_modified', $post->post_modified_gmt );
		$this->__set( 'description', get_the_excerpt( $post ) );
		$this->__set( 'content', $post->post_content );
		$this->__set( 'parent_id', $post->post_parent );
		$this->__set( 'slug', $post->post_name );
		$this->__set( 'comment_allowed', 'open' === $post->comment_status );

		$this->__set( 'fullname', get_post_meta( $this->get_id(), '_testimonial_fullname', true ) );
		$this->__set( 'job', get_post_meta( $this->get_id(), '_testimonial_job', true ) );
		$this->__set( 'email', get_post_meta( $this->get_id(), '_testimonial_email', true ) );
		$this->__set( 'website', get_post_meta( $this->get_id(), '_testimonial_website', true ) );
		$this->__set( 'rate', get_post_meta( $this->get_id(), '_testimonial_rate', true ) );
	}

	/**
	 * Display rate in html format
	 * @return void
	 */
	public function get_rate_html() {
		$html = '<div class="testimonial-rating">';
		$rate = $this->get_rate();
		for ( $i = 1; $i <= 5; $i++ ) {
			$cssClass = 'fa fa-star-o';
			if ( $rate >= $i ) {
				$cssClass = 'fa fa-star';
			}
			$html .= sprintf( '<i class="%s" aria-hidden="true"></i>', $cssClass );
		}
		$html .= '</div>';

		return apply_filters( 'tp_base\toolkit\testimonial\get_rate_html', $html, $rate );
	}

}
