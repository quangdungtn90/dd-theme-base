<?php

namespace TP_Base\Toolkit\Testimonial\Query;


class Customizer {

	public function __construct() {
		add_filter( 'tp_base\query', array( $this, 'init' ) );
	}

	public function init( $query ) {

		if ( $query['hook']['id'] == 'archive_member' ) {
			$query = $this->archive( $query );
		} else if ( $query['hook']['group'] == 'member' ) {
			$query = $this->single( $query );
		}

		return $query;
	}

	public function archive( $query ) {
		$query['breadcrumb']['enable'] = get_theme_mod( 'member_breadcrumb', 'yes' );
		$query['breadcrumb']['image']  = esc_url( get_theme_mod( 'member_breadcrumb_image' ) );

		$query['sidebar']['id']       = get_theme_mod( 'member_sidebar', 'sidebar' );
		$query['sidebar']['position'] = get_theme_mod( 'member_sidebar_position', 'left' );

		return $query;
	}

	public function single( $query ) {
		$query['breadcrumb']['enable'] = get_theme_mod( 'member_single_breadcrumb', get_theme_mod( 'member_breadcrumb', 'yes' ) );
		$query['breadcrumb']['image']  = esc_url( get_theme_mod( 'member_single_breadcrumb_image' ) );

		$query['sidebar']['id']       = get_theme_mod( 'member_single_sidebar', get_theme_mod( 'member_sidebar', 'sidebar' ) );
		$query['sidebar']['position'] = get_theme_mod( 'member_single_sidebar_position', get_theme_mod( 'member_sidebar_position', 'left' ) );

		return $query;
	}

}