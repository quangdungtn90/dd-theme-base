<?php

namespace TP_Base\Toolkit;

class Typography {
	
	/**
	 * @var tring Db option key
	 */
	private $key = 'tp_base_toolkit_fonts';

	public function __construct() {
		add_filter( 'tp_base\fonts_url', array( $this, 'fontUrl' ) );
		add_filter( 'pre_set_theme_mod_primary_font', array( $this, 'flushCache' ) );
		add_filter( 'pre_set_theme_mod_secondary_font', array( $this, 'flushCache' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueueFonts' ), 999 );
	}
	
	/**
	 * Add font-family css to inline style of the theme
	 * @since 1.0
	 */
	public function enqueueFonts() {
		if ( get_theme_mod( 'typography_enable', false ) ) {
			wp_add_inline_style( 'tp-base-style', $this->fontCss() );
		}
	}

	/**
	 * Override to font url in the theme
	 *
	 * @param string $fonts_url
	 *
	 * @return string
	 * @since 1.0
	 */
	public function fontUrl( $fonts_url ) {

		$primary = get_theme_mod( 'primary_font' );

		$primary = tpfw_build_typography( $primary );

		$secondary = get_theme_mod( 'secondary_font' );

		$secondary = tpfw_build_typography( $secondary );

		$font_families = array();

		$subsets = array();

		if ( !empty( $primary['font-family'] ) ) {
			$font_families[] = sprintf( '%s:%s', $primary['font-family'], $primary['variants'] );
			if ( !empty( $primary['subsets'] ) ) {
				$subsets = array_merge( $subsets, explode( ',', $primary['subsets'] ) );
			}
		}

		if ( !empty( $secondary['font-family'] ) ) {
			$font_families[] = sprintf( '%s:%s', $secondary['font-family'], $secondary['variants'] );

			if ( !empty( $secondary['subsets'] ) ) {
				$subsets = array_merge( $subsets, explode( ',', $secondary['subsets'] ) );
			}
		}

		$subsets = array_unique( $subsets );

		$query_args = array(
			'family' => urlencode( implode( '|', $font_families ) ),
			'subset' => urlencode( implode( ',', $subsets ) ),
		);

		if ( $font_families && get_theme_mod( 'typography_enable', 0 ) ) {
			$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
		}

		return $fonts_url;
	}

	/**
	 * Generate the CSS for the current fonts
	 * @since 1.0
	 * @return string
	 */
	public function fontCss() {
		$css = '';

		if ( !WP_DEBUG && !is_customize_preview() ) {
			$css = get_transient( $this->key );
		}

		if ( empty( $css ) ) {

			$primary = get_theme_mod( 'primary_font' );
			$primary = tpfw_build_typography( $primary );

			$secondary = get_theme_mod( 'secondary_font' );
			$secondary = tpfw_build_typography( $secondary );

			$css = '
		 /**
		  * TP Base Toolkit: Fonts
		  * 1. Primary font
		  * 2. Secondary font
		  */
		';

			if ( !empty( $primary['font-family'] ) ) {
				$css .= '.primary_font, body{
				font-family: ' . esc_attr( $primary['font-family'] ) . ',-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
			}';
			}

			if ( !empty( $secondary['font-family'] ) ) {
				$css .= '.secondary_font, h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6,.widget .widget-title,.entry-title,.comments-title, .comment-reply-title, .releated_posts__title,.site-title{
				font-family: ' . esc_attr( $secondary['font-family'] ) . ',-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif
			}';
			}
			if ( !WP_DEBUG && !is_customize_preview() ) {
				set_transient( $this->key, $css );
			}
		}


		/**
		 * Filters Font custom
		 * @since 1.0
		 *
		 * @param $css    string Base theme fonts CSS.
		 */
		return apply_filters( 'tp_base\toolkit\fonts', $css );
	}

	/**
	 * Before theme mod changed, delete font family css
	 * @since 1.0
	 * @return string
	 */
	public function flushCache( $value ) {
		delete_transient( $this->key );

		return $value;
	}

}
