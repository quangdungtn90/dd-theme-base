<?php

namespace TP_Base\Toolkit\Widget;

/**
 * Widget Posts
 *
 * @package     TP_Base
 * @subpackage  TP_Base\Toolkit
 * @category    Widget
 * @author      ThemesPond
 * @license     GPLv3
 */

class Posts extends \Tpfw_Widget {

    public function __construct() {

        $this->widget_cssclass = 'tp_base_widget_posts';
        $this->widget_description = esc_html__('Display Posts.', 'tp-base-toolkit');
        $this->widget_id = 'tp_base_widget_posts';
        $this->widget_name = esc_html__('[TP Base] Posts', 'tp-base-toolkit');


        $this->fields = array(
            // Title
            array(
                'name' => 'title',
                'type' => 'textfield',
                'heading' => esc_html__('Title :', 'tp-base-toolkit'),
            ),
            //Data Source
            array(
                'name' => 'datasource',
                'type' => 'select',
                'multiple' => false,
                'value' => 'custom',
                'heading' => esc_html__('Data source :', 'tp-base-toolkit'),
                'options' => array(
                    'custom' => esc_html__('Custom Query', 'tp-base-toolkit'),
                    'ids' => esc_html__('List Of Posts', 'tp-base-toolkit')
                ),
                'value' => 'custom'
            ),
            //Posts IDS
            array(
                'name' => 'include',
                'type' => 'autocomplete',
                'heading' => esc_html__('List Of Posts :', 'tp-base-toolkit'),
                'value' => '',
                'desc' => esc_html__('', 'tp-base-toolkit'),
                'data' => array('post_type' => array('post')),
                'placeholder' => esc_html__('Enter 3 or more characters to search...', 'tp-base-toolkit'),
                'min_length' => 2,
                'dependency' => array(
                    'datasource' => array('values' => 'ids')
                )
            ),
            // Categories
            array(
                'name' => 'categories',
                'type' => 'autocomplete',
                'heading' => esc_html__('Categories :', 'tp-base-toolkit'),
                'value' => '',
                'desc' => esc_html__('', 'tp-base-toolkit'),
                'data' => array('taxonomy' => array('category')),
                'placeholder' => esc_html__('Enter 3 or more characters to search...', 'tp-base-toolkit'),
                'min_length' => 3,
                'dependency' => array(
                    'datasource' => array('values' => 'custom')
                )
            ),
            // Relation
            array(
                'name' => 'relation',
                'type' => 'select',
                'multiple' => true,
                'heading' => esc_html__('Relation :', 'tp-base-toolkit'),
                'value' => array(
                    '',
                ),
                'inline' => 0,
                'multiple' => false,
                'options' => array(
                    'or' => esc_html__('OR', 'tp-base-toolkit'),
                    'and' => esc_html__('AND', 'tp-base-toolkit'),
                ),
                //'desc' => esc_html__('R', 'tp-base-toolkit'),
                'dependency' => array(
                    'datasource' => array('values' => 'custom')
                )
            ),
            // Tags
            array(
                'name' => 'categories',
                'type' => 'autocomplete',
                'heading' => esc_html__('Tags :', 'tp-base-toolkit'),
                'value' => '',
                'desc' => esc_html__('', 'tp-base-toolkit'),
                'data' => array('taxonomy' => array('post_tag')),
                'placeholder' => esc_html__('Enter 3 or more characters to search...', 'tp-base-toolkit'),
                'min_length' => 3,
                'dependency' => array(
                    'datasource' => array('values' => 'custom')
                )
            ),
            // Orderby
            array(
                'name' => 'orderby',
                'type' => 'select',
                'heading' => esc_html__('Order by :', 'tp-base-toolkit'),
                'inline' => 1,
                'value' => 'popular',
                'multiple' => false,
                'options' => tp_base_toolkit_get_post_orders(),
                'dependency' => array(
                    'datasource' => array('values' => 'custom')
                )
            ),
            // Order
            array(
                'name' => 'order',
                'type' => 'select',
                'heading' => esc_html__('Order :', 'tp-base-toolkit'),
                'value' => 'asc',
                'multiple' => false,
                'options' => array(
                    'desc' => esc_html__('DESC', 'tp-base-toolkit'),
                    'asc' => esc_html__('ASC', 'tp-base-toolkit')
                ),
                'desc' => esc_html__('Choose display postboxs', 'tp-base-toolkit'),
                'dependency' => array(
                    'datasource' => array('values' => 'custom')
                )
            ),
            // 
            array(
                'name' => 'posts_per_page',
                'type' => 'textfield',
                'heading' => esc_html__(' Number of displayed posts :', 'tp-base-toolkit'),
                'desc' => esc_html__('Enter the number of posts that will be displayed', 'tp-base-toolkit'),
                'value' => 5,
                'dependency' => array(
                    'datasource' => array('values' => 'custom')
                )
            ),
            array(
                'name' => 'offset',
                'type' => 'textfield',
                'heading' => esc_html__('Offset post :', 'tp-base-toolkit'),
                'desc' => esc_html__('Enter the number of posts that will be skipped', 'tp-base-toolkit'),
                'value' => 0,
                'dependency' => array(
                    'datasource' => array('values' => 'custom')
                )
            ),
            array(
                'name' => 'display',
                'type' => 'checkbox',
                'multiple' => true,
                'heading' => esc_html__('Content options :', 'tp-base-toolkit'),
                'multiple' => 1,
                'options' => array(
                    'show_thumb' => esc_html__('Show thumbnail?', 'tp-base-toolkit'),
                    'show_date' => esc_html__('Show posted date?', 'tp-base-toolkit'),
                ),
            ),
        );

        parent::__construct();
    }

    public function form($instance) {
        // Get all cats
        $all_cats = get_categories();
        $categories = array('' => esc_html__('--None--', 'tp-base-toolkit'));
        foreach ($all_cats as $cat) {
            $categories[$cat->name] = $cat->slug;
        }
        // Get all tags
        $all_tags = get_tags();
        $tags = array('' => esc_html__('--None--', 'tp-base-toolkit'));
        foreach ($all_tags as $tag) {
            $tags[$tag->name] = $tag->slug;
        }

        $this->fields[3]['options'] = $categories;
        $this->fields[5]['options'] = $tags;

        parent::form($instance);
    }

    /**
     * Widget output
     */
    public function widget($args, $instance) {
		
        $this->widget_start($args, $instance);
		
        // WP_Query arguments
        $filter = tp_base_toolkit_query('post', $instance);
		
        // The Query
        $max = 14;
		
        if(!empty( $instance['max_length'])){
            $max = $instance['max_length'];
        }
        $query = new \WP_Query($filter);
        
        $display ='';
        if(!empty($instance['display'])){
            $display = $instance['display'];
        }
        $data = array(
            'query' => $query,
            'display' => $display,
            'max' => $max
        );
        
        tp_base_toolkit_template('widgets/posts', $data);
		
        $this->widget_end($args);
    }

}
