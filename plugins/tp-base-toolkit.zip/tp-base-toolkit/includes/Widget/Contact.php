<?php
namespace TP_Base\Toolkit\Widget;

/**
 * Widget Contact
 *
 * @package     TP_Base
 * @subpackage TP_Base\Toolkit
 * @category    Widget
 * @author      ThemesPond
 * @license     GPLv3
 */

/**
 * Show widget contact info
 * Contact - Email - Phone
 * 
 */
class Contact extends \Tpfw_Widget {

    public function __construct() {

        $this->widget_cssclass = 'tp_base_widget_contact';
        $this->widget_description = esc_html__('Display Contact Infomation.', 'tp-base-toolkit');
        $this->widget_id = 'tp_base_widget_contact';
        $this->widget_name = esc_html__('[TP Base] Contact', 'tp-base-toolkit');
        $this->fields = array(
             array(
                'name' => 'title',
                'type' => 'textfield',
                'heading' => esc_html__('Title:', 'tp-base-toolkit'),
            ),
            array(
                'name' => 'image',
                'type' => 'image_picker',
                'multiple' => false,
                'heading' => esc_html__('Image:', 'tp-base-toolkit'),
                'desc' => esc_html__('Select an image from library.', 'tp-base-toolkit')
            ),
            array(
                'name' => 'address',
                'type' => 'textarea',
                'heading' => esc_html__('Address:', 'tp-base-toolkit'),
                'value' => '',
            ),
            array(
                'name' => 'email',
                'type' => 'textfield',
                'heading' => esc_html__('Email:', 'tp-base-toolkit'),
                'value' => '',
            ),
            array(
                'name' => 'phone',
                'type' => 'textfield',
                'heading' => esc_html__('Phone:', 'tp-base-toolkit'),
                'value' => '',
            ),
        );
        parent::__construct();
    }

    /**
     * Widget output
     */
    public function widget($args, $instance) {
		
        $this->widget_start($args, $instance);
        
        tp_base_toolkit_template('widgets/contact', $instance);
        
        $this->widget_end($args);
    }

}
