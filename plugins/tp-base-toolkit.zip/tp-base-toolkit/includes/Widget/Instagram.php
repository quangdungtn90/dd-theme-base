<?php
namespace TP_Base\Toolkit\Widget;

/**
 * Widget Instagram
 *
 * @package     TP_Base
 * @subpackage  TP_Base\Toolkit
 * @category    Widget
 * @author      ThemesPond
 * @license     GPLv3
 */

class Instagram extends \Tpfw_Widget {

	public function __construct() {

		$this->widget_cssclass = 'tp_base_widget_instagram';
		$this->widget_description = esc_html__( 'Display Instagram photo feeds.', 'tp-base-toolkit' );
		$this->widget_id = 'tp_base_widget_instagram';
		$this->widget_name = esc_html__( '[TP Base] Instagram Photos', 'tp-base-toolkit' );

		$this->fields = array(
			array(
				'name' => 'title',
				'type' => 'textfield',
				'heading' => esc_html__( 'Title:', 'tp-base-toolkit' ),
				'value' => esc_html__( 'Instagram photos', 'tp-base-toolkit' ),
			),
			array(
				'name' => 'user_id',
				'type' => 'textfield',
				'value' => '',
				'admin_label' => true,
				'heading' => esc_html__( 'User ID', 'tp-base-toolkit' ),
				'desc' => sprintf( wp_kses_post( __( 'To find your User ID, you can use %s.', 'tp-base-toolkit' ) ), '<a href="//smashballoon.com/instagram-feed/find-instagram-user-id/" target="_blank"> ' . esc_html__( 'this tool', 'tp-base-toolkit' ) . ' </a>' ),
			),
			array(
				'name' => 'accesscode',
				'type' => 'textfield',
				'value' => '',
				'admin_label' => true,
				'heading' => esc_html__( 'Access token', 'tp-base-toolkit' ),
				'desc' => sprintf( wp_kses_post( __( 'To find your Access token, you can use %s.', 'tp-base-toolkit' ) ), '<a href="//instagram.pixelunion.net/" target="_blank"> ' . esc_html__( 'this tool', 'tp-base-toolkit' ) . ' </a>' ),
			),
			array(
				'name' => 'count',
				'type' => 'textfield',
				'value' => 6,
				'heading' => esc_html__( 'Number of photos', 'tp-base-toolkit' ),
			),
		);

		parent::__construct();
	}

	/**
	 * Widget output
	 */
	public function widget( $args, $instance ) {

		$this->widget_start( $args, $instance );

		echo '<div class="widget-content">';

		if ( (!empty( $instance['accesscode'] )) && (!empty( $instance['user_id'] )) ):

			$access_token = $instance['accesscode'];

			$url = sprintf( 'https://api.instagram.com/v1/users/%s/media/recent/?access_token=%s&count=%d', $instance['user_id'], $access_token, $instance['count'] );

			$remote_get = wp_remote_get( $url );

			if ( !is_wp_error( $remote_get ) ) {
				$feeds = wp_remote_retrieve_body( $remote_get );
				$feeds = json_decode( $feeds );
				$feeds = isset( $feeds->data ) ? $feeds->data : array();
			}
			$instance['feeds'] = $feeds;

			tp_base_toolkit_template( 'widgets/instagram', $instance );
		else:
			echo esc_html__( 'Please provide Access token API and User ID !', 'tp-base-toolkit' );
		endif;

		echo '</div>';

		$this->widget_end( $args );
	}

}
