<?php

namespace TP_Base\Toolkit\Admin;

class SidebarCreator {

	/**
	 * Option key in db
	 * @var $key string 
	 */
	private $key;

	/**
	 * Storage sidebar data
	 * @var $data array
	 */
	private $data = array();

	/**
	 * Constructor
	 */
	public function __construct( $init_hooks = true ) {

		$this->key = 'tp_base_toolkit_sidebars';

		if ( $init_hooks ) {
			$this->hooks();
		}
	}

	public function setupData() {
		if ( !count( $this->data ) ) {
			$this->data = get_option( $this->key, array() );
		}
	}

	public function hooks() {

		add_action( 'widgets_init', array( $this, 'register' ), 1000 );

		add_action( 'load-widgets.php', array( $this, 'formHandle' ), 100 );

		add_action( 'wp_ajax_sidebar_creator_delete', array( $this, 'delete' ) );

		add_action( 'wp_ajax_sidebar_creator_edit', array( $this, 'edit' ) );

		add_action( 'admin_footer-widgets.php', array( $this, 'template' ), 5 );

		add_action( 'admin_notices', array( $this, 'adminNotice' ) );

		add_action( 'admin_enqueue_scripts', array( $this, 'adminScripts' ) );
	}

	public function __get( $name ) {
		return $name;
	}

	/**
	 * Load assets in admin panel
	 * @since 1.0
	 */
	public function adminScripts() {

		$screen = get_current_screen();

		if ( !empty( $screen->base ) && $screen->base == 'widgets' ) {

			$min = WP_DEBUG ? '' : '.min';

			wp_enqueue_script( 'tp-sidebar-creator', TP_BASE_TOOLKIT_URL . 'assets/libs/sidebar-creator/sidebar-creator' . $min . '.js', array( 'jquery' ), true );

			wp_enqueue_style( 'tp-sidebar-creator', TP_BASE_TOOLKIT_URL . 'assets/libs/sidebar-creator/sidebar-creator' . $min . '.css' );

			wp_localize_script( 'tp-sidebar-creator', 'tp_sidebar_creator', array(
				'text_remove' => esc_html__( 'Remove', 'tp-base-toolkit' ),
				'text_edit' => esc_html__( 'Edit', 'tp-base-toolkit' ),
				'label_edit' => esc_html__( 'Enter sidebar name', 'tp-base-toolkit' ),
				'confirm_remove' => esc_html__( 'Do you really want to delete this widget area?', 'tp-base-toolkit' )
			) );
		}
	}

	/**
	 * Template form add
	 * @since 1.0
	 */
	public function template() {
		?>
		<script type='text/html' id='sidebar_creator__template'>
			<form class='sidebar_creator sidebars-column-1' action='' method='POST'>
				<input type='text' value='' placeholder = '<?php echo esc_html__( 'Enter sidebar name', 'tp-base-toolkit' ) ?>' name='name' />
				<?php wp_nonce_field( 'sidebar_creator' ); ?>
				<button class='button-primary' type='submit'><?php echo esc_html__( 'Create sidebar', 'tp-base-toolkit' ) ?></button>
			</form>
		</script>
		<?php
	}

	/**
	 * Showing a notice  when a new sidebar was added successfuly
	 * @since 1.0
	 */
	public function adminNotice() {

		if ( !empty( $_GET['sidebar'] ) ):
			if ( sanitize_text_field( $_GET['sidebar'] ) == 'added' ):
				?>
				<div class="notice notice-success sidebar-creator__notice">
					<p><?php echo wp_kses_post( __( 'A <strong>Widget area</strong> was added successfully!', 'tp-base-toolkit' ) ); ?></p>
					<a class="notice-dismiss" href="<?php echo esc_url( admin_url( 'widgets.php' ) ) ?>"><?php echo esc_html__( 'Dismiss', 'tp-base-toolkit' ) ?></a>
				</div>
				<?php
			else:
				?>
				<div class="notice notice-error sidebar-creator__notice">
					<p><?php echo wp_kses_post( __( 'Sidebar name is existed, please create another sidebar.', 'tp-base-toolkit' ) ); ?></p>
					<a class="notice-dismiss" href="<?php echo esc_url( admin_url( 'widgets.php' ) ) ?>"><?php echo esc_html__( 'Dismiss', 'tp-base-toolkit' ) ?></a>
				</div>
			<?php
			endif;
		endif;
	}

	/**
	 * Register custom sidebar areas
	 * @since 1.0
	 * @return void
	 */
	public function register() {

		$this->setupData();

		$args = array(
			'before_widget' => '<div id="%1$s" class="widget clearfix %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="widget-title">',
			'after_title' => '</h3>'
		);

		$args = apply_filters( 'tp_base\toolkit\widget_args', $args );

		if ( is_array( $this->data ) ) {
			foreach ( $this->data as $sidebar ) {
				if ( $sidebar != "" ) {
					$args['name'] = $sidebar;
					$args['id'] = sanitize_title( $sidebar );
					$args['class'] = 'sidebar_creator';
					register_sidebar( $args );
				}
			}
		}
	}

	/**
	 * Add sidebar to db
	 * @since 1.0
	 */
	public function formHandle() {

		if ( !empty( $_POST['name'] ) ) {

			if ( wp_verify_nonce( $_POST['_wpnonce'], 'sidebar_creator' ) ) {
				$this->setupData();

				$name = sanitize_text_field( $_POST['name'] );

				if ( $this->add( $name ) ) {
					$this->save();
					wp_redirect( admin_url( 'widgets.php?sidebar=added' ) );
				} else {
					wp_redirect( admin_url( 'widgets.php?sidebar=false' ) );
				}
			}

			die();
		}
	}

	/**
	 * Add sidebar to data storage
	 * @param string $name Sidebar Name
	 */
	public function add( $name ) {

		if ( !$this->isExist( $name ) ) {
			$this->data[] = $name;
			return true;
		}

		return false;
	}

	/**
	 * Save sidebars to db
	 * @return bool
	 */
	public function save() {
		return update_option( $this->key, $this->data );
	}

	/**
	 * Ajax function
	 * Delete a sidebar area from the database
	 * @return void
	 */
	public function delete() {

		check_ajax_referer( 'sidebar_creator' );

		if ( !empty( $_POST['name'] ) ) {
			$name = sanitize_text_field( $_POST['name'] );

			$this->setupData();

			if ( ($index = array_search( $name, $this->data )) !== false ) {
				unset( $this->data[$index] );
				$this->save();
				wp_send_json_success();
			}
		}

		wp_send_json_error();
	}

	/**
	 * Ajax function
	 * Edit a sidebar area from the database
	 * @return void
	 */
	public function edit() {

		check_ajax_referer( 'sidebar_creator' );

		if ( !empty( $_POST['name'] ) && !empty( $_POST['newname'] ) ) {

			$name = sanitize_text_field( $_POST['name'] );
			$newname = sanitize_text_field( $_POST['newname'] );

			if ( trim( $name ) != trim( $newname ) ) {

				$this->setupData();

				if ( ($index = array_search( $name, $this->data )) !== false ) {
					$this->data[$index] = $newname;
					$this->save();
					wp_send_json_success();
				}
			}
		}

		wp_send_json_error();
	}

	/**
	 * Checks the user submitted name and makes sure that there are no colitions
	 * 
	 * @param string $name Sidebar name
	 * @return $name Sanitized sidebar name or false if this name is existed
	 */
	public function isExist( $name ) {

		if ( isset( $GLOBALS['wp_registered_sidebars'][$name] ) ) {
			return true;
		}

		return false;
	}

}
