<?php

namespace TP_Base\Toolkit\Admin;

class Importer {
	
	public function __construct() {
		add_action( 'import_start', array( $this, 'importSidebars' ), 20 );
		add_filter( 'tpfw_importer_files', array( $this, 'register' ), 10, 1 );
		add_action( 'tpfw_importer_end', array( $this, 'setData' ) );
	}
	
	/**
	 * Register demo
	 */
	public function register( $files ) {

		$files['tp_base'] = array(
			'name' => esc_html__( 'TP Base', 'tp-clever-toolkit' ),
			'content_url' => trailingslashit( TP_BASE_TOOLKIT_DIR ) . 'dummy-data/default/content.xml',
			'widget_url' => trailingslashit( TP_BASE_TOOLKIT_DIR ) . 'dummy-data/default/widgets.wie',
			'customizer_url' => trailingslashit( TP_BASE_TOOLKIT_DIR ) . 'dummy-data/default/customizer.dat',
			'preview_image' => trailingslashit( TP_BASE_TOOLKIT_URL ) . 'dummy-data/default/screenshot.png',
			'preview_url' => '//test.themespond.com/tp-base/',
		);

		return $files;
	}

	/**
	 * Register custom sidebars
	 * 
	 * @return void
	 */
	public function setSidebars() {


		$sidebar = new SidebarCreator();

		$sidebar->add( 'Member Sidebar' );
		$sidebar->add( 'Event Sidebar' );
		$sidebar->add( 'Testimonial Sidebar' );
		$sidebar->save();
		$sidebar->register();
	}

	/**
	 * After import data is finished it will setup data
	 * 
	 * @return void
	 */
	public function setData() {
		//preg_replace( ‘/image=\“(\d+)\“/U’, ‘image=“0”’, $postdata[‘post_content’] );\
		/**
		 * Set menus and locations
		 */
		$menus = $this->setMenus( array(
			'primary' => 'Primary Menu',
			'social' => 'Social Links Menu',
				) );
		
		/**
		 * Set megamenu item to menu
		 */
		$this->setMegamenuItem( $menus['primary'], 'Shop', 'Megamenu Item' );

		/**
		 * Set Home page
		 */
		$front_page = get_page_by_title( 'Home' );
		if ( $front_page ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $front_page->ID );
		}

		/**
		 * Set Posts page (blog page)
		 */
		$blog_page = get_page_by_title( 'Blog' );
		if ( $blog_page ) {
			update_option( 'page_for_posts', $blog_page->ID );
		}
		
		/**
		 * Set widget custom menu
		 */
		$this->setWidgetCustomMenu( 'Useful links', 'Useful links' );
	}

	/**
	 * Import Widget Custom Menu
	 * 
	 * @param string $menu_name Menu name
	 * @param string $widget_name Widget Custom Menu name
	 */
	private function setWidgetCustomMenu( $menu_name, $widget_name ) {

		$term = get_term_by( 'name', $menu_name, 'nav_menu' );

		if ( $term ) {

			$widget_nav_menu = get_option( 'widget_nav_menu' );

			$widget_nav_menu_edited = array_map( function ( $value ) use ( $term ) {

				if ( isset( $value['title'] ) && $value['title'] == $widget_name ) {

					$value['nav_menu'] = $term->term_id;

					return $value;
				}

				return $value;
			}, $widget_nav_menu );

			update_option( 'widget_nav_menu', $widget_nav_menu_edited );
		}
	}

	/**
	 * Setup menus
	 * 
	 * @param array $menus Array location and menu name
	 * @return type Description
	 */
	private function setMenus( $menus = array() ) {
		
		if ( empty( $menus ) ) {
			return array();
		}

		foreach ( $menus as $location => $name ) {

			$term = get_term_by( 'name', $name, 'nav_menu' );

			if ( $term ) {
				$menus[$location] = $term->term_id;
			} else {
				$menus[$location] = '';
			}
		}
		
		set_theme_mod( 'nav_menu_locations', $menus );

		return $menus;
	}

	/**
	 * Setup Megamenu item
	 * 
	 * @param int $menu_id Menu ID
	 * @param string $menu_item_title Item Name
	 * @param string $mega_item_title Mega Item Name
	 * 
	 * @return void
	 */
	private function setMegamenuItem( $menu_id, $menu_item_title, $mega_item_title ) {

		$item_menus = wp_get_nav_menu_items( $menu_id );

		foreach ( $item_menus as $item ) {

			if ( $item['title'] == $menu_item_title ) {

				$page = get_page_by_title( $mega_item_title, OBJECT, 'megamenu' );

				update_post_meta( $item['ID'], '_mega_menu', 1 );
				update_post_meta( $item['ID'], '_page_id', $page->ID );
			}
		}
	}

}
