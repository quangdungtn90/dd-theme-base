<?php

namespace TP_Base\Toolkit\Admin;

class ContactMethods {
	public function __construct() {
		add_filter( 'user_contactmethods', array( $this, 'addMethods' ) );
		add_action( 'tp_base\biography_extral', array( $this, 'output' ) );
	}

	public function addMethods( $methods ) {

		$arr = $this->getMethods();

		foreach ( $arr as $key => $value ) {
			$methods[ $key ] = $value['label'];
		}

		return $methods;
	}

	public function getMethods() {
		$methods = array(
			'facebook'   => array(
				'label'           => esc_html__( 'Facebook ID', 'tp-base-toolkit' ),
				'value'           => '//facebook.com/',
				'output_callback' => 'sanitize_text_field',
				'output_icon'     => 'fa fa-facebook'
			),
			'twitter'    => array(
				'label'           => esc_html__( 'Twitter ID', 'tp-base-toolkit' ),
				'value'           => '//twitter.com/',
				'output_callback' => 'sanitize_text_field',
				'output_icon'     => 'fa fa-twitter'
			),
			'googleplus' => array(
				'label'           => esc_html__( 'Google+ ID', 'tp-base-toolkit' ),
				'value'           => '//plus.google.com/u/0/',
				'output_callback' => 'sanitize_text_field',
				'output_icon'     => 'fa fa-google-plus-official'
			),
			'linkedin'   => array(
				'label'           => esc_html__( 'Linked In ID', 'tp-base-toolkit' ),
				'value'           => '//linkedin.com/in/',
				'output_callback' => 'sanitize_text_field',
				'output_icon'     => 'fa fa-linkedin'
			),
			'pinterest'  => array(
				'label'           => esc_html__( 'Pinterest ID', 'tp-base-toolkit' ),
				'value'           => '//pinterest.com/',
				'output_callback' => 'sanitize_text_field',
				'output_icon'     => 'fa fa-pinterest'
			),
			'phone'      => array(
				'label'           => esc_html__( 'Phone Number', 'tp-base-toolkit' ),
				'value'           => 'tel:',
				'output_callback' => 'tp_base_toolkit_sanitize_phone_number',
				'output_icon'     => 'fa fa-phone-square '
			)
		);

		return apply_filters( 'tp_base\toolkit\user_contact_methods', $methods );
	}

	public function output( $user_id ) {

		$arrs = $this->getMethods();
		$wp_user_contact_methods = wp_get_user_contact_methods();
		$item = '';

		foreach ( $wp_user_contact_methods as $key => $label ) {

			$value = get_user_meta( $user_id, $key, true );

			if ( empty( $value ) ) {
				continue;
			}

			$arr = $arrs[$key];

			if ( function_exists( $arr['output_callback'] ) ) {
				$value = call_user_func( $arr['output_callback'], $value );
			}

			$item .= sprintf( '<li><a href="%1$s" target="_blank" class="user-contact-method-%2$s" title="%2$s"><i class="%3$s"></i></a></li>',
				esc_url( $arr['value'] . $value ), $key, $arr['output_icon'] );

		}

		if ( $item ) {
			echo '<ul class="user-contact-methods">' . $item . '</ul>';
		}

	}
}