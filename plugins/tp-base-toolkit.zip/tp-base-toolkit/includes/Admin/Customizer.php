<?php

namespace TP_Base\Toolkit\Admin;

class Customizer {

	public function __construct() {
		add_action( 'customize_register', array( $this, 'init' ), 11 );
	}

	public $wp_customizer;

	public $sidebars;

	public function init( $wp_customizer ) {

		$this->wp_customizer = $wp_customizer;

		$nonce = array( '' => esc_attr__( '-- Select sidebar --', 'tp-base-toolkit' ) );

		$this->sidebars = tp_base_toolkit_get_sidebars( $nonce );

		$this->header();
		$this->footer();
		$this->page();
		$this->blog();
		$this->post();
		$this->typography();
		$this->socials();
		$this->apiSettings();
		$this->customCode();
	}

	public function header() {
		$header = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'header',
			'heading'     => esc_attr__( 'Header', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Setup for header, these settings can be overridden by advanced settings in category, tags, archive or post, page, post type layout...', 'tp-base-toolkit' ),
			'fields'      => array()
		) );

		$header->add_field( array(
			'name'    => 'header_options',
			'type'    => 'heading',
			'heading' => esc_html__( 'Content options', 'tp-base-toolkit' ),
		) );

		if ( class_exists( 'WooCommerce' ) ) {

			$header->add_field(
				array(
					'name'    => 'header_show_account_nav',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show account navigation', 'tp-base-toolkit' ),
					'value'   => true,
				) );

			if ( defined( 'YITH_WCWL' ) ) {
				$header->add_field(
					array(
						'name'    => 'header_show_wishlist',
						'type'    => 'checkbox',
						'heading' => esc_html__( 'Show mini wishlist', 'tp-base-toolkit' ),
						'value'   => true,
					) );
			}

			$header->add_field(
				array(
					'name'    => 'header_show_minicart',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show mini cart', 'tp-base-toolkit' ),
					'value'   => true,
				) );
		}

		$header->add_field(
			array(
				'name'    => 'header_show_topbar_link',
				'type'    => 'checkbox',
				'heading' => esc_html__( 'Show topbar links', 'tp-base-toolkit' ),
				'value'   => false,
			) );

		$header->add_field(
			array(
				'name'        => 'topbar_link',
				'type'        => 'autocomplete',
				'heading'     => esc_html__( 'Topbar menu links', 'tp-base-toolkit' ),
				'data'        => array( 'taxonomy' => array( 'nav_menu' ) ),
				'placeholder' => esc_attr__( 'Enter 3 or more characters to search...', 'tp-base-toolkit' ),
				'desc'        => esc_html__( 'Search and select a menu to display', 'tp-base-toolkit' ),
				'dependency'  => array(
					'header_show_topbar_link' => array( 'values' => true )
				)
			) );


	}

	public function footer() {

		/**
		 * Footer toolkit
		 */
		$footer = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'footer',
			'heading'     => esc_attr__( 'Footer', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Setup for footer, these settings can be overridden by advanced settings in category, tags, archive or post, page, post type layout...', 'tp-base-toolkit' ),
			'fields'      => array(
				array(
					'name'      => 'footer_style',
					'type'      => 'select',
					'heading'   => esc_html__( 'Display style', 'tp-base-toolkit' ),
					'transport' => 'refresh',
					'value'     => 'default',
					'options'   => array(
						'none'    => esc_attr__( 'Hidden', 'tp-base-toolkit' ),
						'default' => esc_attr__( 'Standard', 'tp-base-toolkit' ),
						'dark'    => esc_attr__( 'Dark', 'tp-base-toolkit' )
					)
				),
				array(
					'name'    => 'footer_widgets_label',
					'type'    => 'heading',
					'heading' => esc_html__( 'Column options', 'tp-base-toolkit' ),
				),
				array(
					'name'      => 'footer_widgets_enable',
					'type'      => 'checkbox',
					'heading'   => esc_html__( 'Show widgets area', 'tp-base-toolkit' ),
					'transport' => 'refresh',
					'value'     => true
				),
				array(
					'name'       => 'footer_sidebar_1',
					'type'       => 'select',
					'heading'    => esc_html__( 'Footer column 1', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar-footer',
					'dependency' => array(
						'footer_widgets_enable' => array( 'values' => true )
					)
				),
				array(
					'name'       => 'footer_sidebar_2',
					'type'       => 'select',
					'heading'    => esc_html__( 'Footer column 2', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar-footer-2',
					'dependency' => array(
						'footer_widgets_enable' => array( 'values' => true )
					)
				),
				array(
					'name'       => 'footer_sidebar_3',
					'type'       => 'select',
					'heading'    => esc_html__( 'Footer column 3', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar-footer-3',
					'dependency' => array(
						'footer_widgets_enable' => array( 'values' => true )
					)
				),
				array(
					'name'       => 'footer_sidebar_4',
					'type'       => 'select',
					'heading'    => esc_html__( 'Footer column 4', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar-footer-4',
					'dependency' => array(
						'footer_widgets_enable' => array( 'values' => true )
					)
				),
				array(
					'name'      => 'footer_copyright',
					'type'      => 'textarea',
					'heading'   => esc_html__( 'Site info', 'tp-base-toolkit' ),
					'value'     => wp_kses_post( sprintf( __( 'Designed and built with all the love in the world by %s', 'tp-base-toolkit' ), sprintf( '<a href="%s" target="_blank">%s</a>', esc_url( '//themespond.com/' ), esc_html__( 'ThemesPond', 'tp-base-toolkit' ) ) ) ),
					'transport' => 'postMessage',
					'partial'   => array(
						'selector'            => '.footer__copyright p',
						'render_callback'     => 'tp_base_site_info',
						'container_inclusive' => true
					)
				),
			)
		) );
	}

	public function page() {

		/**
		 * Page
		 */
		$page = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'page',
			'heading'     => esc_attr__( 'Static pages', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Setup for page, these settings can be overridden by advanced settings in individual page.', 'tp-base-toolkit' ),
			'fields'      => array(
				array(
					'name'              => 'page_breadcrumb',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
				),
				array(
					'name'       => 'page_breadcrumb_image',
					'type'       => 'image',
					'heading'    => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'dependency' => array(
						'page_breadcrumb' => array( 'values' => 'yes' )
					)
				),
				array(
					'name'              => 'page_content_spacing',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Content Spacing', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch',
					'desc'              => esc_html__( 'Using spacing top and spacing bottom for the content of the page.', 'tp-base-toolkit' )
				),
				array(
					'name'              => 'page_sidebar_position',
					'type'              => 'image_select',
					'heading'           => esc_html__( 'Sidebar Position', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'left'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
						'none'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
						'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'right',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
				),
				array(
					'name'       => 'page_sidebar',
					'type'       => 'select',
					'heading'    => esc_attr__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar',
					'dependency' => array(
						'page_sidebar_position' => array( 'values' => array( 'left', 'right' ) )
					)
				),
			)
		) );

	}

	public function blog() {

		/**
		 * Blog
		 */
		new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'blog',
			'heading'     => esc_html__( 'Blog', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Setup for blog content,  these settings can be overridden by advanced settings in category, tags, archive posts.', 'tp-base-toolkit' ),
			'fields'      => array(
				array(
					'name'              => 'blog_breadcrumb',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
				),
				array(
					'name'       => 'blog_breadcrumb_image',
					'type'       => 'image',
					'heading'    => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'dependency' => array(
						'blog_breadcrumb' => array( 'values' => 'yes' )
					)
				),
				array(
					'name'              => 'blog_sidebar_position',
					'type'              => 'image_select',
					'heading'           => esc_html__( 'Sidebar Position', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'left'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
						'none'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
						'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'right',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
				),
				array(
					'name'      => 'blog_sidebar',
					'type'      => 'select',
					'heading'   => esc_attr__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport' => 'refresh',
					'options'   => $this->sidebars,
					'value'     => 'sidebar',
				),
				array(
					'name'    => 'blog_label_content_options',
					'type'    => 'heading',
					'heading' => esc_html__( 'Content Options', 'tp-base-toolkit' ),
				),
				array(
					'name'      => 'blog_show_author',
					'type'      => 'checkbox',
					'multiple'  => false,
					'heading'   => esc_html__( 'Show author link', 'tp-base-toolkit' ),
					'transport' => 'refresh',
					'value'     => 1,
				),
				array(
					'name'      => 'blog_show_date',
					'type'      => 'checkbox',
					'multiple'  => false,
					'heading'   => esc_html__( 'Show posted date', 'tp-base-toolkit' ),
					'transport' => 'refresh',
					'value'     => 1,
				),
				array(
					'name'      => 'blog_show_comment_count',
					'type'      => 'checkbox',
					'multiple'  => false,
					'heading'   => esc_html__( 'Show comment count', 'tp-base-toolkit' ),
					'transport' => 'refresh',
					'value'     => 1,
				),
				array(
					'name'      => 'blog_show_sharing',
					'type'      => 'checkbox',
					'multiple'  => false,
					'heading'   => esc_html__( 'Show sharing', 'tp-base-toolkit' ),
					'transport' => 'refresh',
					'value'     => 1,
				),
				array(
					'name'      => 'blog_morelink',
					'type'      => 'checkbox',
					'multiple'  => false,
					'heading'   => esc_html__( 'Show more link', 'tp-base-toolkit' ),
					'transport' => 'refresh',
					'value'     => 1,
				),
			)
		) );

	}

	public function post() {

		/**
		 * Blog detail
		 */
		$post = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'post',
			'heading'     => esc_html__( 'Blog detail', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Settings for article,  these settings can be overridden by advanced settings in individual articles.', 'tp-base-toolkit' ),
			'fields'      => array(
				array(
					'name'              => 'post_breadcrumb',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
				),
				array(
					'name'       => 'post_breadcrumb_image',
					'type'       => 'image',
					'heading'    => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'dependency' => array(
						'post_breadcrumb' => array( 'values' => 'yes' )
					)
				),
				array(
					'name'              => 'post_sidebar_position',
					'type'              => 'image_select',
					'heading'           => esc_html__( 'Sidebar position', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'left'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
						'none'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
						'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'right',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
				),
				array(
					'name'      => 'post_sidebar',
					'type'      => 'select',
					'heading'   => esc_attr__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport' => 'refresh',
					'options'   => $this->sidebars,
					'value'     => 'sidebar',
				),
				array(
					'name'    => 'post_content_option_label',
					'type'    => 'heading',
					'heading' => esc_html__( 'Content Options', 'tp-base-toolkit' )
				),
				array(
					'name'    => 'post_author_link',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show author link', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'post_on',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show posted date', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'post_comment_count',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show comment count', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'post_categories',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show categories', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'post_tags',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show tags', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'post_share',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show social sharing', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'post_nav',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show post navigation', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'post_related',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show related posts', 'tp-base-toolkit' ),
				),
				array(
					'name'       => 'post_related_get_by',
					'type'       => 'select',
					'heading'    => esc_html__( 'Related options', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => array(
						'category' => esc_attr__( 'Category', 'tp-base-toolkit' ),
						'tags'     => esc_attr__( 'Tags', 'tp-base-toolkit' )
					),
					'value'      => 'category',
					'dependency' => array(
						'post_related' => array( 'values' => 1 )
					),
				),
				array(
					'name'              => 'post_related_limit',
					'type'              => 'text',
					'heading'           => esc_html__( 'Releated limit number', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'value'             => 3,
					'sanitize_callback' => 'absint',
					'dependency'        => array(
						'post_related' => array( 'values' => 1 )
					),
				)
			)
		) );
	}

	public function typography() {
		$typography = new \Tpfw_Customize_Section( $this->wp_customizer, array(
				'id'          => 'typography',
				'heading'     => esc_html__( 'Typography', 'tp-base-toolkit' ),
				'description' => esc_html__( 'Font family resource for the theme.', 'tp-base-toolkit' ),
				'priority'    => 55,
				'fields'      => array(
					array(
						'name'      => 'typography_enable',
						'type'      => 'checkbox',
						'heading'   => esc_html__( 'Enable customize fonts?', 'tp-base-toolkit' ),
						'transport' => 'refresh',
						'value'     => 0
					),
					array(
						'name'       => 'primary_font',
						'type'       => 'typography',
						'heading'    => esc_html__( 'Primary font', 'tp-base-toolkit' ),
						'transport'  => 'refresh',
						'desc'       => esc_html__( 'Primary font is used for text content, paragraph or description in the theme.', 'tp-base-toolkit' ),
						'dependency' => array(
							'typography_enable' => array( 'values' => 1 )
						)
					),
					array(
						'name'       => 'secondary_font',
						'type'       => 'typography',
						'heading'    => esc_html__( 'Secondary font', 'tp-base-toolkit' ),
						'transport'  => 'refresh',
						'desc'       => esc_html__( 'Secondary font is used for heading, title in the theme.', 'tp-base-toolkit' ),
						'dependency' => array(
							'typography_enable' => array( 'values' => 1 )
						)
					)
				)
			)
		);
	}

	public function socials() {

		$social_options = tp_base_toolkit_social_list();

		$social_options = array_map( function ( $value ) {
			return $value['text'];
		}, $social_options );

		new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'                 => 'section_social',
			'heading'            => esc_html__( 'Social manager', 'tp-base-toolkit' ),
			'description_hidden' => false,
			'description'        => esc_html__( 'The social manager is used for customers who want to share posts, products or any url on this site to their social networks.', 'tp-base' ),
			'priority'           => 57,
			'fields'             => array(
				array(
					'name'     => 'socials',
					'type'     => 'select',
					'heading'  => esc_html__( 'Socials sharing', 'tp-base-toolkit' ),
					'multiple' => 1,
					'options'  => $social_options,
					'desc'     => esc_html__( 'Select and short social items.', 'tp-base-toolkit' ),
					'value'    => array( 'facebook', 'twitter', 'gplus' )
				)
			)
		) );
	}

	public function apiSettings() {

		/**
		 * Add panel API Settings
		 */
		$panel = new \Tpfw_Customize_Panel( $this->wp_customizer, array(
			'id'       => 'api_settings',
			'title'    => esc_html__( 'API Settings', 'tp-base-toolkit' ),
			'priority' => 161,
		) );


		/**
		 * Add section Goolge Map
		 */
		$panel->add_section( array(
			'id'      => 'api_gmap',
			'heading' => esc_attr__( 'Google map', 'tp-base-toolkit' ),
			'fields'  => array( //Fields in section
				array(
					'name'  => 'gmap_api_key',
					'type'  => 'text',
					'desc'  => esc_html__( 'Gmap API', 'tp-base-toolkit' ),
					'value' => '',
					'desc'  => sprintf( wp_kses_post( __( 'To find your API Key, please %s', 'tp-base-toolkit' ) ), '<a href="//developers.google.com/maps/documentation/javascript/get-api-key" target="_blank"> ' . esc_html__( 'click here', 'tp-base-toolkit' ) . ' </a>' ),
				),
			)
		) );

		/**
		 * Add section Instagram
		 */
		$panel->add_section( array(
			'id'      => 'api_instagram',
			'heading' => esc_attr__( 'Instagram', 'tp-base-toolkit' ),
			'fields'  => array( //Fields in section
				array(
					'name'  => 'instagram_access_token',
					'type'  => 'text',
					'desc'  => esc_html__( 'Instagram access token', 'tp-base-toolkit' ),
					'value' => '',
					'desc'  => sprintf( wp_kses_post( __( 'To find your Access token, you can use %s.', 'tp-base-toolkit' ) ), '<a href="//instagram.pixelunion.net/" target="_blank"> ' . esc_html__( 'this tool', 'tp-base-toolkit' ) . ' </a>' ),
				),
				array(
					'name'  => 'instagram_user_id',
					'type'  => 'text',
					'desc'  => esc_html__( 'Instagram user ID', 'tp-base-toolkit' ),
					'value' => '',
					'desc'  => sprintf( wp_kses_post( __( 'To find your User ID, you can use %s.', 'tp-base-toolkit' ) ), '<a href="//smashballoon.com/instagram-feed/find-instagram-user-id/" target="_blank"> ' . esc_html__( 'this tool', 'tp-base-toolkit' ) . ' </a>' )
				),
				array(
					'name'              => 'instagram_number_photo',
					'type'              => 'text',
					'desc'              => esc_html__( 'Instagram number of photo', 'tp-base-toolkit' ),
					'value'             => 6,
					'sanitize_callback' => 'absint'
				),
			)
		) );

		/**
		 * Add section Twitter
		 */
		$panel->add_section( array(
			'id'          => 'api_twitter',
			'heading'     => esc_attr__( 'Twitter', 'tp-base-toolkit' ),
			'description' => sprintf( wp_kses_post( __( 'Create an app in %s and get all keys are listed bellow.', 'tp-base-toolkit' ) ), '<a href="//apps.twitter.com/" target="_blank"> ' . esc_html__( 'Twitter Application', 'tp-base-toolkit' ) . ' </a>' ),
			'fields'      => array( //Fields in section
				array(
					'name'  => 'api_twitter_consumer_key',
					'type'  => 'text',
					'desc'  => esc_html__( 'Twitter consumer key', 'tp-base-toolkit' ),
					'value' => '',
				),
				array(
					'name'  => 'api_twitter_consumer_secret',
					'type'  => 'text',
					'desc'  => esc_html__( 'Twitter consumer secret', 'tp-base-toolkit' ),
					'value' => '',
				),
				array(
					'name'  => 'api_twitter_access_token',
					'type'  => 'text',
					'desc'  => esc_html__( 'Twitter access token', 'tp-base-toolkit' ),
					'value' => '',
				),
				array(
					'name'  => 'api_twitter_access_token_secret',
					'type'  => 'text',
					'desc'  => esc_html__( 'Twitter access token secret', 'tp-base-toolkit' ),
					'value' => '',
				),
			)
		) );
	}

	public function customCode() {

		new \Tpfw_Customize_Section( $this->wp_customizer, array(
				'id'                 => 'section_custom_js',
				'heading'            => esc_html__( 'Additional JS', 'tp-base-toolkit' ),
				'description_hidden' => true,
				'priority'           => 161,
				'description'        => esc_html__( 'Allows you to write Javascript code to footer of your website. Separate Javascript is saved for each of your themes. In the editing area the Tab key enters a tab character. To move below this area by pressing Tab, press the Esc key followed by the Tab key.', 'tp-base-toolkit' ),
				'fields'             => array(
					array(
						'name'        => 'custom_js',
						'type'        => 'textarea',
						'value'       => sprintf( "/*\n%s\n*/", esc_html( __( "You can add your own Javascript code here.\n\nClick the help icon above to learn more.", 'tp-base-toolkit' ) ) ),
						'heading'     => '',
						'transport'   => 'postMessage',
						'input_attrs' => array(
							'class' => 'custom_code', // Ensures contents displayed as LTR instead of RTL.
						),
					)
				)
			)
		);
	}

}
