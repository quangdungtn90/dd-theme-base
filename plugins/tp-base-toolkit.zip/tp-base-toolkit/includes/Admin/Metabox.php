<?php

namespace TP_Base\Toolkit\Admin;

class Metabox {

	public function __construct() {

		add_action( 'tpfw_metabox_init', array( $this, 'advancedPostBox' ) );
		add_action( 'tpfw_metabox_init', array( $this, 'advancedPageBox' ) );
		add_action( 'tpfw_metabox_init', array( $this, 'advancedBlogPage' ) );
		add_action( 'tpfw_termbox_init', array( $this, 'advancedPostList' ) );
	}

	protected function footerArgs() {

		$sidebars = array(
			'none' => esc_attr__( '--None--', 'tp-base-toolkit' ),
			'' => esc_attr__( 'Inherit from customizer', 'tp-base-toolkit' )
		);

		$sidebars = tp_base_toolkit_get_sidebars( $sidebars );

		$args = array(
			//Sidebar
			array(
				'name' => '_sidebar_position',
				'type' => 'image_select',
				'heading' => esc_html__( 'Sidebar position', 'tp-base-toolkit' ),
				'options' => array(
					'left' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
					'none' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
					'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
				),
				'value' => 'right',
				'group' => esc_html__( 'Sidebar', 'tp-base-toolkit' ),
				'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
			),
			array(
				'name' => '_sidebar',
				'type' => 'select',
				'heading' => esc_html__( 'Sidebar', 'tp-base-toolkit' ),
				'options' => $sidebars,
				'value' => '',
				'group' => esc_html__( 'Sidebar', 'tp-base-toolkit' )
			),
			//Footer
			array(
				'name' => '_footer_style',
				'type' => 'select',
				'heading' => esc_html__( 'Display style', 'tp-base-toolkit' ),
				'options' => array(
					'' => esc_attr__( 'Inherit from customizer', 'tp-base-toolkit' ),
					'none' => esc_attr__( 'Hidden', 'tp-base-toolkit' ),
					'default' => esc_attr__( 'Standard', 'tp-base-toolkit' ),
					'dark' => esc_attr__( 'Dark', 'tp-base-toolkit' )
				),
				'value' => 'right',
				'group' => esc_html__( 'Footer', 'tp-base-toolkit' )
			),
			array(
				'name' => '_footer_sidebar',
				'type' => 'checkbox',
				'heading' => esc_html__( 'Show widgets area', 'tp-base-toolkit' ),
				'value' => true,
				'group' => esc_html__( 'Footer', 'tp-base-toolkit' )
			),
			array(
				'name' => '_sidebar_footer_1',
				'type' => 'select',
				'heading' => esc_html__( 'Footer column 1', 'tp-base-toolkit' ),
				'options' => $sidebars,
				'value' => '',
				'group' => esc_html__( 'Footer', 'tp-base-toolkit' )
			),
			array(
				'name' => '_sidebar_footer_2',
				'type' => 'select',
				'heading' => esc_html__( 'Footer column 2', 'tp-base-toolkit' ),
				'options' => $sidebars,
				'value' => '',
				'group' => esc_html__( 'Footer', 'tp-base-toolkit' )
			),
			array(
				'name' => '_sidebar_footer_3',
				'type' => 'select',
				'heading' => esc_html__( 'Footer column 3', 'tp-base-toolkit' ),
				'options' => $sidebars,
				'value' => '',
				'group' => esc_html__( 'Footer', 'tp-base-toolkit' )
			),
			array(
				'name' => '_sidebar_footer_4',
				'type' => 'select',
				'heading' => esc_html__( 'Footer column 4', 'tp-base-toolkit' ),
				'options' => $sidebars,
				'value' => '',
				'group' => esc_html__( 'Footer', 'tp-base-toolkit' )
			),
		);

		return $args;
	}

	/**
	 * Advanded box settings in single post
	 * @since 1.0
	 * @return void
	 */
	public function advancedPostBox() {

		$fields = array(
			array(
				'name' => '_breadcrumb',
				'type' => 'radio',
				'heading' => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
				'options' => array(
					'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
					'no' => esc_attr__( 'Disable', 'tp-base-toolkit' ),
				),
				'display_inline' => true,
				'value' => 'yes',
				'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
			),
			array(
				'name' => '_breadcrumb_image',
				'type' => 'image_picker',
				'heading' => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
				'desc' => esc_html__( 'Select a background image for breadcrumb.', 'tp-base-toolkit' ),
			),
			array(
				'name' => '_content_options',
				'type' => 'checkbox',
				'multiple' => true,
				'heading' => esc_html__( 'Content Options', 'tp-base-toolkit' ),
				'options' => array(
					'post_author' => esc_attr__( 'Show author link', 'tp-base-toolkit' ),
					'post_on' => esc_attr__( 'Show posted on', 'tp-base-toolkit' ),
					'post_comment_count' => esc_attr__( 'Show comment count', 'tp-base-toolkit' ),
					'post_categories' => esc_attr__( 'Show categories', 'tp-base-toolkit' ),
					'post_tags' => esc_attr__( 'Show tags', 'tp-base-toolkit' ),
					'post_share' => esc_attr__( 'Show social sharing', 'tp-base-toolkit' ),
					'post_biography' => esc_attr__( 'Show biography', 'tp-base-toolkit' ),
					'post_nav' => esc_attr__( 'Show post navigation', 'tp-base-toolkit' ),
					'post_related' => esc_attr__( 'Related posts', 'tp-base-toolkit' ),
				),
				'value' => array(
					'post_author',
					'post_on',
					'post_comment_count',
					'post_categories',
					'post_tags',
					'post_nav',
					'post_related',
					'post_share',
					'post_biography'
				),
				'desc' => esc_html__( 'Show or hide content options in this post.', 'tp-base-toolkit' ),
			),
			array(
				'name' => '_related_get_by',
				'type' => 'select',
				'heading' => esc_attr__( 'Releated post options', 'tp-base-toolkit' ),
				'options' => array(
					'category' => esc_attr__( 'Category', 'tp-base-toolkit' ),
					'tags' => esc_attr__( 'Tags', 'tp-base-toolkit' ),
					'ids' => esc_attr__( 'Linked Posts', 'tp-base-toolkit' )
				),
				'value' => 'category',
				'dependency' => array(
					'_content_options' => array( 'values' => 'post_related' ),
				),
			),
			array(
				'name' => '_related_limit',
				'type' => 'textfield',
				'heading' => esc_attr__( 'Releated limit number', 'tp-base-toolkit' ),
				'value' => 3,
				'size' => 'small',
				'dependency' => array(
					'_related_get_by' => array( 'values' => array( 'category', 'tags' ) ),
					'_content_options' => array( 'values' => 'post_related' ),
				),
			),
			array(
				'name' => '_related_ids',
				'type' => 'autocomplete',
				'multiple' => 1,
				'heading' => esc_attr__( 'Linked posts', 'tp-base-toolkit' ),
				'data' => array( 'post_type' => array( 'post' ) ),
				'dependency' => array(
					'_related_get_by' => array( 'values' => array( 'ids' ) ),
					'_content_options' => array( 'values' => 'post_related' ),
				),
			),
		);

		$fields2 = $this->footerArgs();

		$fields = array_merge( $fields, $fields2 );

		$box = new \Tpfw_Metabox( array(
			'id' => '_advanced_settings',
			'screens' => array( 'post' ), //Display in post, page, front_page, posts_page
			'heading' => esc_html__( 'Advanced Settings', 'tp-base-toolkit' ),
			'context' => 'advanced', //side
			'priority' => 'low',
			'manage_box' => true,
			'fields' => $fields
				) );
	}

	private function postListFields() {

		$fields2 = $this->footerArgs();

		$fields = array(
			array(
				'name' => '_breadcrumb',
				'type' => 'radio',
				'heading' => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
				'options' => array(
					'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
					'no' => esc_attr__( 'Disable', 'tp-base-toolkit' ),
				),
				'display_inline' => true,
				'value' => 'yes',
				'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
			),
			array(
				'name' => '_breadcrumb_image',
				'type' => 'image_picker',
				'heading' => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
				'desc' => esc_html__( 'Select a background image for breadcrumb.', 'tp-base-toolkit' )
			),
			array(
				'name' => '_content_options',
				'type' => 'checkbox',
				'multiple' => true,
				'heading' => esc_html__( 'Content Options', 'tp-base-toolkit' ),
				'options' => array(
					'post_author' => esc_attr__( 'Show author link', 'tp-base-toolkit' ),
					'post_on' => esc_attr__( 'Show posted on', 'tp-base-toolkit' ),
					'post_comment_count' => esc_attr__( 'Show comment count', 'tp-base-toolkit' ),
					'post_share' => esc_attr__( 'Show social sharing', 'tp-base-toolkit' ),
					'morelink' => esc_attr__( 'Show more link', 'tp-base-toolkit' ),
				),
				'value' => array(
					'post_author',
					'post_on',
					'post_comment_count',
					'post_share',
					'morelink'
				),
				'desc' => esc_html__( 'Show or hide content option in this category', 'tp-base-toolkit' ),
			)
		);

		return array_merge( $fields, $fields2 );
	}

	/**
	 * Advanded box settings in category
	 * @since 1.0
	 * @return void
	 */
	public function advancedPostList() {

		new \Tpfw_Taxonomy( array(
			'id' => '_advanced_settings',
			'pages' => array( 'category', 'post_tag' ), //Display in category screen
			'heading' => esc_html__( 'Advanced Settings', 'tp-base-toolkit' ),
			'context' => 'advanced', //side
			'priority' => 'low',
			'manage_box' => true,
			'fields' => $this->postListFields()
				) );
	}

	/**
	 * Advanded box settings in page
	 * @since 1.0
	 * @return void
	 */
	public function advancedPageBox() {

		$fields2 = $this->footerArgs();

		$fields = array(
			array(
				'name' => '_breadcrumb',
				'type' => 'radio',
				'heading' => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
				'display_inline' => true,
				'options' => array(
					'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
					'no' => esc_attr__( 'Disable', 'tp-base-toolkit' ),
				),
				'display_inline' => true,
				'value' => 'yes',
				'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
			),
			array(
				'name' => '_breadcrumb_image',
				'type' => 'image_picker',
				'heading' => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
				'desc' => esc_html__( 'Select a background image for breadcrumb.', 'tp-base-toolkit' )
			),
			array(
				'name' => '_content_title',
				'type' => 'radio',
				'display_inline' => true,
				'heading' => esc_html__( 'Show title', 'tp-base-toolkit' ),
				'value' => 1,
				'sanitize_callback' => 'absint',
				'options' => array(
					1 => esc_attr__( 'Enable', 'tp-base-toolkit' ),
					0 => esc_attr__( 'Disable', 'tp-base-toolkit' ),
				)
			),
			array(
				'name' => '_content_spacing',
				'type' => 'radio',
				'display_inline' => true,
				'heading' => esc_html__( 'Content Spacing', 'tp-base-toolkit' ),
				'options' => array(
					'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
					'no' => esc_attr__( 'Disable', 'tp-base-toolkit' ),
				),
				'value' => 'yes',
				'sanitize_callback' => 'tp_base_toolkit_sanitize_switch',
				'desc' => esc_html__( 'Using spacing top and spacing bottom for the content of the page.', 'tp-base-toolkit' )
			),
		);

		$fields = array_merge( $fields, $fields2 );

		new \Tpfw_Metabox( array(
			'id' => '_advanced_settings',
			'screens' => array( 'page' ),
			'heading' => esc_html__( 'Advanced Settings', 'tp-base-toolkit' ),
			'context' => 'advanced', //side
			'priority' => 'low',
			'manage_box' => true,
			'fields' => $fields
				) );
	}

	/**
	 * Advanded box settings in blog posts page
	 * @since 1.0
	 * @return void
	 */
	public function advancedBlogPage() {

		new \Tpfw_Metabox( array(
			'id' => '_advanced_settings',
			'screens' => array( 'posts_page' ),
			'heading' => esc_html__( 'Advanced Settings', 'tp-base-toolkit' ),
			'context' => 'advanced', //side
			'priority' => 'low',
			'manage_box' => true,
			'fields' => $this->postListFields()
				) );
	}

}
