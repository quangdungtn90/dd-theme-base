<?php

namespace TP_Base\Toolkit\Vc;

/**
 * Display posts - a Visual Composer Addon
 *
 * @package     Tp_Base
 * @subpackage  Tp_Base Toolkit
 * @category    VC
 * @author      ThemesPond
 * @license     GPLv3
 *
 * @since 1.0
 */
class Posts extends VcBase {

	private $id = 'tp_base_posts';

	public function __construct() {

		add_shortcode( $this->id, array( $this, 'render' ) );
		add_action( 'tp_base\toolkit\vc_map', array( $this, 'form' ), 10, 2 );

		// Categories
		add_filter( 'vc_autocomplete_' . $this->id . '_categories_callback', array( $this, 'categories_search' ), 10, 1 );
		add_filter( 'vc_autocomplete_' . $this->id . '_categories_render', array( $this, 'categories_render' ), 10, 1 );

		// Tags
		add_filter( 'vc_autocomplete_' . $this->id . '_tags_callback', array( $this, 'tags_search' ), 10, 1 );
		add_filter( 'vc_autocomplete_' . $this->id . '_tags_render', array( $this, 'tags_render' ), 10, 1 );

		// Posts
		add_filter( 'vc_autocomplete_' . $this->id . '_include_callback', array( $this, 'posts_search' ), 10, 1 );
		add_filter( 'vc_autocomplete_' . $this->id . '_include_render', array( $this, 'posts_render' ), 10, 1 );
	}

	public function form( $action, $tag ) {

		if ( $action == 'vc_edit_form' && $tag != $this->id ) {
			return;
		}

		vc_map( array(
			'name' => esc_html__( '[TP Base] Posts', 'tp-base-toolkit' ),
			'base' => $this->id,
			'category' => esc_html__( 'TP Base', 'tp-base-toolkit' ),
			'icon' => '',
			'params' => array(
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Data source', 'tp-base-toolkit' ),
					'param_name' => 'datasource',
					'admin_label' => true,
					'value' => array(
						esc_html__( 'Custom Query', 'tp-base-toolkit' ) => 'query',
						esc_html__( 'List of IDs', 'tp-base-toolkit' ) => 'ids'
					),
					'save_always' => true,
				),
				array(
					'type' => 'autocomplete',
					'heading' => esc_html__( 'List Of Posts:', 'tp-base-toolkit' ),
					'param_name' => 'include',
					'admin_label' => true,
					'description' => esc_html__( 'Display selected posts.', 'tp-base-toolkit' ),
					'settings' => array(
						'multiple' => true,
						'sortable' => true,
					),
					'save_always' => true,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'ids',
					),
				),
				array(
					'type' => 'autocomplete',
					'heading' => esc_html__( 'Select categories', 'tp-base-toolkit' ),
					'param_name' => 'categories',
					'settings' => array(
						'multiple' => true,
						'sortable' => true,
					),
					'save_always' => true,
					'description' => esc_html__( 'Display posts by categories', 'tp-base-toolkit' ),
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Relation', 'tp-base-toolkit' ),
					'param_name' => 'relation',
					'admin_label' => true,
					'value' => array(
						esc_html__( 'OR', 'tp-base-toolkit' ) => 'or',
						esc_html__( 'AND', 'tp-base-toolkit' ) => 'and'
					),
					'save_always' => true,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
				),
				array(
					'type' => 'autocomplete',
					'heading' => esc_html__( 'Select tags', 'tp-base-toolkit' ),
					'param_name' => 'tags',
					'admin_label' => true,
					'settings' => array(
						'multiple' => true,
					),
					'save_always' => true,
					'description' => esc_html__( 'Display posts by tags.', 'tp-base-toolkit' ),
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Order by', 'tp-base-toolkit' ),
					'param_name' => 'orderby',
					'admin_label' => true,
					'value' => array_flip( tp_base_toolkit_get_post_orders() ),
					'save_always' => true,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Order', 'tp-base-toolkit' ),
					'param_name' => 'order',
					'admin_label' => true,
					'value' => array(
						esc_html__( 'DESC', 'tp-base-toolkit' ) => 'desc',
						esc_html__( 'ASC', 'tp-base-toolkit' ) => 'asc',
					),
					'save_always' => true,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of displayed posts', 'tp-base-toolkit' ),
					'param_name' => 'posts_per_page',
					'value' => 5,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
					'edit_field_class' => 'vc_col-sm-6',
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Number of offset posts', 'tp-base-toolkit' ),
					'param_name' => 'offset',
					'value' => 0,
					'dependency' => array(
						'element' => 'datasource',
						'value' => 'query',
					),
					'edit_field_class' => 'vc_col-sm-6',
				),
			),
		) );
	}

	public function render( $atts ) {

		$atts = wp_parse_args( $atts, array(
			'datasource' => 'query',
			'include' => '',
			'categories' => '',
			'relation' => '',
			'tags' => '',
			'orderby' => 'date',
			'order' => 'desc',
			'posts_per_page' => 5,
			'offset' => 0
				) );

		$args = tp_base_toolkit_query( 'post', $atts );

		$atts['query'] = new \WP_Query( $args );

		return tp_base_toolkit_get_template( 'vc/posts', $atts );
	}

}
