<?php

namespace TP_Base\Toolkit\Vc;

/**
 * Display google map - a Visual Composer Addon
 *
 * @package     TP_Base
 * @subpackage  TP_Base\Toolkit
 * @author      ThemesPond
 * @license     GPLv3
 *
 * @since 1.0
 */
class Map {

	public $id = 'tp_base_map';

	public function __construct() {

		add_shortcode( $this->id, array( $this, 'render' ) );
		add_action( 'tp_base\toolkit\vc_map', array( $this, 'form' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueueScripts' ) );
	}

	/**
	 * Display form in admin
	 */
	public function form( $action, $tag = '' ) {

		if ( $action == 'vc_edit_form' && $tag != $this->id ) {
			return;
		}
		
		vc_map( array(
			'name' => esc_html__( '[TP Base] Map', 'tp-base-toolkit' ),
			'base' => $this->id,
			'category' => esc_html__( 'TP Base', 'tp-base-toolkit' ),
			'icon' => '',
			'admin_enqueue_js' => '',
			'admin_enqueue_css' => '',
			'params' => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'tp-base-toolkit' ),
					'param_name' => 'title',
					'value' => '',
					'admin_label' => true
				),
				array(
					'type' => 'textarea',
					'heading' => esc_html__( 'Description', 'tp-base-toolkit' ),
					'param_name' => 'description',
					'value' => '',
					'description' => esc_html__( 'It will be displayed when user click on Map Marker in Window Info.', 'tp-base-toolkit' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Map location', 'tp-base-toolkit' ),
					'param_name' => 'location',
					'value' => '',
					'description' => wp_kses_post( sprintf( __( 'Visit %s to create your map (Step by step: 1) Find location 2) Click on destination 3) A location (lat,lng) will be displayed at bottom map 4) Copy lat lng and paste it.', 'tp-base-toolkit' ), '<a href="//www.google.com/maps" target="_blank">Google Map</a>' ) )
				),
				array(
					'type' => 'attach_image',
					'heading' => esc_html__( 'Custom Marker', 'tp-base-toolkit' ),
					'param_name' => 'icon',
					'description' => esc_html__( 'Choose an image Marker Icon to display on map.', 'tp-base-toolkit' ),
					'value' => '',
					'group' => esc_html__( 'Settings', 'tp-base-toolkit' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Map height', 'tp-base-toolkit' ),
					'param_name' => 'height',
					'value' => '',
					'edit_field_class' => 'vc_col-sm-6',
					'description' => esc_html__( 'Enter map height (in pixels or leave empty for responsive map).', 'tp-base-toolkit' ),
					'group' => esc_html__( 'Settings', 'tp-base-toolkit' )
				),
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Map zoom', 'tp-base-toolkit' ),
					'param_name' => 'height',
					'value' => 15,
					'edit_field_class' => 'vc_col-sm-6',
					'description' => esc_html__( 'Enter map zoom (from 3 to 21), it must be a number.', 'tp-base-toolkit' ),
					'group' => esc_html__( 'Settings', 'tp-base-toolkit' )
				),
				array(
					'type' => 'dropdown',
					'heading' => esc_html__( 'Map style', 'tp-base-toolkit' ),
					'param_name' => 'style',
					'value' => $this->styleOpts(),
					'edit_field_class' => 'vc_col-sm-12',
					'group' => esc_html__( 'Settings', 'tp-base-toolkit' )
				),
				array(
					'type' => 'textarea_safe',
					'heading' => esc_html__( 'Create a map style', 'to-base-toolkit' ),
					'param_name' => 'style_custom',
					'value' => '',
					'description' => sprintf( __( 'Please %s, export JSON then copy and paste it in the box. ', 'tp-base-toolkit' ), '<a href="//mapstyle.withgoogle.com/" target="_blank">' . esc_html__( 'Create a Map Style', 'tp-base-toolkit' ) . '</a>' ),
					'group' => esc_html__( 'Settings', 'tp-base-toolkit' ),
					'dependency' => array(
						'element' => 'style',
						'value' => array( 'customize' )
					)
				)
			),
		) );
	}

	/**
	 * Render output
	 */
	public function render( $atts ) {

		$atts = wp_parse_args( $atts, array(
			'title' => '',
			'description' => '',
			'location' => '',
			'height' => '500px',
			'zoom' => 15,
			'icon' => '',
			'lat' => '',
			'lng' => '',
			'style' => '',
			'style_custom' => ''
				) );

		$latlgn = explode( ',', $atts['location'] );

		if ( isset( $latlgn[1] ) ) {
			$atts['lat'] = $latlgn[0];
			$atts['lng'] = $latlgn[1];
			unset( $atts['location'] );
		}

		if ( !empty( $atts['icon'] ) ) {
			$atts['icon'] = wp_get_attachment_image_url( $atts['icon'] );
		}

		if ( $atts['style'] == 'customize' ) {
			$atts['style'] = vc_value_from_safe( $atts['style_custom'], true );
			unset( $atts['style_custom'] );
		} else {
			$atts['style'] = $this->getMapStyle( $atts['style'] );
		}

		$data_attrs = array();
		foreach ( $atts as $key => $value ) {
			$data_attrs[] = sprintf( 'data-%s="%s"', $key, esc_attr( trim( $value ) ) );
		}

		$atts['data'] = $data_attrs;

		return tp_base_toolkit_get_template( 'vc/map', $atts );
	}

	/**
	 * Enqueue script for the shortcode
	 */
	public function enqueueScripts() {
		global $post;
		if ( $post && $post->post_type == 'page' && has_shortcode( $post->post_content, $this->id ) ) {
			wp_enqueue_script( 'google-map-v-3' );
		}
	}

	public function getMapStyle( $key ) {
		$arr = tp_base_toolkit_get_map_styles();
		$style = '';
		if ( isset( $arr[$key] ) ) {
			$style = $arr[$key]['configs'];
		}

		return $style;
	}

	public function styleOpts() {
		$arr = tp_base_toolkit_get_map_styles();
		$new = array();
		foreach ( $arr as $key => $value ) {
			$new[$value['name']] = $key;
		}

		$new[__( 'Create custom style', 'tp-base-toolkit' )] = 'customize';

		return $new;
	}

}
