<?php

namespace TP_Base\Toolkit\Vc;

/**
 * A demo Visual Composer Addon, please remove it in published products
 * 
 * @package     TP_Base
 * @subpackage  TP_Base\Toolkit
 * @author      ThemesPond
 * @license     GPLv3
 * 
 * @since 1.0
 */
class Block {

	public $id = 'tp_base_block';

	public function __construct() {

		add_shortcode( $this->id, array( $this, 'render' ) );
		add_action( 'tp_base\toolkit\vc_map', array( $this, 'form' ), 10,2 );
	}

	/**
	 * Display form in admin
	 */
	public function form( $action, $tag ) {

		if ( $action == 'vc_edit_form' && $tag != $this->id ) {
			return;
		}
		
		vc_map( array(
			'name' => esc_html__( '[TP Base] Block', 'tp-base-toolkit' ),
			'base' => $this->id,
			'category' => esc_html__( 'TP Base', 'tp-base-toolkit' ),
			'icon' => '',
			'admin_enqueue_js' => '',
			'admin_enqueue_css' => '',
			"params" => array(
				array(
					'type' => 'textfield',
					'heading' => esc_html__( 'Title', 'tp-base-toolkit' ),
					'param_name' => 'title',
					'value' => '',
					'admin_label' => true
				),
				array(
					'type' => 'textarea',
					'heading' => esc_html__( 'Description', 'tp-base-toolkit' ),
					'param_name' => 'description',
					'value' => '',
				),
				array(
					'type' => 'attach_image',
					'heading' => esc_html__( 'Background image', 'tp-base-toolkit' ),
					'param_name' => 'image',
					'description' => esc_html__( 'Choose background image for banner', 'tp-base-toolkit' ),
					'value' => array(),
				),
			),
		) );
	}

	/**
	 * Render output
	 */
	public function render( $atts ) {

		$atts = wp_parse_args( $atts, array(
			'title' => '',
			'description' => '',
			'image' => ''
				) );

		return tp_base_toolkit_get_template( 'vc/block', $atts );
	}

}
