<?php

namespace TP_Base\Toolkit\Vc;

abstract class VcBase {

	/**
	 * Autocomplete search term for post categories
	 * For Visual Composer Autocomplete Param
	 * Provide suggestion result
	 * 
	 * @param string $search_string
	 * @return array categories suggestion result
	 */
	public function categories_search( $search_string ) {
		$data = array();

		$terms = get_terms( array(
			'taxonomy' => 'category',
			'hide_empty' => false,
			'search' => $search_string
				) );

		if ( !empty( $terms ) && is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$data[] = array(
					'label' => $term->name,
					'value' => $term->slug,
					'group_id' => $term->taxonomy,
				);
			}
		}

		return $data;
	}

	/**
	 * Autocomplete render term for post categories
	 * For Visual Composer Autocomplete Param
	 * Display term item as a label
	 * 
	 * @param array $query
	 * @return array categories suggestion result
	 */
	public function categories_render( $query ) {

		$term = get_term_by( 'slug', $query['value'], 'category' );

		if ( $term ) {
			$query['label'] = $term->name;
		}

		return $query;
	}

	/**
	 * Autocomplete search term for post tags
	 * For Visual Composer Autocomplete Param
	 * Provide suggestion result
	 * 
	 * @param string $search_string
	 * @return array tags suggestion result
	 */
	public function tags_search( $search_string ) {

		$data = array();

		$terms = get_terms( array(
			'taxonomy' => 'post_tag',
			'hide_empty' => false,
			'search' => $search_string
				) );

		if ( !empty( $terms ) && is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$data[] = array(
					'label' => $term->name,
					'value' => $term->slug,
					'group_id' => $term->taxonomy,
				);
			}
		}

		return $data;
	}

	/**
	 * Autocomplete render term for post tags
	 * For Visual Composer Autocomplete Param
	 * Display term item as a label
	 * 
	 * @param array $query
	 * @return array tags suggestion result
	 */
	public function tags_render( $query ) {

		$term = get_term_by( 'slug', $query['value'], 'post_tag' );

		if ( $term ) {
			$query['label'] = $term->name;
		}

		return $query;
	}

	/**
	 * Autocomplete search term for posts
	 * For Visual Composer Autocomplete Param
	 * Provide suggestion result
	 * 
	 * @param string $search_string
	 * @return array posts suggestion result
	 */
	public function posts_search( $search_string ) {

		$data = array();

		$posts = get_posts( array(
			'post_type' => 'post',
			'post_status' => 'publish',
			's' => $search_string,
			'posts_per_page' => 10
				) );
		if ( $posts ) {
			foreach ( $posts as $post ) {
				$data[] = array(
					'label' => $post->post_title,
					'value' => $post->ID,
					'group_id' => $post->post_type,
				);
			}
		}

		return $data;
	}

	/**
	 * Autocomplete render term for post
	 * For Visual Composer Autocomplete Param
	 * Display term item as a label
	 * 
	 * @param array $query
	 * @return array post suggestion result
	 */
	public function posts_render( $query ) {

		$post = get_post( $query['value'] );

		if ( $post ) {
			$query['label'] = $post->post_title;
		}

		return $query;
	}

}
