<?php
return array(
	'facebook' => array(
		'id' => 'facebook',
		'text' => 'Facebook',
		'label' => 'Facebook Page URL',
		'color' => '#44619d',
		'icons' => array(
			'fa fa-facebook',
			'fa fa-facebook-official',
			'fa fa-facebook-square'
		),
		'url' => '//facebook.com',
		'share_url' => '//www.facebook.com/sharer.php?u=[post-url]'
	),
	'twitter' => array(
		'id' => 'twitter',
		'text' => 'Twitter',
		'label' => 'Twitter URL or Username',
		'color' => '#1da1f2',
		'icons' => array(
			'fa fa-twitter',
			'fa fa-twitter-square'
		),
		'url' => '//twitter.com',
		'share_url' => '//twitter.com/share?url=[post-url]&text=[post-title]'
	),
	'gplus' => array(
		'id' => 'gplus',
		'label' => 'Google Plus Profile URL',
		'text' => 'G Plus',
		'color' => '#db4437',
		'icons' => array(
			'fa fa-google-plus',
			'fa fa-google-plus-square'
		),
		'url' => '//plus.google.com',
		'share_url' => '//plus.google.com/share?url=[post-url]'
	),
	'linkedin' => array(
		'id' => 'linkedin',
		'text' => 'LinkedIn',
		'label' => 'LinkedIn Profile URL',
		'url' => '//www.linkedin.com',
		'icons' => array(
			'fa fa-linkedin',
			'fa fa-linkedin-square'
		),
		'color' => '#1683bc',
		'share_url' => '//www.linkedin.com/shareArticle?url=[post-url]&title=[post-title]'
	),
	'youtube' => array(
		'id' => 'youtube',
		'text' => 'YouTube',
		'label' => 'YouTube Channel URL',
		'url' => '//www.youtube.com',
		'icons' => array(
			'fa fa-youtube-play',
			'fa fa-youtube',
			'fa fa-youtube-square'
		),
		'color' => '#e62117',
	),
	'pinterest' => array(
		'id' => 'pinterest',
		'text' => 'Pinterest',
		'label' => 'Pinterest Board URL',
		'url' => '//www.pinterest.com',
		'icons' => array(
			'fa fa-pinterest',
			'fa fa-pinterest-square'
		),
		'color' => '#d01d15',
		'share_url' => '//pinterest.com/pin/create/bookmarklet/?url=[post-url]&description=[post-title]'
	),
	'tumblr' => array(
		'id' => 'tumblr',
		'text' => 'Tumblr',
		'label' => 'Tumblr Blog URL',
		'url' => '//www.tumblr.com',
		'icons' => array(
			'fa fa-tumblr',
			'fa fa-tumblr-square'
		),
		'color' => '#31506c',
		'share_url' => '//www.tumblr.com/share/link?url=[post-url]&name=[post-title]&description=[post-desc]'
	),
	'instagram' => array(
		'id' => 'instagram',
		'text' => 'Instagram',
		'label' => 'Instagram Profile URL',
		'url' => '//instagram.com',
		'icons' => array(
			'fa fa-instagram'
		),
		'color' => '#517ea3',
	),
	'soundcloud' => array(
		'id' => 'soundcloud',
		'text' => 'SoundCloud',
		'label' => 'SoundCloud URL',
		'url' => '//www.soundcloud.com',
		'icons' => array(
			'fa fa-soundcloud'
		),
		'color' => '#ff6000',
	),
	'github' => array(
		'id' => 'github',
		'text' => 'GitHub',
		'label' => 'GitHub URL',
		'url' => '//github.com',
		'icons' => array(
			'fa fa-github',
			'fa fa-github-square'
		),
		'color' => '#000000',
	),
	'vimeo' => array(
		'id' => 'vimeo',
		'text' => 'Vimeo',
		'label' => 'Vimeo URL',
		'url' => '//vimeo.com',
		'icons' => array(
			'fa fa-vimeo',
			'fa fa-vimeo-square'
		),
		'color' => '#44bbff',
	),
	'vine' => array(
		'id' => 'vine',
		'text' => 'Vine',
		'label' => 'Vine URL',
		'url' => '//vine.co',
		'icons' => array(
			'fa fa-vine'
		),
		'color' => '#00ac7f',
	),
	'medium' => array(
		'id' => 'medium',
		'text' => 'Medium',
		'label' => 'Medium URL',
		'url' => '//medium.com',
		'icons' => array(
			'fa fa-medium'
		),
		'color' => '#00ab6c',
	),
	'reddit' => array(
		'id' => 'reddit',
		'text' => 'Reddit',
		'label' => 'Reddit URL',
		'url' => '//www.reddit.com',
		'icons' => array(
			'fa fa-reddit-alien',
			'fa fa-reddit',
			'fa fa-reddit-square'
		),
		'color' => '#ff5700',
		'share_url' => '//reddit.com/submit?url=[post-url]&title=[post-title]'
	),
	'dribbble' => array(
		'id' => 'dribbble',
		'text' => 'Dribbble',
		'label' => 'Dribbble URL',
		'url' => '//dribbble.com',
		'icons' => array(
			'fa fa-dribbble'
		),
		'color' => '#ea4c89',
	),
	'spotify' => array(
		'id' => 'spotify',
		'text' => 'Spotify',
		'label' => 'Spotify URL',
		'url' => '//www.spotify.com',
		'icons' => array(
			'fa fa-spotify'
		),
		'color' => '#81c240',
	),
	'houzz' => array(
		'id' => 'houzz',
		'text' => 'Houzz',
		'label' => 'Houzz URL',
		'url' => '//www.houzz.com',
		'icons' => array(
			'fa fa-houzz'
		),
		'color' => '#7ac143',
	),
	'vk' => array(
		'id' => 'vk',
		'text' => 'VKontakte',
		'label' => 'VKontakte URL',
		'url' => '//vk.com',
		'icons' => array(
			'fa fa-vk'
		),
		'color' => '#45668e',
		'share_url' => '//vk.com/share.php?url=[post-url]title=[title]&description=[post-desc]'
	),
	'slack' => array(
		'id' => 'slack',
		'text' => 'Slack It',
		'label' => 'Slack URL',
		'url' => '//slack.com/',
		'icons' => array(
			'fa fa-slack'
		),
		'color' => '#56b68b',
		'share_url' => '//slackbutton.herokuapp.com/post/new/?url=[post-url]?utm_source=slack&utm_medium=referral&utm_campaign=share-button'
	),
	'stumbleupon' => array(
		'id' => 'stumbleupon',
		'text' => 'StumbleUpon',
		'label' => 'StumbleUpon URL',
		'url' => '//stumbleupon.com/',
		'icons' => array(
			'fa fa-stumbleupon',
			'fa fa-stumbleupon-circle'
		),
		'color' => '#eb4924',
		'share_url' => '//www.stumbleupon.com/submit?url=[post-url]&title=[post-title]'
	),
	'delicious' => array(
		'id' => 'delicious',
		'text' => 'Delicious',
		'label' => 'Delicious URL',
		'url' => '//delicious.com/',
		'icons' => array(
			'fa fa-delicious',
		),
		'color' => '#3399ff',
		'share_url' => '//delicious.com/save?v=5&noui&jump=close&url=[post-url]&title=[post-title]'
	),
	'digg' => array(
		'id' => 'digg',
		'text' => 'Digg',
		'label' => 'Digg URL',
		'url' => '//digg.com/',
		'icons' => array(
			'fa fa-digg',
		),
		'color' => '#000000',
		'share_url' => '//digg.com/submit?url=[post-url]&title=[post-title]'
	),
	'getpocket' => array(
		'id' => 'getpocket',
		'text' => 'Get Pocket',
		'label' => 'Get Pocket URL',
		'url' => '//getpocket.com/',
		'icons' => array(
			'fa fa-get-pocket',
		),
		'color' => '#ef4056',
		'share_url' => '//getpocket.com/save?url=[post-url]&title=[post-title]'
	),
	'rss' => array(
		'id' => 'rss',
		'text' => 'RSS',
		'label' => 'RSS URL',
		'url' => '//www.yourfeedurl.com',
		'icons' => array(
			'fa fa-rss',
			'fa fa-rss-square'
		),
		'color' => '#f26e30',
	),
	'mail' => array(
		'id' => 'mail',
		'text' => 'Mail',
		'label' => 'Email Address',
		'url' => 'your@email.com',
		'icons' => array(
			'fa fa-envelope',
			'fa fa-envelope-o'
		),
		'color' => '#52b9d4',
		'share_url' => 'mailto:?subject=[post-title]&body=[post-url]'
	),
	'website' => array(
		'id' => 'website',
		'text' => 'Website',
		'label' => 'Website URL',
		'url' => '//www.yourwebsite.com',
		'icons' => array(
			'fa fa-link'
		),
		'color' => '#33d299',
	),
);
