<?php

namespace TP_Base\Toolkit;

class Toolkit {

	/**
	 *  The current globally available container (if any).
	 * @var static
	 */
	public static $instance;

	/**
	 * Set the globally available instance of the container.
	 *
	 * @return static
	 */
	public static function get_instance() {
		if ( is_null( static::$instance ) ) {
			static::$instance = new static;
		}

		return static::$instance;
	}

	/**
	 * Modules list
	 * @var array
	 */
	public $modules = array();

	public function __construct() {

		static::$instance = $this;

		add_action( 'admin_enqueue_scripts', array( $this, 'adminScripts' ), 15 );
		add_action( 'wp_enqueue_scripts', array( $this, 'frontScripts' ), 999 );
		add_action( 'init', array( $this, 'registerScripts' ), 10 );
		add_action( 'plugins_loaded', array( $this, 'loadPluginTextdomain' ) );
		add_action( 'plugins_loaded', array( $this, 'init' ) );
		add_action( 'widgets_init', array( $this, 'widgetInit' ) );
		add_action( 'admin_init', array( $this, 'activation' ) );
		add_action( 'admin_init', array( $this, 'vcMap' ) );

		$this->modules['woocommerce'] = new WooCommerce\Hooks();
		$this->modules['minicart'] = new WooCommerce\MiniCart();
		$this->modules['miniwishlist'] = new WooCommerce\MiniWishlist();

		$this->modules['member'] = new Member\Hooks();
		$this->modules['event'] = new Event\Hooks();
		$this->modules['testimonial'] = new Testimonial\Hooks();

		do_action( 'tp_base\toolkit\loaded' );
	}

	/**
	 * Init classes and functions were written for third party
	 * @since 1.0
	 * @return void
	 */
	public function init() {

		if ( class_exists( '\TPFW' ) ) {

			new Admin\Customizer();
			new Admin\Metabox();
			new Admin\SidebarCreator();
			new Admin\Importer();

			new Query\Customizer();
			new Query\Metabox();

			new MegaMenu\MegaMenu();
			new Typography();
		}

		if ( class_exists( '\Vc_Manager' ) ) {
			new Vc\Block();
			new Vc\Map();
			new Vc\Posts();
		}

		new Admin\ContactMethods();
	}

	/**
	 * Init Widget hooks
	 * @since 1.0
	 */
	public function widgetInit() {
		if ( class_exists( '\TPFW' ) ) {
			register_widget( 'TP_Base\Toolkit\Widget\Contact' );
			register_widget( 'TP_Base\\Toolkit\\Widget\\Posts' );
			register_widget( 'TP_Base\\Toolkit\\Widget\\Instagram' );
		}
	}

	/**
	 * Activation function fires when the plugin is activated.
	 *
	 * @since 1.0
	 * @return void
	 */
	public function activation() {
		if ( !class_exists( '\TPFW' ) ) {
			// is this plugin active?
			if ( is_plugin_active( plugin_basename( __FILE__ ) ) ) {
				// unset activation notice
				unset( $_GET['activate'] );
				// display notice
				add_action( 'admin_notices', array( $this, 'admin_notices' ) );
			}
		}
	}

	/**
	 * Admin notices
	 * @since 1.0
	 * @return void
	 */
	public function admin_notices() {
		echo '<div class="notice notice-warning"><p>';
		echo __( '<strong>TP Framework</strong> Plugin should be activated to enable full features of TP Base Toolkit Plugin', 'tp-base-toolkit' );
		echo '</p></div>';
	}

	/**
	 * Enqueue admin script
	 * @since 1.0
	 *
	 * @param string $hook
	 *
	 * @return void
	 */
	public function adminScripts( $hook ) {
		wp_enqueue_script( 'tp-base-toolkit-admin', TP_BASE_TOOLKIT_URL . 'assets/js/admin.js', array( 'jquery' ), TP_BASE_TOOLKIT_VER, true );
		wp_enqueue_style( 'tp-base-toolkit-admin', TP_BASE_TOOLKIT_URL . 'assets/css/admin.css', array(), TP_BASE_TOOLKIT_VER );
	}

	/**
	 * Enqueue front-end scripts
	 *
	 * @since 1.0
	 * @return void
	 */
	public function frontScripts() {

		wp_enqueue_script( 'tp-base-toolkit-front', TP_BASE_TOOLKIT_URL . 'assets/js/front.js', array( 'jquery' ), TP_BASE_TOOLKIT_VER, true );
		if ( $custom_js = get_theme_mod( 'custom_js', '' ) ) {
			wp_add_inline_script( 'tp-base-toolkit-front', $custom_js, 'after' );
		}

		wp_localize_script( 'tp-base-toolkit-front', 'tp_base_toolkit', apply_filters( 'tp_base\toolkit\localize', array() ) );
	}

	/**
	 * Register scripts are supported in plugin
	 * @return void
	 */
	public function registerScripts() {

		/**
		 * Register gmap v3
		 */
		if ( $key = get_theme_mod( 'gmap_api_key' ) ) {
			$googleapiurl = 'http://maps.googleapis.com/maps/api/js?libraries=places';
			$googleapiurl = $googleapiurl . '&key=' . $key;
			wp_register_script( 'google-map-v-3', $googleapiurl, array( 'jquery' ), null, true );
		}

		/**
		 * Register slick slider
		 */
		wp_register_style( 'slick', TP_BASE_TOOLKIT_URL . 'assets/vendor/slick/slick.css', array(), '1.8.0' );
		wp_register_style( 'slick-theme', TP_BASE_TOOLKIT_URL . 'assets/vendor/slick/slick-theme.css', array(), '1.8.0' );
		wp_register_script( 'slick', TP_BASE_TOOLKIT_URL . 'assets/vendor/slick/slick.min.js', array( 'jquery' ), '1.8.0', true );
	}

	/**
	 * Custom build param vc_map
	 * @since 1.0
	 */
	public function vcMap() {

		global $pagenow;

		if ( $pagenow == 'post.php' || $pagenow == 'post-new.php' ) {
			do_action( 'tp_base\toolkit\vc_map', 'wp_edit_post', false );
		} else if ( wp_doing_ajax() && isset( $_POST['action'] ) && sanitize_text_field( $_POST['action'] ) == 'vc_edit_form' ) {
			do_action( 'tp_base\toolkit\vc_map', 'vc_edit_form', sanitize_key( $_POST['tag'] ) );
		}
	}

	/**
	 * Load Local files.
	 * @since 1.0
	 * @return void
	 */
	public function loadPluginTextdomain() {

		// Set filter for plugin's languages directory
		$dir = TP_BASE_TOOLKIT_DIR . 'languages/';
		$dir = apply_filters( 'tp_base\toolkit\languages_directory', $dir );

		// Traditional WordPress plugin locale filter
		$locale = apply_filters( 'plugin_locale', get_locale(), 'tp-base-toolkit' );
		$mofile = sprintf( '%1$s-%2$s.mo', 'tp-base-toolkit', $locale );

		// Setup paths to current locale file
		$mofile_local = $dir . $mofile;

		$mofile_global = WP_LANG_DIR . '/tp-base-toolkit/' . $mofile;

		if ( file_exists( $mofile_global ) ) {
			load_textdomain( 'tp-base-toolkit', $mofile_global );
		} elseif ( file_exists( $mofile_local ) ) {
			load_textdomain( 'tp-base-toolkit', $mofile_local );
		} else {
			// Load the default language files
			load_plugin_textdomain( 'tp-base-toolkit', false, $dir );
		}
	}

	/**
	 * Resolve a object/property and call it if needed.
	 *
	 * @param  string $id Param ID.
	 *
	 * @return mixed
	 */
	public function factory( $id ) {

		if ( isset( $this->modules[$id] ) ) {
			return $this->modules[$id];
		}
	}

}
