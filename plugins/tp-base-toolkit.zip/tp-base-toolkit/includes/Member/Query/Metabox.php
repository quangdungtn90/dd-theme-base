<?php

namespace TP_Base\Toolkit\Member\Query;

use TP_Base\Toolkit\Query\Metabox as TP_Base_Query_Metabox;

class Metabox extends TP_Base_Query_Metabox{

	public function __construct() {
		add_filter( 'tp_base\query', array( $this, 'init' ), 15 );
	}

	public function init( $query ) {

		if ( $query['hook']['group'] == 'member' ) {
			$query = $this->single( $query );
		}

		return $query;
	}
	public function single( $query ) {

		$post_id = get_the_ID();

		if ( get_post_meta( $post_id, '_advanced_settings', true ) ) {

			/**
			 * Override Content options
			 */
			$query = $this->general( $query, 'post', $post_id );

		}

		return $query;
	}
}