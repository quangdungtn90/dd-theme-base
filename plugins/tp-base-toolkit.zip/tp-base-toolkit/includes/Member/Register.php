<?php

namespace TP_Base\Toolkit\Member;

use TP_Base\Toolkit\Admin\Metabox;

class Register extends Metabox {

	public function __construct() {

		add_action( 'init', array( $this, 'postType' ) );
		add_action( 'init', array( $this, 'taxonomyGroup' ) );
		add_action( 'init', array( $this, 'taxonomyPosition' ) );
		add_action( 'tpfw_metabox_init', array( $this, 'fields' ) );
	}

	public function postType() {

		$labels = array(
			'name' => esc_html_x( 'Members', 'Post Type General Name', 'tp-base-toolkit' ),
			'singular_name' => esc_html_x( 'Member', 'Post Type Singular Name', 'tp-base-toolkit' ),
			'menu_name' => esc_html__( 'Members', 'tp-base-toolkit' ),
			'name_admin_bar' => esc_html__( 'Member', 'tp-base-toolkit' ),
			'archives' => esc_html__( 'Member Archives', 'tp-base-toolkit' ),
			'attributes' => esc_html__( 'Member Attributes', 'tp-base-toolkit' ),
			'parent_item_colon' => esc_html__( 'Parent Member:', 'tp-base-toolkit' ),
			'all_items' => esc_html__( 'All Items', 'tp-base-toolkit' ),
			'add_new_item' => esc_html__( 'Add New Item', 'tp-base-toolkit' ),
			'add_new' => esc_html__( 'Add Member', 'tp-base-toolkit' ),
			'new_item' => esc_html__( 'New Member', 'tp-base-toolkit' ),
			'edit_item' => esc_html__( 'Edit Member', 'tp-base-toolkit' ),
			'update_item' => esc_html__( 'Update Member', 'tp-base-toolkit' ),
			'view_item' => esc_html__( 'View Member', 'tp-base-toolkit' ),
			'view_items' => esc_html__( 'View Members', 'tp-base-toolkit' ),
			'search_items' => esc_html__( 'Search Member', 'tp-base-toolkit' ),
			'not_found' => esc_html__( 'Not found', 'tp-base-toolkit' ),
			'not_found_in_trash' => esc_html__( 'Not found in Trash', 'tp-base-toolkit' ),
			'featured_image' => esc_html__( 'Member Avatar', 'tp-base-toolkit' ),
			'set_featured_image' => esc_html__( 'Set Member Avatar', 'tp-base-toolkit' ),
			'remove_featured_image' => esc_html__( 'Remove Member Avatar', 'tp-base-toolkit' ),
			'use_featured_image' => esc_html__( 'Use as Member Avatar', 'tp-base-toolkit' ),
			'insert_into_item' => esc_html__( 'Insert into Member', 'tp-base-toolkit' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to the Member', 'tp-base-toolkit' ),
			'items_list' => esc_html__( 'Member list', 'tp-base-toolkit' ),
			'items_list_navigation' => esc_html__( 'Member list navigation', 'tp-base-toolkit' ),
			'filter_items_list' => esc_html__( 'Filter Member list', 'tp-base-toolkit' ),
		);
		$args = array(
			'menu_icon' => 'dashicons-universal-access-alt',
			'label' => esc_html__( 'Member', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Team Members', 'tp-base-toolkit' ),
			'labels' => $labels,
			'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
			'taxonomies' => array( 'member_group', 'member_position' ),
			'rewrite' => array( 'slug' => 'member' ),
			'hierarchical' => false,
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'menu_position' => null,
			'show_in_admin_bar' => true,
			'show_in_nav_menus' => true,
			'can_export' => true,
			'has_archive' => true,
			'exclude_from_search' => false,
			'publicly_queryable' => true,
			'capability_type' => 'page',
		);

		register_post_type( 'member', $args );
	}

	public function taxonomyGroup() {


		$labels = array(
			'name' => esc_html_x( 'Member groups', 'Taxonomy General Name', 'tp-base-toolkit' ),
			'singular_name' => esc_html_x( 'Member group', 'Taxonomy Singular Name', 'tp-base-toolkit' ),
			'menu_name' => esc_html__( 'Member groups', 'tp-base-toolkit' ),
			'all_items' => esc_html__( 'All Member groups', 'tp-base-toolkit' ),
			'parent_item' => esc_html__( 'Parent Group', 'tp-base-toolkit' ),
			'parent_item_colon' => esc_html__( 'Parent group:', 'tp-base-toolkit' ),
			'new_item_name' => esc_html__( 'New group', 'tp-base-toolkit' ),
			'add_new_item' => esc_html__( 'Add new group', 'tp-base-toolkit' ),
			'edit_item' => esc_html__( 'Edit group', 'tp-base-toolkit' ),
			'update_item' => esc_html__( 'Update group', 'tp-base-toolkit' ),
			'view_item' => esc_html__( 'View group', 'tp-base-toolkit' ),
			'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'tp-base-toolkit' ),
			'add_or_remove_items' => esc_html__( 'Add or remove items', 'tp-base-toolkit' ),
			'choose_from_most_used' => esc_html__( 'Choose from the most used', 'tp-base-toolkit' ),
			'popular_items' => esc_html__( 'Popular Items', 'tp-base-toolkit' ),
			'search_items' => esc_html__( 'Search groups', 'tp-base-toolkit' ),
			'not_found' => esc_html__( 'Not Found', 'tp-base-toolkit' ),
			'no_terms' => esc_html__( 'No groups', 'tp-base-toolkit' ),
			'items_list' => esc_html__( 'Group list', 'tp-base-toolkit' ),
			'items_list_navigation' => esc_html__( 'Groups list navigation', 'tp-base-toolkit' ),
		);


		$args = array(
			'labels' => $labels,
			'hierarchical' => true,
			'public' => true,
			'show_ui' => true,
			'show_admin_column' => true,
			'show_in_nav_menus' => true,
			'show_tagcloud' => true,
		);


		register_taxonomy( 'member_group', array( 'member' ), $args );
	}

	public function taxonomyPosition() {


		$labels = array(
			'name' => esc_html_x( 'Member position', 'Taxonomy General Name', 'tp-base-toolkit' ),
			'singular_name' => esc_html_x( 'Member position', 'Taxonomy Singular Name', 'tp-base-toolkit' ),
			'menu_name' => esc_html__( 'Member positions', 'tp-base-toolkit' ),
			'all_items' => esc_html__( 'All Member position', 'tp-base-toolkit' ),
			'parent_item' => esc_html__( 'Parent position', 'tp-base-toolkit' ),
			'parent_item_colon' => esc_html__( 'Parent position:', 'tp-base-toolkit' ),
			'new_item_name' => esc_html__( 'New position', 'tp-base-toolkit' ),
			'add_new_item' => esc_html__( 'Add new position', 'tp-base-toolkit' ),
			'edit_item' => esc_html__( 'Edit position', 'tp-base-toolkit' ),
			'update_item' => esc_html__( 'Update position', 'tp-base-toolkit' ),
			'view_item' => esc_html__( 'View position', 'tp-base-toolkit' ),
			'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'tp-base-toolkit' ),
			'add_or_remove_items' => esc_html__( 'Add or remove items', 'tp-base-toolkit' ),
			'choose_from_most_used' => esc_html__( 'Choose from the most used', 'tp-base-toolkit' ),
			'popular_items' => esc_html__( 'Popular Items', 'tp-base-toolkit' ),
			'search_items' => esc_html__( 'Search groups', 'tp-base-toolkit' ),
			'not_found' => esc_html__( 'Not Found', 'tp-base-toolkit' ),
			'no_terms' => esc_html__( 'No groups', 'tp-base-toolkit' ),
			'items_list' => esc_html__( 'Position list', 'tp-base-toolkit' ),
			'items_list_navigation' => esc_html__( 'Position list navigation', 'tp-base-toolkit' ),
		);


		$args = array(
			'labels' => $labels,
			'hierarchical' => true,
			'public' => true,
			'show_ui' => true,
			'show_admin_column' => true,
			'show_in_nav_menus' => true,
			'show_tagcloud' => true,
		);


		register_taxonomy( 'member_position', array( 'member' ), $args );
	}

	/**
	 * Declare Members meta fields
	 *
	 * @since 1.0
	 *
	 * @param array $fields Form fields
	 *
	 * @return array Form fields
	 */
	public function fields() {

		$fields = array(
			array(
				'name' => '_member_firstname',
				'type' => 'textfield',
				'heading' => esc_html__( 'First Name', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
				'size' => 'small'
			),
			array(
				'name' => '_member_lastname',
				'type' => 'textfield',
				'heading' => esc_html__( 'Last Name', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
				'size' => 'small'
			),
			array(
				'name' => '_member_gender',
				'type' => 'select',
				'heading' => esc_html__( 'Gender', 'tp-base-toolkit' ),
				'options' => array(
					'male' => esc_html__( 'Male', 'tp-base-toolkit' ),
					'female' => esc_html__( 'Female', 'tp-base-toolkit' ),
					'' => esc_html__( 'Other', 'tp-base-toolkit' )
				),
				'sanitize_callback' => 'sanitize_text_field',
			),
			array(
				'name' => '_member_email',
				'type' => 'textfield',
				'heading' => esc_html__( 'Email', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_email',
				'size' => 'small'
			),
			array(
				'name' => '_member_phone',
				'type' => 'textfield',
				'heading' => esc_html__( 'Phone number', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
				'size' => 'small'
			),
			array(
				'name' => '_member_address',
				'type' => 'textarea',
				'heading' => esc_html__( 'Address', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
			),
			array(
				'name' => '_member_contacts',
				'type' => 'textfield',
				'multiple' => 1,
				'heading' => esc_html__( 'Social or Website URL', 'tp-base-toolkit' ),
				'group' => esc_html__( 'Social contact', 'tp-base-toolkit' ),
				'value' => array(
					'https://facebook.com/your_ID',
					'https://twitter.com/your_ID',
					'https://plus.google.com/+your_ID'
				)
			)
		);

		new \Tpfw_Metabox( array(
			'id' => '_member_settings',
			'screens' => array( 'member' ),
			'heading' => esc_html__( 'Member Info', 'tp-base-toolkit' ),
			'context' => 'advanced', //side
			'priority' => 'low',
			'manage_box' => false,
			'fields' => $fields
				) );
	}

}
