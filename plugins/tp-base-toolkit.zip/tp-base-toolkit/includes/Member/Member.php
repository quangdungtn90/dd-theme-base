<?php

namespace TP_Base\Toolkit\Member;

class Member {

	/**
	 * ID for this object.
	 *
	 * @since 1.0
	 * @var int
	 */
	protected $id = 0;

	/**
	 * Post type.
	 * @var string
	 */
	protected $post_type = 'member';

	/**
	 * Stores member data.
	 *
	 * @var array
	 */
	protected $data = array(
		'name' => '',
		'slug' => '',
		'date_created' => null,
		'date_modified' => null,
		'status' => false,
		'featured' => false,
		'description' => '',
		'content' => '',
		'image_id' => '',
		'comment_allowed' => true,
		'firstname' => '',
		'lastname' => '',
		'gender' => '',
		'email' => '',
		'phone' => '',
		'address' => '',
		'contacts' => ''
	);

	/**
	 * Get the event if ID is passed, otherwise the event is new and empty.
	 * This class should NOT be instantiated, but the tp_base_toolkit_get_member() function
	 * should be used.
	 *
	 * @param int|Testimonal|object $event Event to init.
	 */
	public function __construct( $event = 0 ) {

		$this->setup( $event );
	}

	public function __set( $name, $value ) {
		if ( isset( $this->data[$name] ) ) {
			$this->data[$name] = $value;
		}
	}

	public function __get( $name ) {
		return isset( $this->data[$name] ) ? $this->data[$name] : '';
	}

	/**
	 * Get event id
	 * @return int
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Get event name.
	 * @return string
	 */
	public function get_name() {
		return $this->__get( 'name' );
	}

	/**
	 * Get created date
	 * @return string
	 */
	public function get_date_created() {
		return $this->__get( 'date_created' );
	}

	/**
	 * Get modified date
	 * @return string
	 */
	public function get_date_modified() {
		return $this->__get( 'date_modified' );
	}

	/**
	 * Get status
	 * @return string
	 */
	public function get_status() {
		return $this->__get( 'status' );
	}

	/**
	 * Get is featured
	 * @return string
	 */
	public function get_featured() {
		return $this->__get( 'featured' );
	}

	/**
	 * Get description
	 * @return string
	 */
	public function get_description() {
		return $this->__get( 'description' );
	}

	/**
	 * Get content
	 * @return string
	 */
	public function get_content() {
		return $this->__get( 'content' );
	}

	/**
	 * Get thumbnail id
	 * @return string
	 */
	public function get_image_id() {
		return $this->__get( 'image_id' );
	}

	/**
	 * Get event slug.
	 * @return string
	 */
	public function get_slug() {
		return $this->__get( 'slug' );
	}

	/**
	 * Get is comment allowed
	 * @return bool
	 */
	public function get_comment_allowed() {
		return $this->__get( 'comment_allowed' );
	}

	/**
	 * Get firstname
	 * @return string
	 */
	public function get_firstname() {
		return $this->__get( 'firstname' );
	}

	/**
	 * Get lastname
	 * @return array
	 */
	public function get_lastname() {
		return $this->__get( 'lastname' );
	}

	/**
	 * Get gender
	 * @return string
	 */
	public function get_gender() {
		return $this->__get( 'gender' );
	}

	/**
	 * Get gender text
	 * @return string
	 */
	public function get_gender_text() {
		$genders = array(
			'male' => esc_html__( 'Male', 'tp-base-toolkit' ),
			'female' => esc_html__( 'Female', 'tp-base-toolkit' ),
			'' => esc_html__( 'Other', 'tp-base-toolkit' )
		);

		$gender = $this->get_gender();

		if ( isset( $genders[$gender] ) ) {
			$gender = $genders[$gender];
		}
		
		return apply_filters( 'tp_base\toolkit\get_gender_text', $gender, $genders );
	}

	/**
	 * Get email
	 * @return string
	 */
	public function get_email() {
		return $this->__get( 'email' );
	}

	/**
	 * Get phone number
	 * @return string
	 */
	public function get_phone() {
		return $this->__get( 'phone' );
	}

	/**
	 * Get address
	 * @return string
	 */
	public function get_address() {
		return $this->__get( 'address' );
	}

	/**
	 * Get contact socials
	 * @return array
	 */
	public function get_contacts() {

		$contacts = $this->__get( 'contacts' );
		if ( is_string( $contacts ) && !empty( $contacts ) ) {
			$contacts = json_decode( urldecode( $contacts ) );
		}

		return $contacts;
	}

	/**
	 * Method to read a event from the database.
	 *
	 * @param Event|WP_Post $event
	 *
	 * @throws Exception
	 */
	public function setup( $post ) {

		if ( is_numeric( $post ) ) {
			$post = get_post( $post );
		}

		if ( !$post ) {
			throw new \Exception( __( 'Invalid member.', 'tp-base-toolkit' ) );
		}

		$this->id = $post->ID;

		$this->__set( 'name', $post->post_title );
		$this->__set( 'slug', $post->post_name );
		$this->__set( 'date_created', $post->post_date_gmt );
		$this->__set( 'date_modified', $post->post_modified_gmt );
		$this->__set( 'description', $post->post_excerpt );
		$this->__set( 'content', $post->post_content );
		$this->__set( 'parent_id', $post->post_parent );
		$this->__set( 'slug', $post->post_name );
		$this->__set( 'comment_allowed', 'open' === $post->comment_status );
		$this->__set( 'firstname', get_post_meta( $this->get_id(), '_member_firstname', true ) );
		$this->__set( 'lastname', get_post_meta( $this->get_id(), '_member_lastname', true ) );
		$this->__set( 'gender', get_post_meta( $this->get_id(), '_member_gender', true ) );
		$this->__set( 'email', get_post_meta( $this->get_id(), '_member_email', true ) );
		$this->__set( 'phone', get_post_meta( $this->get_id(), '_member_phone', true ) );
		$this->__set( 'address', get_post_meta( $this->get_id(), '_member_address', true ) );
		$this->__set( 'contacts', get_post_meta( $this->get_id(), '_member_contacts', true ) );
	}

	public function get_contacts_html() {

		$html = '<div class="member_socials">';
		$social_icons = tp_base_social_links_icons();

		$contacts = $this->get_contacts();

		foreach ( $contacts as $key => $value ) {

			$host = parse_url( $value );
			if ( $host['scheme'] == 'mailto' ) {
				$host = 'mailto:';
			} else {
				$host = str_replace( 'www.', '', isset( $host['host'] ) ? $host['host'] : $host['path'] );
			}


			$icon = tp_base_get_icon( 'link' );

			if ( isset( $social_icons[$host] ) ) {
				$icon = tp_base_get_icon( $social_icons[$host] );
			}

			$html .= sprintf( '<a href="%s" target="_blank">%s</a>', esc_url( $value ), $icon );
		}

		$html .= '</div>';

		return apply_filters( 'tp_base\toolkit\member\get_contacts_html', $html, $contacts );
	}

}
