<?php

namespace TP_Base\Toolkit\Member;

class Hooks {

	public function __construct() {
		new Register();
		new Query\Customizer();
		new Query\Metabox();

		add_filter( 'template_include', array( $this, 'templateLoader' ) );
		add_action( 'the_post', array( $this, 'setupData' ) );

		include 'functions.php';
	}

	/**
	 * Load a template.
	 *
	 * Handles template usage so that we can use our own templates instead of the themes.
	 *
	 * Templates are in the 'templates' folder. toolkit looks for theme.
	 * overrides in /theme/toolkit/ by default.
	 *
	 * @param mixed $template
	 *
	 * @return string
	 */
	public static function templateLoader( $template ) {

		if ( is_embed() ) {
			return $template;
		}

		if ( is_singular( 'member' ) ) {
			$template = tp_base_toolkit_template_path( 'member/single-member' );
		} else if ( is_post_type_archive( 'member' ) ) {
			$template = tp_base_toolkit_template_path( 'member/archive-member' );
		}

		return $template;
	}

	/**
	 * When the_post is called, put product data into a global.
	 *
	 * @param mixed $post Post Object.
	 *
	 * @return Event
	 */
	public function setupData( $post ) {
		unset( $GLOBALS['tp_base_member'] );

		if ( is_int( $post ) ) {
			$the_post = get_post( $post );
		} else {
			$the_post = $post;
		}

		if ( empty( $the_post->post_type ) || $the_post->post_type !== 'member' ) {
			return;
		}

		$GLOBALS['tp_base_member'] = new Member( $the_post );

		return $GLOBALS['tp_base_member'];
	}

}
