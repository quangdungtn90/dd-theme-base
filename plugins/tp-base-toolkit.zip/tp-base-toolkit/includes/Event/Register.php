<?php

namespace TP_Base\Toolkit\Event;

use TP_Base\Toolkit\Admin\Metabox;

class Register extends Metabox {

	public function __construct() {
			
		add_action( 'init', array( $this, 'postType' ) );
		add_action( 'tpfw_metabox_init', array( $this, 'fields' ) );
		
	}

	public function postType() {

		$labels = array(
			'name'               => esc_html_x( 'Events', 'Post type general name', 'tp-base-toolkit' ),
			'singular_name'      => esc_html_x( 'Event', 'Post type singular name', 'tp-base-toolkit' ),
			'menu_name'          => esc_html_x( 'Events', 'Admin menu', 'tp-base-toolkit' ),
			'name_admin_bar'     => esc_html_x( 'Event', 'Add new on admin bar', 'tp-base-toolkit' ),
			'add_new'            => esc_html_x( 'Add New', 'Event', 'tp-base-toolkit' ),
			'add_new_item'       => esc_html__( 'Add New Event', 'tp-base-toolkit' ),
			'new_item'           => esc_html__( 'New Event', 'tp-base-toolkit' ),
			'edit_item'          => esc_html__( 'Edit Event', 'tp-base-toolkit' ),
			'view_item'          => esc_html__( 'View Event', 'tp-base-toolkit' ),
			'all_items'          => esc_html__( 'All Events', 'tp-base-toolkit' ),
			'search_items'       => esc_html__( 'Search Events', 'tp-base-toolkit' ),
			'parent_item_colon'  => esc_html__( 'Parent Events:', 'tp-base-toolkit' ),
			'not_found'          => esc_html__( 'No events found.', 'tp-base-toolkit' ),
			'not_found_in_trash' => esc_html__( 'No events found in Trash.', 'tp-base-toolkit' )
		);

		$args = array(
			'menu_icon'          => 'dashicons-calendar',
			'labels'             => $labels,
			'description'        => esc_html__( 'Description.', 'tp-base-toolkit' ),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'event' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
		);

		register_post_type( 'event', $args );
	}

	/**
	 * Declare Events meta fields
	 *
	 * @since 1.0
	 *
	 * @param array $fields Form fields
	 *
	 * @return array Form fields
	 */
	public function fields() {

		$fields = array(
			array(
				'name'              => '_frequency',
				'type'              => 'select',
				'heading'           => esc_html__( 'Frequency', 'tp-base-toolkit' ),
				'options'           => array(
					'one'    => esc_attr__( 'Occurs Once', 'tp-base-toolkit' ),
					'daily'  => esc_attr__( 'Daily', 'tp-base-toolkit' ),
					'weekly' => esc_attr__( 'Weekly', 'tp-base-toolkit' ),
					'custom' => esc_attr__( 'Custom...', 'tp-base-toolkit' )
				),
				'value'             => 'one',
				'desc'              => esc_html__( 'Let people know whether this event repeats and how often it occurs.', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
				'group'             => esc_html__( 'General', 'tp-base-toolkit' )
			),
			array(
				'name'              => '_event_date_once',
				'type'              => 'event_datetime',
				'heading'           => '&nbsp;',
				'data'              => 'one',
				'sanitize_callback' => 'maybe_serialize',
				'dependency'        => array(
					'_frequency' => array( 'values' => 'one' ),
				),
				'group'             => esc_html__( 'General', 'tp-base-toolkit' ),
				'desc'              => esc_html__( 'Your event lasts more than 24 hours. Select Daily, Weekly or Custom for a recurring event.', 'tp-base-toolkit' )
			),
			array(
				'name'              => '_event_date_daily',
				'type'              => 'event_datetime',
				'heading'           => '&nbsp;',
				'data'              => 'daily',
				'sanitize_callback' => 'maybe_serialize',
				'dependency'        => array(
					'_frequency' => array( 'values' => 'daily' ),
				),
				'group'             => esc_html__( 'General', 'tp-base-toolkit' )
			),
			array(
				'name'              => '_event_date_weekly',
				'type'              => 'event_datetime',
				'heading'           => '&nbsp;',
				'data'              => 'weekly',
				'sanitize_callback' => 'maybe_serialize',
				'dependency'        => array(
					'_frequency' => array( 'values' => 'weekly' ),
				),
				'group'             => esc_html__( 'General', 'tp-base-toolkit' )
			),
			array(
				'name'              => '_event_date_custom',
				'type'              => 'event_datetime',
				'heading'           => '&nbsp;',
				'data'              => 'custom',
				'sanitize_callback' => 'maybe_serialize',
				'dependency'        => array(
					'_frequency' => array( 'values' => 'custom' ),
				),
				'group'             => esc_html__( 'General', 'tp-base-toolkit' )
			),
			array(
				'name'              => '_location',
				'type'              => 'textfield',
				'heading'           => esc_html__( 'Location', 'tp-base-toolkit' ),
				'desc'              => esc_html__( 'A specific location helps guests know where to go.', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
				'group'             => esc_html__( 'Location', 'tp-base-toolkit' )
			),
			array(
				'name'              => '_map',
				'type'              => 'map',
				'heading'           => esc_html__( 'Map Location', 'tp-base-toolkit' ),
				'display_inline'    => true,
				'value'             => '',
				'desc'              => esc_html__( 'A specific location in map.', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
				'group'             => esc_html__( 'Location', 'tp-base-toolkit' )
			),
			array(
				'name'              => '_gallery',
				'type'              => 'image_picker',
				'heading'           => esc_html__( 'Event gallery', 'tp-base-toolkit' ),
				'display_inline'    => true,
				'value'             => '',
				'desc'              => esc_html__( 'Add event gallery images.', 'tp-base-toolkit' ),
				'sanitize_callback' => 'sanitize_text_field',
				'multiple'          => true,
				'group'             => esc_html__( 'Gallery', 'tp-base-toolkit' ),
			),

		);

		new \Tpfw_Metabox( array(
			'id'         => '_event_settings',
			'screens'    => array( 'event' ),
			'heading'    => esc_html__( 'Event Manager', 'tp-base-toolkit' ),
			'context'    => 'advanced', //side
			'priority'   => 'low',
			'manage_box' => false,
			'fields'     => $fields
		) );
	}
}