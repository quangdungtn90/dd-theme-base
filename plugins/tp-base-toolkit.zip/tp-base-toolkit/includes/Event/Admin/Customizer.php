<?php

namespace TP_Base\Toolkit\Event\Admin;


class Customizer {
	public function __construct() {
		add_action( 'customize_register', array( $this, 'init' ), 11 );
	}

	public $wp_customizer;
	public $sidebars;

	public function init( $wp_customizer ) {

		$this->wp_customizer = $wp_customizer;

		$nonce = array( '' => esc_attr__( '-- Select sidebar --', 'tp-base-toolkit' ) );

		$this->sidebars = tp_base_toolkit_get_sidebars( $nonce );

		$this->archive();

		$this->single();

	}

	public function archive() {
		$event = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'event',
			'heading'     => esc_html__( 'Event list', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Setting for page event list', 'tp-base-toolkit' ),
			'fields'      => array(
				array(
					'name'              => 'event_breadcrumb',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
				),
				array(
					'name'       => 'event_breadcrumb_image',
					'type'       => 'image',
					'heading'    => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'dependency' => array(
						'event_breadcrumb' => array( 'values' => 'yes' )
					)
				),

				array(
					'name'              => 'event_sidebar_position',
					'type'              => 'image_select',
					'heading'           => esc_html__( 'Sidebar Position', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'left'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
						'none'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
						'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'right',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
				),
				array(
					'name'       => 'event_sidebar',
					'type'       => 'select',
					'heading'    => esc_attr__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar',
					'dependency' => array(
						'event_sidebar_position' => array( 'values' => array( 'left', 'right' ) )
					)
				),

				array(
					'name'              => 'event_excerpt_length',
					'type'              => 'text',
					'heading'           => esc_html__( 'Change excerpt length', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'value'             => 40,
					'sanitize_callback' => 'absint',
				)
			)
		) );
	}

	public function single() {
		$event = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'event-single',
			'heading'     => esc_html__( 'Event single', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Setting for page event single', 'tp-base-toolkit' ),
			'fields'      => array(
				array(
					'name'              => 'event_single_breadcrumb',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
				),
				array(
					'name'       => 'event_single_breadcrumb_image',
					'type'       => 'image',
					'heading'    => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'value'      => get_theme_mod( 'event_breadcrumb_image' ),
					'dependency' => array(
						'event_breadcrumb' => array( 'values' => 'yes' )
					)
				),

				array(
					'name'              => 'event_single_sidebar_position',
					'type'              => 'image_select',
					'heading'           => esc_html__( 'Sidebar Position', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'left'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
						'none'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
						'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'right',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
				),
				array(
					'name'       => 'event_single_sidebar',
					'type'       => 'select',
					'heading'    => esc_html__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar',
					'dependency' => array(
						'event_single_sidebar_position' => array( 'values' => array( 'left', 'right' ) )
					)
				),
				array(
					'name'       => 'event_single_sidebar',
					'type'       => 'select',
					'heading'    => esc_html__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'sidebar',
					'dependency' => array(
						'event_single_sidebar_position' => array( 'values' => array( 'left', 'right' ) )
					)
				),
				array(
					'name'       => 'event_single_mapstyle',
					'type'       => 'image_select',
					'heading'    => esc_html__( 'Available Map Style', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => tp_base_toolkit_get_map_styles_opt(),
					'value'      => '',
					'image_size' => array( '55px', 'auto' ),
				),
				array(
					'name'       => 'event_single_mapstyle_custom',
					'type'       => 'textarea',
					'heading'    => esc_html__( 'Create a map style', 'tp-base-toolkit' ),
					'dependency' => array(
						'event_single_mapstyle' => array( 'values' => array( 'customize' ) )
					),
					'desc'       => sprintf( __( 'Please %s, export JSON then copy and paste it in the box. ', 'tp-base-toolkit' ), '<a href="//mapstyle.withgoogle.com/" target="_blank">' . esc_html__( 'Create a Map Style', 'tp-base-toolkit' ) . '</a>' )
				)
			)
		) );
	}

}