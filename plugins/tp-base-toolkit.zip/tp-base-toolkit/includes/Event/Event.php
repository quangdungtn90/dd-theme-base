<?php

namespace TP_Base\Toolkit\Event;

class Event {

	/**
	 * ID for this object.
	 *
	 * @since 1.0
	 * @var int
	 */
	protected $id = 0;

	/**
	 * Post type.
	 * @var string
	 */
	protected $post_type = 'event';

	/**
	 * Stores event data.
	 *
	 * @var array
	 */
	protected $data = array(
		'name'            => '',
		'slug'            => '',
		'date_created'    => null,
		'date_modified'   => null,
		'status'          => false,
		'featured'        => false,
		'description'     => '',
		'content'         => '',
		'image_id'        => '',
		'comment_allowed' => true,

		'frequency' => '',
		'date'      => '',
		'location'  => '',
		'map'       => '',
		'gallery'   => '',
	);

	/**
	 * Get the event if ID is passed, otherwise the event is new and empty.
	 * This class should NOT be instantiated, but the wc_get_event() function
	 * should be used. It is possible, but the wc_get_event() is preferred.
	 *
	 * @param int|Event|object $event Event to init.
	 */
	public function __construct( $event = 0 ) {

		$this->setup( $event );

	}

	public function __set( $name, $value ) {
		if ( isset( $this->data[ $name ] ) ) {
			$this->data[ $name ] = $value;
		}
	}

	public function __get( $name ) {
		return isset( $this->data[ $name ] ) ? $this->data[ $name ] : '';
	}

	/**
	 * Get event id
	 * @return int
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Get event name.
	 * @return string
	 */
	public function get_name() {
		return $this->__get( 'name' );
	}

	/**
	 * Get created date
	 * @return string
	 */
	public function get_date_created() {
		return $this->__get( 'date_created' );
	}

	/**
	 * Get modified date
	 * @return string
	 */
	public function get_date_modified() {
		return $this->__get( 'date_modified' );
	}

	/**
	 * Get status
	 * @return string
	 */
	public function get_status() {
		return $this->__get( 'status' );
	}

	/**
	 * Get is featured
	 * @return string
	 */
	public function get_featured() {
		return $this->__get( 'featured' );
	}

	/**
	 * Get description
	 * @return string
	 */
	public function get_description() {
		return $this->__get( 'description' );
	}

	/**
	 * Get content
	 * @return string
	 */
	public function get_content() {
		return $this->__get( 'content' );
	}

	/**
	 * Get thumbnail id
	 * @return string
	 */
	public function get_image_id() {
		return $this->__get( 'image_id' );
	}

	/**
	 * Get event frequency
	 * @return string
	 */
	public function get_frequency() {
		return $this->__get( 'frequency' );
	}

	/**
	 * Get event date
	 * @return array
	 */
	public function get_date() {
		return $this->__get( 'date' );
	}

	/**
	 * Get address location
	 * @return string
	 */
	public function get_location() {
		return $this->__get( 'location' );
	}

	/**
	 * Get map
	 * @return array
	 */
	public function get_map() {

		$arr = array(
			'lat'  => '',
			'lng'  => '',
			'zoom' => 14
		);

		if ( $map = $this->__get( 'map' ) ) {
			$map    = explode( '|', $map );
			$latlng = explode( ',', $map[0] );

			if ( isset( $latlng[0] ) && isset( $latlng[1] ) ) {
				$arr['lat'] = $latlng[0];
				$arr['lng'] = $latlng[1];
			}

			if ( isset( $map[1] ) ) {
				$arr['zoom'] = $map[1];
			}

		}

		return $arr;
	}

	/**
	 * Get gallery image ids
	 * @return string
	 */
	public function get_image_ids() {
		return tpfw_get_gallery_image_ids( $this->__get( 'gallery' ) );
	}


	/**
	 * Get event slug.
	 * @return string
	 */
	public function get_slug() {
		return $this->__get( 'slug' );
	}

	/**
	 * Get is comment allowed
	 * @return bool
	 */
	public function get_comment_allowed() {
		return $this->__get( 'comment_allowed' );
	}


	/**
	 * Method to read a event from the database.
	 *
	 * @param Event|WP_Post $event
	 *
	 * @throws Exception
	 */
	public function setup( $post ) {

		if ( is_numeric( $post ) ) {
			$post = get_post( $post );
		}

		if ( ! $post ) {
			throw new \Exception( __( 'Invalid event.', 'tp-base-toolkit' ) );
		}

		$this->id = $post->ID;

		$this->__set( 'name', $post->post_title );
		$this->__set( 'slug', $post->post_name );
		$this->__set( 'date_created', $post->post_date_gmt );
		$this->__set( 'date_modified', $post->post_modified_gmt );
		$this->__set( 'description', $post->post_excerpt );
		$this->__set( 'content', $post->post_content );
		$this->__set( 'parent_id', $post->post_parent );
		$this->__set( 'slug', $post->post_name );
		$this->__set( 'comment_allowed', 'open' === $post->comment_status );
		$this->__set( 'frequency', get_post_meta( $this->get_id(), '_frequency', true ) );
		$this->__set( 'location', get_post_meta( $this->get_id(), '_location', true ) );
		$this->__set( 'map', get_post_meta( $this->get_id(), '_map', true ) );
		$this->__set( 'gallery', get_post_meta( $this->get_id(), '_gallery', true ) );
		$this->setupDate();

	}

	/**
	 *
	 * Setup date data
	 *
	 * @since 1.0
	 */
	protected function setupDate() {

		$frequency = $this->get_frequency();

		$key = '_event_date_once';

		switch ( $frequency ) {
			case 'daily':
				$key = '_event_date_daily';
				break;
			case 'weekly':
				$key = '_event_date_weekly';
				break;
			case 'custom':
				$key = '_event_date_custom';
				break;
		}

		$this->__set( 'date', maybe_unserialize( get_post_meta( $this->get_id(), $key, true ) ) );

	}

	public function getDate() {
		$date = wp_parse_args( $this->get_date(), array(
			'date_starts' => '',
			'time_ends'   => ''
		) );

		return $date;
	}

	public function output_date_one() {

		$date = wp_parse_args( $this->get_date(), array(
			'starts' => '',
			'ends'   => ''
		) );

		$starts = new \DateTime( $date['starts'] );
		$ends   = new \DateTime( $date['ends'] );

		tp_base_toolkit_template( 'event/single/date-one', array(
			'date'       => $this->get_date(),
			'date_start' => $starts,
			'date_end'   => $ends,
		) );

	}

	public function output_date_daily() {

		$date = wp_parse_args( $this->get_date(), array(
			'date_starts' => '',
			'date_ends'   => '',
			'time_starts' => '',
			'time_ends'   => ''
		) );


		$starts      = new \DateTime( $date['date_starts'] );
		$ends        = new \DateTime( $date['date_ends'] );
		$time_starts = new \DateTime( $date['time_starts'] );
		$time_ends   = new \DateTime( $date['time_ends'] );

		$period = new \DatePeriod(
			$starts,
			new \DateInterval( 'P1D' ),
			$ends->modify( '+1 day' )
		);

		$items = iterator_to_array( $period );

		tp_base_toolkit_template( 'event/single/date-daily', array(
			'date_start' => $starts,
			'date_end'   => $ends,
			'time_start' => $time_starts,
			'time_end'   => $time_ends,
			'items'      => $items
		) );

	}

	public function output_date_weekly() {

		$date = wp_parse_args( $this->get_date(), array(
			'day'         => 'mon',
			'date_starts' => '',
			'date_ends'   => '',
			'time_starts' => '',
			'time_ends'   => ''
		) );

		$starts      = new \DateTime( $date['date_starts'] );
		$ends        = new \DateTime( $date['date_ends'] );
		$time_starts = new \DateTime( $date['time_starts'] );
		$time_ends   = new \DateTime( $date['time_ends'] );

		$period = new \DatePeriod(
			$starts,
			new \DateInterval( 'P1W' ),
			$ends->modify( '+1 week' )
		);

		$items = iterator_to_array( $period );

		$day = new \DateTime( $date['day'] );

		tp_base_toolkit_template( 'event/single/date-weekly', array(
			'day'        => $day,
			'date'       => $this->get_date(),
			'date_start' => $starts,
			'date_end'   => $ends,
			'time_start' => $time_starts,
			'time_end'   => $time_ends,
			'items'      => $items
		) );

	}

	public function output_date_custom() {

		$dates = wp_parse_args( $this->get_date(), array(
			array(
				'date'        => '',
				'time_starts' => '',
				'time_ends'   => ''
			)
		) );

		$items = array();

		foreach ( $dates as $date ) {
			$items[] = array(
				'date'       => new \DateTime( $date['date'] ),
				'time_start' => new \DateTime( $date['time_starts'] ),
				'time_end'   => new \DateTime( $date['time_ends'] ),
			);
		}

		$number_of_dates = count( $items ) - 1;

		tp_base_toolkit_template( 'event/single/date-custom', array(
			'items'           => $items,
			'date_start'      => $items[1]['date'],
			'date_end'        => $items[ $number_of_dates ]['date'],
			'number_of_dates' => $number_of_dates
		) );

	}

	public function getDateTimeData() {

		$date      = $this->get_date();
		$frequency = $this->get_frequency();

		$data = array(
			'date_starts' => '',
			'date_ends'   => '',
			'time_starts' => '',
			'time_ends'   => '',
			'frequency'   => $frequency
		);

		if ( $frequency == 'one' ) {
			$data['date_starts'] = new \DateTime( $date['starts'] );
			$data['date_ends']   = new \DateTime( $date['ends'] );
			$data['time_starts'] = $data['date_starts'];
			$data['time_ends']   = $data['date_ends'];
		} else if ( $frequency == 'custom' && count( $date ) ) {
			$data['date_starts'] = new \DateTime( $date[0]['date'] );
			$data['date_ends']   = new \DateTime( $date[ count( $date ) - 1 ]['date'] );
		} else {
			$data['date_starts'] = new \DateTime( $date['date_starts'] );
			$data['date_ends']   = new \DateTime( $date['date_ends'] );

			$data['time_starts'] = new \DateTime( $date['time_starts'] );
			$data['time_ends']   = new \DateTime( $date['time_ends'] );

			if ( ! empty( $date['day'] ) ) {
				$data['day'] = new \DateTime( $date['day'] );
			}
		}

		$data['year_number']  = abs($data['date_starts']->format('Y')-$data['date_ends']->format('Y'));
		$data['month_number'] = abs($data['date_starts']->format('m')-$data['date_ends']->format('m'));
		$data['day_number']   = abs($data['date_starts']->format('d')-$data['date_ends']->format('d'));

		return $data;
	}

}