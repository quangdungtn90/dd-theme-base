<?php

namespace TP_Base\Toolkit\Event;

use TP_Base\Toolkit\Event\Field\Datetime;

class Hooks {
	public function __construct() {
		
		new Register();
		new Datetime();
		
		new Admin\Customizer();
		new Admin\Metabox();
		new Query\Customizer();
		new Query\Metabox();
		
		add_filter( 'tpfw_gmap_key', array( $this, 'key' ) );
		add_action( 'init', array( $this, 'addImageSize' ) );
		add_filter( 'template_include', array( $this, 'templateLoader' ) );
		add_filter( 'wp_title', array( $this, 'titleBreadcrumb' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
		add_action( 'the_post', array( $this, 'setupData' ) );
		add_filter( 'body_class', array( $this, 'bodyClass' ) );
		add_filter( 'tp_base\toolkit\localize', array( $this, 'localize' ) );


		include 'template-functions.php';
	}

	public function localize( $arr ) {
		if ( is_singular( 'event' ) ) {
			$arr['event_map_marker'] = TP_BASE_TOOLKIT_URL . 'assets/images/map-marker.png';
			$arr['event_map_style']  = $this->mapStyle();
		}

		return $arr;
	}

	public function key( $key = '' ) {
		return get_theme_mod( 'gmap_api_key' );
	}

	/**
	 * Get map style from settings
	 *
	 * @since 1.0
	 * @return string Config
	 */
	public function mapStyle() {

		$map_style    = '';
		$map_selected = get_theme_mod( 'event_single_mapstyle', '' );
		if ( $map_selected == 'customize' ) {
			$map_style = stripcslashes( get_theme_mod( 'event_single_mapstyle_custom', '' ) );
		} else {
			$map_styles = tp_base_toolkit_get_map_styles();
			if ( isset( $map_styles[ $map_selected ] ) ) {
				$map_style = $map_styles[ $map_selected ]['configs'];
			}
		}

		return apply_filters( 'tp_base\toolkit\get_setting_map_style', $map_style );
	}

	/**
	 * Load a template.
	 *
	 * Handles template usage so that we can use our own templates instead of the themes.
	 *
	 * Templates are in the 'templates' folder. toolkit looks for theme.
	 * overrides in /theme/toolkit/ by default.
	 *
	 * @param mixed $template
	 *
	 * @return string
	 */
	public static function templateLoader( $template ) {

		if ( is_embed() ) {
			return $template;
		}

		if ( is_singular( 'event' ) ) {
			$template = tp_base_toolkit_template( 'event/single-event' );
		} else if ( is_post_type_archive( 'event' ) ) {
			$template = tp_base_toolkit_template( 'event/archive-event' );
		}

		return $template;
	}

	public function titleBreadcrumb( $title ) {
		$hook = tp_base( 'hook' )->id;
		if ( $hook == 'event' ) {
			$title = sprintf( '<h2 class="page-title">%s</h2>', esc_attr__( 'Event Details', 'tp-base-toolkit' ) );
		}

		return $title;
	}

	public function addImageSize() {
		add_image_size( 'tp-base-toolkit-event', 770, 330, true );
	}


	/**
	 * Register Front-end scripts
	 */
	public function scripts() {

		if ( is_singular( 'event' ) ) {
			
			wp_enqueue_script( 'google-map-v-3' );

			wp_enqueue_style( 'slick' );
			wp_enqueue_style( 'slick-theme' );
			wp_enqueue_script( 'slick' );
		}
	}


	/**
	 * When the_post is called, put product data into a global.
	 *
	 * @param mixed $post Post Object.
	 *
	 * @return Event
	 */
	public function setupData( $post ) {
		unset( $GLOBALS['tp_base_event'] );

		if ( is_int( $post ) ) {
			$the_post = get_post( $post );
		} else {
			$the_post = $post;
		}

		if ( empty( $the_post->post_type ) || $the_post->post_type !== 'event' ) {
			return;
		}

		$GLOBALS['tp_base_event'] = new Event( $the_post );

		return $GLOBALS['tp_base_event'];
	}

	/**
	 * Adds custom event classes to the array of body classes.
	 *
	 * @param array $classes Classes for the body element.
	 *
	 * @return array
	 */
	public function bodyClass( $classes ) {

		if ( is_singular( 'event' ) ) {

			$frequency = get_post_meta( get_the_ID(), '_frequency', true );

			if ( ! $frequency ) {
				$frequency = 'one';
			}

			$classes[] = 'event-' . $frequency;

		}

		return $classes;

	}

}