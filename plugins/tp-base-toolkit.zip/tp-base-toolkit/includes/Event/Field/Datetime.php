<?php

namespace TP_Base\Toolkit\Event\Field;

class Datetime {
	public function __construct() {
		add_filter( 'tpfw_form_event_datetime', array( $this, 'render' ), 10, 2 );
		add_action( 'tpfw_admin_event_datetime_scripts', array( $this, 'scripts' ) );
	}

	public function scripts() {
		$min = WP_DEBUG ? '' : '.min';
		wp_enqueue_script( 'datetimepicker', TPFW_URL . 'assets/vendors/datetimepicker/jquery.datetimepicker' . $min . '.js', array( 'jquery' ), TPFW_VERSION );
		wp_enqueue_style( 'datetimepicker', TPFW_URL . 'assets/vendors/datetimepicker/jquery.datetimepicker' . $min . '.css', null, TPFW_VERSION );
	}

	public function render( $field, $settings ) {

		ob_start();
		if ( method_exists( $this, $settings['data'] ) ) {
			?>
            <div class="event_datetime-field event_datetime" data-type="<?php echo esc_attr( $settings['type'] ) ?>">
				<?php
				$this->{$settings['data']}( $settings );
				?>
            </div>
			<?php
		}

		return ob_get_clean();
	}

	private function one( $settings ) {

		$date = new \Datetime();

		$value = wp_parse_args( maybe_unserialize( $settings['value'] ), array(
			'starts' => $date->format( 'Y/m/d H:i' ),
			'ends'   => $date->modify( '+1 day' )->format( 'Y/m/d H:i' ),
		) );
		?>

        <div class="datetime-row date-event-starts">
            <span class="datetime-label">
			<?php echo esc_html__( 'Starts', 'tp-base-toolkit' ) ?>
            </span>
            <span class="datepicker">
                 <i class="fa fa-calendar"></i>
                    <input class="tpfw_value" type="text" data-datepicker="1" data-timepicker="1"
                           name="<?php echo esc_attr( $settings['name'] ) ?>[starts]"
                           value="<?php echo esc_attr( $value['starts'] ) ?>"
                    />

               </span>
        </div>

        <div class="datetime-row date-event-ends">
            <span class="datetime-label">
			<?php echo esc_html__( 'Ends', 'tp-base-toolkit' ) ?>
            </span>
            <span class="datepicker">
                  <i class="fa fa-calendar"></i>
                    <input type="text" data-datepicker="1" data-timepicker="1"
                           name="<?php echo esc_attr( $settings['name'] ) ?>[ends]"
                           value="<?php echo esc_attr( $value['ends'] ) ?>"
                    />

               </span>
        </div>
		<?php
	}

	private function daily( $settings ) {
		$date  = new \Datetime();
		$value = wp_parse_args( maybe_unserialize( $settings['value'] ), array(
			'date_starts' => $date->format( 'Y/m/d' ),
			'date_ends'   => $date->modify( '+1 day' )->format( 'Y/m/d' ),
			'time_starts' => $date->format( 'H:i' ),
			'time_ends'   => $date->modify( '+1 hour' )->format( 'H:i' )
		) );

		?>

        <div class="datetime-row date-event-starts">
            <span class="datetime-label"><?php echo esc_html__( 'Starts', 'tp-base-toolkit' ) ?></span>
            <span class="datepicker">
                 <i class="fa fa-calendar"></i>
                    <input class="tpfw_value" type="text" data-datepicker="1" data-timepicker="0" data-format="Y/m/d"
                           name="<?php echo esc_attr( $settings['name'] ) ?>[date_starts]"
                           value="<?php echo esc_attr( $value['date_starts'] ) ?>"
                    />

            </span>
        </div>

        <div class="datetime-row date-event-ends">
			<span class="datetime-label"><?php echo esc_html__( 'Ends By', 'tp-base-toolkit' ) ?>
            </span>
            <span class="datepicker">
                <i class="fa fa-calendar"></i>
                    <input type="text" data-datepicker="1" data-timepicker="0" data-format="Y/m/d"
                           name="<?php echo esc_attr( $settings['name'] ) ?>[date_ends]"
                           value="<?php echo esc_attr( $value['date_ends'] ) ?>"
                    />

            </span>
        </div>

        <div class="datetime-row date-event-times">
            <span class="datetime-label">
			<?php echo esc_html__( 'Time', 'tp-base-toolkit' ) ?>
            </span>
            <span class="timepicker">
                        <i class="fa fa-clock-o"></i>
                    <input type="text" data-datepicker="0" data-timepicker="1" data-format="H:i"
                           name="<?php echo esc_attr( $settings['name'] ) ?>[time_starts]"
                           value="<?php echo esc_attr( $value['time_starts'] ) ?>"
                    />
            </span>
            <span class="timedashed">-</span>
            <span class="timepicker">
                        <i class="fa fa-clock-o"></i>
                    <input type="text" data-datepicker="0" data-timepicker="1" data-format="H:i"
                           name="<?php echo esc_attr( $settings['name'] ) ?>[time_ends]"
                           value="<?php echo esc_attr( $value['time_ends'] ) ?>"
                    />
            </span>
        </div>
		<?php
	}

	private function weekly( $settings ) {

		$date = new \Datetime();

		$value = wp_parse_args( maybe_unserialize( $settings['value'] ), array(
			'day'         => strtolower( $date->format( 'D' ) ),
			'date_starts' => $date->format( 'Y/m/d' ),
			'date_ends'   => $date->modify( '+7 days' )->format( 'Y/m/d' ),
			'time_starts' => $date->format( 'H:i' ),
			'time_ends'   => $date->modify( '+1 hour' )->format( 'H:i' )
		) );

		$settings['value'] = $value;

		$days = array(
			'sun' => esc_html__( 'Sun', 'tp-base-toolkit' ),
			'mon' => esc_html__( 'Mon', 'tp-base-toolkit' ),
			'tue' => esc_html__( 'Tue', 'tp-base-toolkit' ),
			'wed' => esc_html__( 'Wed', 'tp-base-toolkit' ),
			'thu' => esc_html__( 'Thu', 'tp-base-toolkit' ),
			'fri' => esc_html__( 'Fri', 'tp-base-toolkit' ),
			'sat' => esc_html__( 'Sat', 'tp-base-toolkit' ),
		);
		?>

        <div class="datetime-row date-event-days">

            <span class="datetime-label">
			    <?php echo esc_html__( 'Day', 'tp-base-toolkit' ) ?>
            </span>

            <div class="datetime-days">
				<?php foreach ( $days as $key => $label ) : ?>
                    <label>
                        <input type="radio" <?php checked( $key, $value['day'] ) ?>
                               name="<?php echo esc_attr( $settings['name'] ) ?>[day]"
                               value="<?php echo esc_attr( $key ) ?>"
                        />
                        <span> <?php echo esc_html( $label ) ?></span>
                    </label>
				<?php endforeach; ?>
            </div>
        </div>
		<?php

		$this->daily( $settings );
	}

	private function custom( $settings ) {

		$value = maybe_unserialize( $settings['value'] );
		$date  = new \Datetime();

		if ( ! isset( $value[0] ) || ! is_array( $value[0] ) ) {
			$value = array(
				0 => array(
					'date'        => $date->format( 'Y/m/d' ),
					'time_starts' => $date->format( 'H:i' ),
					'time_ends'   => $date->modify( '+1 hour' )->format( 'H:i' )
				)
			);
		}
		foreach ( $value as $key => $arr ):
			$clone = $key == 0 ? 'clone' : '';
			?>
            <div class="date-event-custom <?php echo esc_attr( $clone ) ?>"
                 data-name="<?php echo esc_attr( $settings['name'] ) ?>">

                <div class="datetime-row">
                    <span class="datetime-label"><?php echo esc_html__( 'Date', 'tp-base-toolkit' ) ?></span>
                    <span class="datepicker">
                     <i class="fa fa-calendar"></i>
                        <input class="tpfw_value" type="text" data-datepicker="1" data-timepicker="0"
                               data-format="Y/m/d"
                               name="<?php echo esc_attr( $settings['name'] ) ?>[<?php echo esc_attr( $key ) ?>][date]"
                               value="<?php echo esc_attr( $arr['date'] ) ?>"
                        />
                    </span>
                </div>

                <div class="datetime-row date-event-times">
                    <span class="datetime-label"><?php echo esc_html__( 'Time', 'tp-base-toolkit' ) ?></span><span
                            class="timepicker">
                            <i class="fa fa-clock-o"></i>
                        <input type="text" data-datepicker="0" data-timepicker="1" data-format="H:i"
                               name="<?php echo esc_attr( $settings['name'] ) ?>[<?php echo esc_attr( $key ) ?>][time_starts]"
                               value="<?php echo esc_attr( $arr['time_starts'] ) ?>"
                        />
                 </span>

                    <span class="timedashed"> <?php echo esc_html__( 'To', 'tp-base-toolkit' ) ?> </span>
                    <span class="timepicker">
                                <i class="fa fa-clock-o"></i>
                            <input type="text" data-datepicker="0" data-timepicker="1" data-format="H:i"
                                   name="<?php echo esc_attr( $settings['name'] ) ?>[<?php echo esc_attr( $key ) ?>][time_ends]"
                                   value="<?php echo esc_attr( $arr['time_ends'] ) ?>"
                            />
                    </span>
                    <a href="#" class="btn-removedate"><?php echo esc_html__( 'Remove', 'tp-base-toolkit' ) ?></a>

                </div>

            </div>
		<?php endforeach; ?>

        <div class="datetime-row">
            <span class="datetime-label">&nbsp;</span>
            <button type="button" class="button btn-adddate"><i class="fa fa-plus-circle"
                                                                aria-hidden="true"></i><?php echo esc_html__( 'Add more date', 'tp-base-toolkit' ) ?>
            </button>
        </div>

		<?php
	}
}