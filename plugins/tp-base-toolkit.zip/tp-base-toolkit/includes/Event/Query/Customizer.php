<?php
namespace TP_Base\Toolkit\Event\Query;


class Customizer {
	public function __construct() {
		add_filter( 'tp_base\query', array( $this, 'init' ) );
	}

	public function init($query){
		if ( $query['hook']['id'] == 'archive_event' ) {
			add_filter( 'tp_base\excerpt_length', array($this,'excerptEvent'),10 );
			$query = $this->listEvent($query);
		} else if ( $query['hook']['group'] == 'event' ) {
			$query = $this->singleEvent( $query );
		}

		return $query;
	}

	public function listEvent($query){
		$query['breadcrumb']['enable'] = get_theme_mod( 'event_breadcrumb', 'yes' );
		$query['breadcrumb']['image'] = esc_url( get_theme_mod( 'event_breadcrumb_image' ) );

		$query['sidebar']['id'] = get_theme_mod( 'event_sidebar', 'sidebar' );
		$query['sidebar']['position'] = get_theme_mod( 'event_sidebar_position', 'left' );

		return $query;
	}
	public function singleEvent($query){
		$query['breadcrumb']['enable'] = get_theme_mod( 'event_single_breadcrumb', get_theme_mod( 'event_breadcrumb', 'yes' ) );
		$query['breadcrumb']['image'] = esc_url( get_theme_mod( 'event_single_breadcrumb_image' ) );

		$query['sidebar']['id'] = get_theme_mod( 'event_single_sidebar', get_theme_mod( 'event_sidebar', 'sidebar' ));
		$query['sidebar']['position'] = get_theme_mod( 'event_single_sidebar_position', get_theme_mod( 'event_sidebar_position', 'left' ) );

		return $query;
	}


	public function excerptEvent($length){
		$length = get_theme_mod('event_excerpt_length',40);
		return $length;
	}
}