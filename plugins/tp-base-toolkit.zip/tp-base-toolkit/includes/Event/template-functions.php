<?php

/**
 * Add default room type tabs to room type pages.
 *
 * @param array $tabs tabs.
 *
 * @return array
 */
function tp_base_toolkit_get_event_single_tabs( $tabs = array() ) {
	global $post, $tp_base_event;

	// Content tab
	if ( $post->post_content ) {
		$tabs['content'] = array(
			'title'    => __( 'Introduction', 'tp-base-toolkit' ),
			'priority' => 10,
			'callback' => 'tp_base_toolkit_event_content_tab',
		);
	}

	// Event dates
	if ( $tp_base_event && $tp_base_event->get_date() && $tp_base_event->get_frequency() != 'one' ) {
		$tabs['dates'] = array(
			'title'    => __( 'Event dates', 'tp-base-toolkit' ),
			'priority' => 20,
			'callback' => 'tp_base_toolkit_event_dates_tab',
		);
	}

	$map = $tp_base_event->get_map();

	// Optional map
	if ( $tp_base_event && ! empty( $map['lat'] ) && $map['lng'] ) {
		$tabs['map'] = array(
			'title'    => __( 'View Map', 'tp-base-toolkit' ),
			'priority' => 30,
			'callback' => 'tp_base_toolkit_event_map_tab',
		);
	}

	// Optional comment
	if ( $tp_base_event && $tp_base_event->get_comment_allowed() ) {
		$tabs['comments'] = array(
			'title'    => __( 'Comments', 'tp-base-toolkit' ),
			'priority' => 30,
			'callback' => 'tp_base_toolkit_event_comment_tab',
		);
	}

	return $tabs;
}

add_filter( 'tp_base\toolkit\event_single_tabs', 'tp_base_toolkit_get_event_single_tabs', 10 );


function tp_base_toolkit_event_content_tab() {
	tp_base_toolkit_template( 'event/single/tabs/content' );
}

function tp_base_toolkit_event_dates_tab() {
	tp_base_toolkit_template( 'event/single/tabs/dates' );
}

function tp_base_toolkit_event_comment_tab() {
	tp_base_toolkit_template( 'event/single/tabs/comment' );
}

function tp_base_toolkit_event_single_tabs() {
	tp_base_toolkit_template( 'event/single/tabs/tabs' );
}

function tp_base_toolkit_event_map_tab() {
	tp_base_toolkit_template( 'event/single/tabs/map' );
}

add_action( 'tp_base\toolkit\event_single_content', 'tp_base_toolkit_event_single_tabs' );

function tp_base_toolkit_event_single_image() {
	tp_base_toolkit_template( 'event/single/event-image' );
}

function tp_base_toolkit_event_single_thumbnails() {
	tp_base_toolkit_template( 'event/single/event-image-thumbnails' );
}

function tp_base_toolkit_event_related_args(){

	global $post;
	$args = array(
		'post_type'           => array( $post->post_type ),
		'post__not_in'        => array( $post->ID ),
		'ignore_sticky_posts' => 1,
		'orderby'               => 'rand',
		'posts_per_page'      => 2
	);
	return apply_filters( 'tp_base\event_related_args', $args );
}

function tp_base_toolkit_event_single_related() {
	tp_base_toolkit_template( 'event/single/event-related' );
}

add_action( 'tp_base\toolkit\event_single_thumbnails', 'tp_base_toolkit_event_single_thumbnails' );

function tp_base_toolkit_event_placeholder_img_src() {
	return apply_filters( 'event/placeholder_img_src', TP_BASE_TOOLKIT_URL . '/assets/images/placeholder.png' );
}


function tp_base_toolkit_event_get_location() {
	global $tp_base_event;
	$location = $tp_base_event->get_location();
	if ( ! $location ) {
		return;
	}

	tp_base_toolkit_template( 'event/single/meta/location', array( 'location' => $location ) );
}

add_action( 'tp_base\toolkit\event_meta', 'tp_base_toolkit_event_get_location' );

function tp_base_toolkit_event_single_datetime_meta() {

	global $tp_base_event;
	$data = $tp_base_event->getDateTimeData();
	tp_base_toolkit_template( 'event/single/meta/date-' . $tp_base_event->get_frequency(), $data );

}

add_action( 'tp_base\toolkit\event_meta', 'tp_base_toolkit_event_single_datetime_meta', 5 );
add_action( 'tp_base\toolkit\event_datetime_list', 'tp_base_toolkit_event_single_datetime_meta' );


function tp_base_toolkit_event_vc_excerpt() {
	return apply_filters( 'tp-base\toolkit\event_slider_vc', 50 );
}
function tp_base_toolkit_event_box_vc_excerpt() {
	return apply_filters( 'tp-base\toolkit\event_box_vc', 20 );
}

/**
 * Display date start
 */
function tp_base_toolkit_event_loop_date_start() {
	global $tp_base_event;
	$data = $tp_base_event->getDateTimeData();
	tp_base_toolkit_template( 'event/loop/date-start', $data );
}