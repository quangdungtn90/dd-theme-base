<?php

/**
 * Sanitize switch with yes or no
 * @return string
 */
function tp_base_toolkit_sanitize_switch( $value ) {
	if ( !in_array( $value, array( 'yes', 'no' ) ) ) {
		return 'yes';
	}

	return $value;
}

/**
 * Sanitize Sidebar position
 * 
 * @return string
 */
function tp_base_toolkit_sanitize_sidebar_position( $value ) {
	if ( !in_array( $value, array( 'left', 'none', 'right' ) ) ) {
		return 'right';
	}

	return $value;
}


/**
 * Get number from string
 * @since 1.0
 * @return number
 */
function tp_base_toolkit_sanitize_phone_number( $str ) {
	preg_match_all( '/[+,0-9]/', $str, $matches );
	if ( is_array( $matches[0] ) ) {
		return implode( '', $matches[0] );
	}

	return $matches[0];
}
