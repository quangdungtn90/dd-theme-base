<?php

namespace TP_Base\Toolkit\Query;

class Customizer {

	public function __construct() {
		add_filter( 'tp_base\query', array( $this, 'init' ) );
	}

	public function init( $query ) {

		switch ( $query['hook']['id'] ) {
			case 'post':
				$query = $this->post( $query );
				break;
			case 'page':
			case 'front_page':
				$query = $this->page( $query );
				break;
			case 'blog_page':
			case 'latest_posts':
			case 'category':
			case 'post_tag':
			case 'search':
			case 'archive':
				$query = $this->blog( $query );
				break;
		}

		return $this->footer( $query );
	}

	public function footer( $query ) {

		$query['header']['topbar_show_link'] = get_theme_mod( 'header_show_topbar_link');
		$query['header']['topbar']      = $query['header']['topbar_show_link'] || class_exists( '\WooCommerce' );


		$query['footer']['style']          = get_theme_mod( 'footer_style', 'default' );
		$query['footer']['widgets_enable'] = get_theme_mod( 'footer_widgets_enable', true );

		$query['footer']['widgets'] = array();

		$query['footer']['widgets'][0] = get_theme_mod( 'footer_sidebar_1', 'sidebar-footer' );
		$query['footer']['widgets'][1] = get_theme_mod( 'footer_sidebar_2', 'sidebar-footer-2' );
		$query['footer']['widgets'][2] = get_theme_mod( 'footer_sidebar_3', 'sidebar-footer-3' );
		$query['footer']['widgets'][3] = get_theme_mod( 'footer_sidebar_4', 'sidebar-footer-4' );

		return $query;
	}

	public function page( $query ) {

		$query['breadcrumb']['enable'] = get_theme_mod( 'page_breadcrumb', 'yes' );
		$query['breadcrumb']['image']  = esc_url( get_theme_mod( 'page_breadcrumb_image' ) );

		$query['content']['spacing'] = get_theme_mod( 'page_content_spacing', 'yes' );

		$query['sidebar']['id']       = get_theme_mod( 'page_sidebar', 'sidebar' );
		$query['sidebar']['position'] = get_theme_mod( 'page_sidebar_position', 'right' );

		return $query;
	}

	public function post( $query ) {

		$query['breadcrumb']['enable'] = get_theme_mod( 'post_breadcrumb', 'yes' );
		$query['breadcrumb']['image']  = esc_url( get_theme_mod( 'post_breadcrumb_image' ) );

		$query['sidebar']['id']       = get_theme_mod( 'post_sidebar', 'sidebar' );
		$query['sidebar']['position'] = get_theme_mod( 'post_sidebar_position', 'right' );

		$query['content']['show_author_link']   = get_theme_mod( 'post_author_link', true );
		$query['content']['show_date']          = get_theme_mod( 'post_on', true );
		$query['content']['show_comment_count'] = get_theme_mod( 'post_comment_count', true );
		$query['content']['show_categories']    = get_theme_mod( 'post_categories', true );
		$query['content']['show_tags']          = get_theme_mod( 'post_tags', true );
		$query['content']['show_sharing']       = get_theme_mod( 'post_share', true );
		$query['content']['show_nav']           = get_theme_mod( 'post_nav', true );
		$query['content']['show_related']       = get_theme_mod( 'post_related', true );
		$query['content']['show_biography']     = get_theme_mod( 'post_biography', true );

		$query['content']['related_limit'] = get_theme_mod( 'post_related_limit', 3 );
		$query['content']['related_by']    = get_theme_mod( 'post_related_get_by', 'category' );

		return $query;
	}

	public function blog( $query ) {

		$query['breadcrumb']['enable'] = get_theme_mod( 'blog_breadcrumb', 'yes' );
		$query['breadcrumb']['image']  = esc_url( get_theme_mod( 'blog_breadcrumb_image' ) );

		$query['sidebar']['id']       = get_theme_mod( 'blog_sidebar', 'sidebar' );
		$query['sidebar']['position'] = get_theme_mod( 'blog_sidebar_position', 'right' );

		$query['content']['show_author_link']   = get_theme_mod( 'blog_show_author', true );
		$query['content']['show_date']          = get_theme_mod( 'blog_show_date', true );
		$query['content']['show_comment_count'] = get_theme_mod( 'blog_show_comment_count', true );
		$query['content']['show_categories']    = false;
		$query['content']['show_tags']          = false;
		$query['content']['show_sharing']       = get_theme_mod( 'blog_show_sharing', true );
		$query['content']['show_readmore']      = get_theme_mod( 'blog_show_readmore', true );

		return $query;
	}

}
