<?php

namespace TP_Base\Toolkit\Query;

/**
 * Override metabox and taxonomy settings to customizer
 */
class Metabox {

	public function __construct() {
		add_filter( 'tp_base\query', array( $this, 'init' ), 15 );
	}

	/**
	 * Init functions
	 */
	public function init( $query ) {

		switch ( $query['hook']['id'] ) {
			case 'post':
				$query = $this->post( $query );
				break;
			case 'page':
			case 'front_page':
				$query = $this->page( $query );
				break;
			case 'blog_page':
				$query = $this->blog( $query, 'post' );
				break;
			case 'category':
			case 'post_tag':
				$query = $this->blog( $query, 'term' );
				break;
		}

		return $query;
	}

	/**
	 * Override Single Post or Post type Footer to customizer
	 * @return void
	 */
	protected function general( $query, $type = 'term', $post_id = 0 ) {
		/**
		 * Breadcrumb
		 */
		$query['breadcrumb']['enable'] = tp_base_toolkit_sanitize_switch( get_metadata( $type, $post_id, '_breadcrumb', true ) );
		$query['breadcrumb']['image'] = wp_get_attachment_url( get_metadata( $type, $post_id, '_breadcrumb_image', true ) );

		/**
		 * Sidebar
		 */
		if ( $sidebar_id = get_metadata( $type, $post_id, '_sidebar', true ) ) {
			$query['sidebar']['id'] = $sidebar_id;
		}
		$query['sidebar']['position'] = tp_base_toolkit_sanitize_sidebar_position( get_metadata( $type, $post_id, '_sidebar_position', true ));

		/**
		 * Footer
		 */
		if ( $style = get_metadata( $type, $post_id, '_footer_style', true ) ) {
			$query['footer']['style'] = $style;
		}

		$query['footer']['widgets_enable'] = get_metadata( $type, $post_id, '_footer_sidebar', true );

		if ( $query['footer']['widgets_enable'] ) {

			if ( $footer1 = get_metadata( $type, $post_id, '_sidebar_footer_1', true ) ) {
				$query['footer']['widgets'][0] = $footer1;
			}
			if ( $footer2 = get_metadata( $type, $post_id, '_sidebar_footer_2', true ) ) {
				$query['footer']['widgets'][1] = $footer2;
			}
			if ( $footer3 = get_metadata( $type, $post_id, '_sidebar_footer_3', true ) ) {
				$query['footer']['widgets'][2] = $footer3;
			}
			if ( $footer4 = get_metadata( $type, $post_id, '_sidebar_footer_4', true ) ) {
				$query['footer']['widgets'][3] = $footer4;
			}
			
		}

		return $query;
	}

	/**
	 * Get content options
	 * @param string $type
	 * @param int $post_id or $term_id
	 * @return array
	 */
	protected function getContentOptions( $type, $post_id ) {

		$content_options = get_metadata( $type, $post_id, '_content_options', true );

		if ( !empty( $content_options ) ) {
			$content_options = explode( ',', $content_options );
			$content_options = array_flip( $content_options );
		}

		return $content_options;
	}

	public function page( $query ) {

		if ( get_post_meta( get_the_ID(), '_advanced_settings', true ) ) {

			$query['content']['spacing'] = tp_base_toolkit_sanitize_switch( get_post_meta( get_the_ID(), '_content_spacing', true ) );
			$query['content']['show_title'] = absint( get_post_meta( get_the_ID(), '_content_title', true ) );

			$query = $this->general( $query, 'post', get_the_ID() );
		}

		return $query;
	}

	public function post( $query ) {

		$post_id = get_the_ID();

		if ( get_post_meta( $post_id, '_advanced_settings', true ) ) {

			/**
			 * Override Content options
			 */
			$content_options = $this->getContentOptions( 'post', $post_id );


			$query['content']['show_author_link'] = isset( $content_options['post_author'] );
			$query['content']['show_date'] = isset( $content_options['post_on'] );
			$query['content']['show_comment_count'] = isset( $content_options['post_comment'] );
			$query['content']['show_categories'] = isset( $content_options['post_categories'] );
			$query['content']['show_tags'] = isset( $content_options['post_tags'] );
			$query['content']['show_sharing'] = isset( $content_options['post_share'] );
			$query['content']['show_nav'] = isset( $content_options['post_nav'] );
			$query['content']['show_biography'] = isset( $content_options['post_biography'] );
			$query['content']['show_related'] = isset( $content_options['post_related'] );

			$query['content']['related_ids'] = get_post_meta( $post_id, '_related_ids', true );
			$query['content']['related_by'] = get_post_meta( $post_id, '_related_get_by', true );
			$query['content']['related_limit'] = get_post_meta( $post_id, '_related_limit', true );

			$query = $this->general( $query, 'post', get_the_ID() );
		}

		return $query;
	}

	public function blog( $query, $type = 'term' ) {

		$post_id = 0;

		if ( $type == 'term' ) {
			$post_id = get_queried_object()->term_id;
		} else {
			$post_id = get_queried_object()->ID;
		}

		if ( get_metadata( $type, $post_id, '_advanced_settings', true ) ) {

			/**
			 * Override Content options
			 */
			$content_options = $this->getContentOptions( $type, $post_id );


			$query['content']['show_author_link'] = isset( $content_options['post_author'] );
			$query['content']['show_date'] = isset( $content_options['post_on'] );
			$query['content']['show_comment_count'] = isset( $content_options['post_comment_count'] );
			$query['content']['show_sharing'] = isset( $content_options['post_share'] );
			$query['content']['morelink'] = isset( $content_options['morelink'] );

			$query = $this->general( $query, $type, $post_id );
		}

		return $query;
	}

}
