<?php

/**
 * Include helper or core functions
 * @package TP_Base_Toolkit
 *
 * @category Functions
 * @since 1.0
 */

/**
 * Get template file path
 * @since 1.0
 * @return string
 */
function tp_base_toolkit_template_path( $slug ) {
	$template = apply_filters( 'tp_base\toolkit\template_path', get_template_directory() . '/template-parts/toolkit' ) . '/' . $slug . '.php';

	if ( !file_exists( $template ) ) {
		$template = TP_BASE_TOOLKIT_DIR . 'templates/' . $slug . '.php';
	}

	return $template;
}

/**
 * Include template file
 *
 * @since 1.0
 */
function tp_base_toolkit_template( $slug, $data = array() ) {

	if ( is_array( $data ) ) {
		extract( $data );
	}

	$template = tp_base_toolkit_template_path( $slug );

	include $template;
}

/**
 * Get content of template file
 *
 * @since 1.0
 */
function tp_base_toolkit_get_template( $slug, $data = array() ) {
	ob_start();
	tp_base_toolkit_template( $slug, $data );

	return ob_get_clean();
}

/**
 * Get Post Order
 * @since 1.0
 *
 * @return array
 */
function tp_base_toolkit_get_post_orders( $key = '' ) {
	$order = array(
		'date' => esc_attr__( 'Date', 'tp-base-toolkit' ),
		'ID' => esc_attr__( 'ID', 'tp-base-toolkit' ),
		'author' => esc_attr__( 'Author', 'tp-base-toolkit' ),
		'rand' => esc_attr__( 'Random', 'tp-base-toolkit' ),
		'comment_count' => esc_attr__( 'Most Commented', 'tp-base-toolkit' ),
	);

	if ( function_exists( 'MN_Reorder' ) ) {
		$order['menu_order'] = esc_html__( 'Menu order/Page Order', 'tp-base-toolkit' );
	}

	if ( function_exists( 'Post_Views_Counter' ) ) {
		$order['post_views'] = esc_html__( 'Most Viewed (Post Views Counter)', 'tp-base-toolkit' );
	}

	if ( $key != '' ) {
		return isset( $order[$key] ) ? $order[$key] : '';
	}

	return apply_filters( 'tp_base\toolkit\get_post_orders', $order );
}

/**
 * Custom Post Query
 * @since 1.0
 * @return array
 */
function tp_base_toolkit_query( $post_type, $args ) {
	$query = array(
		'post_type' => $post_type,
		'ignore_sticky_posts' => true
	);

	if ( isset( $args['post__not_in'] ) ) {
		$query['post__not_in'] = $args['post__not_in'];
	}

	$cat_type = '';

	$query['orderby'] = $args['orderby'];

	if ( $post_type == 'post' ) {
		$cat_type = 'category';
	} else if ( $post_type == 'product' ) {
		$cat_type = 'product_cat';

		$viewed_products = null;
		if ( !empty( $_COOKIE['woocommerce_recently_viewed'] ) ) {
			$viewed_products = (array) explode( '|', $_COOKIE['woocommerce_recently_viewed'] );
		} else {
			$viewed_products = array( '' );
			//return false;
		}
		$viewed_products = array_reverse( array_filter( array_map( 'absint', $viewed_products ) ) );
		if ( $args['orderby'] == 'recentview' ) {
			$args['orderby'] = 'post__in';
			$query['post__in'] = $viewed_products;
		} elseif ( $args['orderby'] == 'rate' ) {

			$query['meta_key'] = '_wc_average_rating';
			$query['orderby'] = 'meta_value_num';
		}
	}
	
	if ( !empty( $args['datasource'] ) ) {
		if ( $args['datasource'] == 'ids' ) {
			$query['post__in'] = explode( ',', !empty( $args['include'] ) ? $args['include'] : '' );
			$query['orderby'] = 'post__in';

			return $query;
		}
	}
	
	$query['order'] = 'date';
	if ( !empty( $args['order'] ) ) {
		$query['order'] = $args['order'];
	}
	$query['posts_per_page'] = 8;
	if ( !empty( $args['posts_per_page'] ) ) {
		$query['posts_per_page'] = $args['posts_per_page'];
	}
	$query['offset'] = 0;
	if ( !empty( $args['posts_per_page'] ) ) {
		$query['offset'] = $args['offset'];
	}
	$categories = array();
	if ( !empty( $args['categories'] ) ) {
		$categories = is_array( $args['categories'] ) ? $args['categories'] : explode( ',', str_replace( " ", "", $args['categories'] ) );
	}

	if ( !empty( $args['categories'][0] ) ) {
		$query['tax_query'][] = array(
			'taxonomy' => $cat_type,
			'field' => 'slug',
			'terms' => $categories,
		);
	}

	$tags = array();
	if ( !empty( $args['tags'] ) ) {
		$tags = is_array( $args['tags'] ) ? $args['tags'] : explode( ',', $args['tags'] );
	}
	if ( !empty( $args['tags'][0] ) ) {
		$query['tax_query'][] = array(
			'taxonomy' => 'post_tag',
			'field' => 'slug',
			'terms' => $tags,
		);
	}

	if ( isset( $query['tax_query'] ) && count( $query['tax_query'] ) == 2 ) {
		$query['tax_query']['relation'] = $args['relation'];
	}

	return $query;
}

/**
 * Get term name by term slug
 * 
 * @param type $slug
 * @param type $term
 * @return string
 */
function tp_base_toolkit_get_term_name_by_slug( $slug, $term ) {
	$term = get_term_by( 'slug', $slug, $term, 'ARRAY_A' );
	return $term['name'];
}

/**
 * Get post content
 *
 * @param int $post_id
 *
 * @return html Post Content
 * @since 1.0
 */
function tp_base_toolkit_post_content( $post_id ) {

	$post = get_post( $post_id );

	if ( !empty( $post ) ) {
		return do_shortcode( force_balance_tags( $post->post_content ) );
	}
}

/**
 * Get registered sidebar
 *
 * @param array $arr
 *
 * @return array
 */
function tp_base_toolkit_get_sidebars( $arr = array() ) {
	global $wp_registered_sidebars;

	$sidebars = array_map( function ( $arr ) {
		return $arr['name'];
	}, $wp_registered_sidebars );
	if ( !empty( $arr ) ) {
		return array_merge( $arr, $sidebars );
	}

	return $sidebars;
}

/**
 * A Array template for social list
 *
 * @category Config Data
 * @since 1.0
 */
function tp_base_toolkit_social_list( $type = 'share', $name = '' ) {

	$arr = include TP_BASE_TOOLKIT_DIR . '/includes/socials.php';

	if ( $type == 'share' ) {
		$newarr = array();
		foreach ( $arr as $key => $value ) {
			if ( !empty( $value['share_url'] ) ) {
				$newarr[$key] = $value;
			}
		}

		$arr = $newarr;
	}

	$list = apply_filters( 'tp_base\toolkit\social_list', $arr );

	if ( empty( $name ) ) {
		return $list;
	}

	foreach ( $list as $_key => $value ) {
		if ( $name == $_key ) {
			return $list[$name];
		}
	}

	return 0;
}

/**
 * Display social share by post
 * @since 1.0
 *
 * @param bool $echo
 * @param array|bool $list_data
 *
 * @return void
 */
function tp_base_toolkit_social_sharing( $echo = false ) {

	$list = tp_base_toolkit_social_list();

	$list_data = get_theme_mod( 'socials', array( 'facebook', 'twitter', 'gplus' ) );

	$output = '';

	if ( !empty( $list_data ) && is_array( $list_data ) ) {

		$output .= '<ul class="social-links">';

		foreach ( $list_data as $id ) {
			$value = isset( $list[$id] ) ? $list[$id] : false;
			if ( $value ) {
				$link = '#';
				if ( !empty( $value['share_url'] ) ) {
					$link = str_replace(
							array( '[post-url]', '[post-title]', '[post-desc]', '[post-img]' ), array(
						urlencode( get_the_permalink() ),
						get_the_title(),
						get_the_excerpt(),
						''
							), $value['share_url'] );
				}

				$output .= sprintf( '<li><a href="%s" class="social-item--%s" title="%s"><i class="%s"></i></a></li>', esc_url( $link ), esc_attr( $id ), esc_attr( $value['text'] ), esc_attr( $value['icons'][0] ) );
			}
		}

		$output .= '</ul>';
	}

	echo apply_filters( 'tp_base\toolkit\social_sharing', $output, $list_data );
}

/**
 * Config map styles
 * @since 1.0
 *
 * @return array
 */
function tp_base_toolkit_get_map_styles() {
	$arr = array(
		'' => array(
			'name' => __( 'Standard', 'tp-base-toolkit' ),
			'configs' => '',
			'image' => TP_BASE_TOOLKIT_URL . '/assets/images/map-standard.png'
		),
		'style_1' => array(
			'image' => TP_BASE_TOOLKIT_URL . '/assets/images/map-blue.png',
			'name' => __( 'Blue Sky', 'tp-base-toolkit' ),
			'configs' => '[{"featureType": "administrative", "elementType": "labels.text.fill", "stylers": [{"color": "#444444"}]}, {"featureType": "landscape", "elementType": "all", "stylers": [{"color": "#f2f2f2"}]}, {"featureType": "poi", "elementType": "all", "stylers": [{"visibility": "off"}]}, {"featureType": "road", "elementType": "all", "stylers": [{"saturation": -100}, {"lightness": 45}]}, {"featureType": "road.highway", "elementType": "all", "stylers": [{"visibility": "simplified"}]}, {"featureType": "road.arterial", "elementType": "labels.icon", "stylers": [{"visibility": "off"}]}, {"featureType": "transit", "elementType": "all", "stylers": [{"visibility": "off"}]}, {"featureType": "water", "elementType": "all", "stylers": [{"color": "#46bcec"}, {"visibility": "on"}]}]'
		),
		'style_2' => array(
			'image' => TP_BASE_TOOLKIT_URL . '/assets/images/map-light.png',
			'name' => __( 'Light Purple', 'tp-base-toolkit' ),
			'configs' => '[{"featureType":"landscape.natural","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#e0efef"}]},{"featureType":"poi","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"hue":"#1900ff"},{"color":"#c0e8e8"}]},{"featureType":"road","elementType":"geometry","stylers":[{"lightness":100},{"visibility":"simplified"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"transit.line","elementType":"geometry","stylers":[{"visibility":"on"},{"lightness":700}]},{"featureType":"water","elementType":"all","stylers":[{"color":"#7dcdcd"}]}]'
		),
		'style_3' => array(
			'image' => TP_BASE_TOOLKIT_URL . '/assets/images/map-gray.png',
			'name' => __( 'Gray', 'tp-base-toolkit' ),
			'configs' => '[{"featureType": "administrative", "elementType": "labels.text.fill", "stylers": [{"color": "#444444"}]}, {"featureType": "landscape", "elementType": "all", "stylers": [{"color": "#e9e4e1"}, {"visibility": "on"}]}, {"featureType": "landscape", "elementType": "labels.text", "stylers": [{"color": "#444444"}]}, {"featureType": "landscape", "elementType": "labels.text.fill", "stylers": [{"color": "#797979"}]}, {"featureType": "landscape", "elementType": "labels.text.stroke", "stylers": [{"color": "#e9e4e1"}]}, {"featureType": "poi", "elementType": "all", "stylers": [{"visibility": "off"}]}, {"featureType": "road", "elementType": "all", "stylers": [{"saturation": -100}, {"lightness": 45}, {"visibility": "on"}]}, {"featureType": "road", "elementType": "geometry.stroke", "stylers": [{"color": "#d8cdcd"}]}, {"featureType": "road", "elementType": "labels.icon", "stylers": [{"visibility": "off"}]}, {"featureType": "road.highway", "elementType": "all", "stylers": [{"visibility": "simplified"}]}, {"featureType": "road.highway", "elementType": "labels.icon", "stylers": [{"visibility": "off"}]}, {"featureType": "road.highway.controlled_access", "elementType": "all", "stylers": [{"visibility": "simplified"}]}, {"featureType": "road.highway.controlled_access", "elementType": "labels.icon", "stylers": [{"visibility": "off"}]}, {"featureType": "road.arterial", "elementType": "labels.icon", "stylers": [{"visibility": "off"}]}, {"featureType": "transit", "elementType": "all", "stylers": [{"visibility": "off"}]}, {"featureType": "transit.line", "elementType": "all", "stylers": [{"visibility": "off"}]}, {"featureType": "transit.station", "elementType": "all", "stylers": [{"visibility": "off"}]}, {"featureType": "water", "elementType": "all", "stylers": [{"color": "#f6f5f1"}, {"visibility": "on"}]}]'
		)
	);

	return apply_filters( 'tp_base\toolkit\get_map_styles', $arr );
}

/**
 * Get key and label map styles
 * @since 1.0
 * @return array
 */
function tp_base_toolkit_get_map_styles_opt() {
	$arr = tp_base_toolkit_get_map_styles();
	$new = array();
	foreach ( $arr as $key => $value ) {
		$new[$key] = $value['image'];
	}

	$new['customize'] = TP_BASE_TOOLKIT_URL . '/assets/images/map-custom.png';

	return $new;
}
