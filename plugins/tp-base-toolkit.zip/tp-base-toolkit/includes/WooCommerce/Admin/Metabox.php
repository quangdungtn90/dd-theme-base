<?php

namespace TP_Base\Toolkit\WooCommerce\Admin;

use TP_Base\Toolkit\Admin\Metabox as TP_Base_Metabox;

class Metabox extends TP_Base_Metabox {

	public function __construct() {

		add_action( 'tpfw_metabox_init', array( $this, 'productBox' ) );
		//add_action( 'tpfw_metabox_init', array( $this, 'shopPage' ) );
		add_action( 'tpfw_termbox_init', array( $this, 'taxonomyBox' ) );
	}

	/**
	 * Advanded box settings in single post
	 * @since 1.0
	 * @return void
	 */
	public function productBox() {

		$fields = array(
			array(
				'name' => '_breadcrumb',
				'type' => 'radio',
				'heading' => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
				'options' => array(
					'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
					'no' => esc_attr__( 'Disable', 'tp-base-toolkit' ),
				),
				'display_inline' => true,
				'value' => 'yes',
				'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
			),
			array(
				'name' => '_breadcrumb_image',
				'type' => 'image_picker',
				'heading' => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
				'desc' => esc_html__( 'Select a background image for breadcrumb.', 'tp-base-toolkit' )
			),
			array(
				'name' => '_content_options',
				'type' => 'checkbox',
				'multiple' => true,
				'heading' => esc_html__( 'Content Options', 'tp-base-toolkit' ),
				'options' => array(
					'show_price' => esc_attr__( 'Show price', 'tp-base-toolkit' ),
					'show_rating' => esc_attr__( 'Show rating', 'tp-base-toolkit' ),
					'show_excerpt' => esc_attr__( 'Show excerpt', 'tp-base-toolkit' ),
					'show_add_to_cart' => esc_html__( 'Show Add to cart', 'tp-base-toolkit' ),
					'show_sku' => esc_attr__( 'Show SKU', 'tp-base-toolkit' ),
					'show_categories' => esc_attr__( 'Show categories', 'tp-base-toolkit' ),
					'show_tags' => esc_attr__( 'Show tags', 'tp-base-toolkit' ),
					'show_upsell' => esc_attr__( 'Show upsell products', 'tp-base-toolkit' ),
					'show_related' => esc_attr__( 'Show related products', 'tp-base-toolkit' ),
				),
				'value' => array(
					'show_price',
					'show_rating',
					'show_excerpt',
					'show_add_to_cart',
					'show_sku',
					'show_categories',
					'show_tags',
					'show_upsell',
					'show_related'
				),
				'desc' => esc_html__( 'Show or hide content option in this shop detail', 'tp-base-toolkit' ),
			),
		);

		new \Tpfw_Metabox( array(
			'id' => '_advanced_settings',
			'screens' => array( 'product' ),
			'heading' => esc_html__( 'Advanced Settings', 'tp-base-toolkit' ),
			'context' => 'advanced', //side
			'priority' => 'low',
			'manage_box' => true,
			'fields' => array_merge( $fields, $this->footerArgs() )
				) );
	}

	private function _shopListFields() {

		$fields = array(
			array(
				'name' => '_breadcrumb',
				'type' => 'radio',
				'heading' => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
				'options' => array(
					'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
					'no' => esc_attr__( 'Disable', 'tp-base-toolkit' ),
				),
				'display_inline' => true,
				'value' => 'yes',
				'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
			),
			array(
				'name' => '_breadcrumb_image',
				'type' => 'image_picker',
				'heading' => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
				'desc' => esc_html__( 'Select a background image for breadcrumb.', 'tp-base-toolkit' )
			),
			array(
				'name' => '_content_options',
				'type' => 'checkbox',
				'multiple' => true,
				'heading' => esc_html__( 'Content Options', 'tp-base-toolkit' ),
				'options' => array(
					'show_rating' => esc_attr__( 'Show rating', 'tp-base-toolkit' ),
					'show_price' => esc_attr__( 'Show price', 'tp-base-toolkit' ),
					'show_add_to_cart' => esc_attr__( 'Show add to cart', 'tp-base-toolkit' ),
				),
				'value' => array( 'show_rating', 'show_price', 'show_add_to_cart' ),
				'desc' => esc_html__( 'Show or hide content option in this category', 'tp-base-toolkit' ),
			)
		);

		return array_merge( $fields, $this->footerArgs() );
	}

	/**
	 * Advanded box settings in category
	 * @since 1.0
	 * @return void
	 */
	public function taxonomyBox() {

		new \Tpfw_Taxonomy( array(
			'id' => '_advanced_settings',
			'pages' => array( 'product_cat', 'product_tag' ),
			'heading' => esc_html__( 'Advanced Settings', 'tp-base-toolkit' ),
			'context' => 'advanced', //side
			'priority' => 'low',
			'manage_box' => true,
			'fields' => $this->_shopListFields()
				) );
	}

	/**
	 * Advanded box settings in shop page
	 * @since 1.0
	 * @return void
	 */
	public function shopPage() {

		new \Tpfw_Metabox( array(
			'id' => '_advanced_settings',
			'screens' => array( 'page' ),
			'heading' => esc_html__( 'Advanced Settings', 'tp-base-toolkit' ),
			'context' => 'advanced', //side
			'priority' => 'low',
			'manage_box' => true,
			'fields' => $this->_shopListFields()
				) );
	}

}
