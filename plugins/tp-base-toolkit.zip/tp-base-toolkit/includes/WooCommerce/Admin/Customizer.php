<?php

namespace TP_Base\Toolkit\WooCommerce\Admin;

class Customizer {

	public function __construct() {
		add_action( 'customize_register', array( $this, 'init' ), 11 );
	}

	public $wp_customizer;
	public $sidebars;

	public function init( $wp_customizer ) {

		$this->wp_customizer = $wp_customizer;

		$nonce = array( '' => esc_attr__( '-- Select sidebar --', 'tp-base-toolkit' ) );

		$this->sidebars = tp_base_toolkit_get_sidebars( $nonce );

		$this->shop();
		$this->shopSingle();
	}

	public function shop() {
		$section = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'          => 'shop',
			'heading'     => esc_attr__( 'Shop', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Settings for shop list, these settings can be overridden by advanced settings in shop category, shop tags and shop page.', 'tp-base-toolkit' ),
			'fields'      => array(
				array(
					'name'              => 'shop_breadcrumb',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
				),
				array(
					'name'       => 'shop_breadcrumb_image',
					'type'       => 'image',
					'heading'    => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'dependency' => array(
						'shop_breadcrumb' => array( 'values' => 'yes' )
					)
				),
				array(
					'name'              => 'shop_sidebar_position',
					'type'              => 'image_select',
					'heading'           => esc_html__( 'Sidebar Position', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'left'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
						'none'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
						'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'right',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
				),
				array(
					'name'       => 'shop_sidebar',
					'type'       => 'select',
					'heading'    => esc_attr__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'shop_sidebar',
					'dependency' => array(
						'shop_sidebar_position' => array( 'values' => array( 'left', 'right' ) )
					)
				),
				array(
					'name'    => 'shop_content_option_label',
					'type'    => 'heading',
					'heading' => esc_html__( 'Content Options', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'shop_content_price',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show price', 'tp-base-toolkit' ),
					'value'   => 1
				),
				array(
					'name'    => 'shop_content_rating',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show rating', 'tp-base-toolkit' ),
					'value'   => 1
				),
				array(
					'name'    => 'shop_content_add_to_cart',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show add to cart', 'tp-base-toolkit' ),
					'value'   => 1
				)
			)
		) );
	}

	public function shopSingle() {
		$section = new \Tpfw_Customize_Section( $this->wp_customizer, array(
			'id'      => 'product',
			'heading' => esc_attr__( 'Shop Single', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Settings for shop detail, these settings can be overridden by advanced settings in individual product.', 'tp-base-toolkit' ),
			'fields'  => array(
				array(
					'name'              => 'product_breadcrumb',
					'type'              => 'radio',
					'heading'           => esc_html__( 'Breadcrumb', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'yes' => esc_attr__( 'Enable', 'tp-base-toolkit' ),
						'no'  => esc_attr__( 'Disable', 'tp-base-toolkit' ),
					),
					'value'             => 'yes',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_switch'
				),
				array(
					'name'       => 'product_breadcrumb_image',
					'type'       => 'image',
					'heading'    => esc_html__( 'Breadcrumb Image', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'dependency' => array(
						'product_breadcrumb' => array( 'values' => 'yes' )
					)
				),
				array(
					'name'              => 'product_sidebar_position',
					'type'              => 'image_select',
					'heading'           => esc_html__( 'Sidebar Position', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'options'           => array(
						'left'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-left.jpg',
						'none'  => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-none.jpg',
						'right' => TP_BASE_TOOLKIT_URL . '/assets/images/sidebar-right.jpg'
					),
					'image_size'        => array( '70px', 'auto' ),
					'value'             => 'right',
					'sanitize_callback' => 'tp_base_toolkit_sanitize_sidebar_position'
				),
				array(
					'name'       => 'product_sidebar',
					'type'       => 'select',
					'heading'    => esc_attr__( 'Select sidebar', 'tp-base-toolkit' ),
					'transport'  => 'refresh',
					'options'    => $this->sidebars,
					'value'      => 'shop_sidebar',
					'dependency' => array(
						'product_sidebar_position' => array( 'values' => array( 'left', 'right' ) )
					)
				),
				array(
					'name'    => 'product_content_option_label',
					'type'    => 'heading',
					'heading' => esc_html__( 'Content Options', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'product_price',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show price', 'tp-base-toolkit' ),
					'value'   => 1
				),
				array(
					'name'    => 'product_rating',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show rating', 'tp-base-toolkit' ),
					'value'   => 1
				),
				array(
					'name'    => 'product_excerpt',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show summary', 'tp-base-toolkit' ),
					'value'   => 1
				),
				array(
					'name'    => 'product_add_to_cart',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show add to cart', 'tp-base-toolkit' ),
					'value'   => 1
				),
				array(
					'name'    => 'product_sku',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show SKU', 'tp-base-toolkit' ),
					'value'   => 1
				),
				array(
					'name'    => 'product_cat',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show categories', 'tp-base-toolkit' ),
					'value'   => 1
				),
				array(
					'name'    => 'product_tag',
					'type'    => 'checkbox',
					'heading' => esc_html__( 'Show tags', 'tp-base-toolkit' ),
					'value'   => 1
				),
				array(
					'name'    => 'product_upsell',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show upsell products', 'tp-base-toolkit' ),
				),
				array(
					'name'    => 'product_related',
					'type'    => 'checkbox',
					'value'   => 1,
					'heading' => esc_html__( 'Show related products', 'tp-base-toolkit' ),
				),
				array(
					'name'       => 'product_related_get_by',
					'type'       => 'select',
					'heading'    => esc_html__( 'Related options', 'tp-base-toolkit' ),
					'options'    => array(
						'category' => esc_attr__( 'Category', 'tp-base-toolkit' ),
						'tags'     => esc_attr__( 'Tags', 'tp-base-toolkit' )
					),
					'value'      => 'category',
					'dependency' => array(
						'product_related' => array( 'values' => 1 )
					),
				),
				array(
					'name'              => 'product_related_limit',
					'type'              => 'text',
					'heading'           => esc_html__( 'Releated limit number', 'tp-base-toolkit' ),
					'transport'         => 'refresh',
					'value'             => 3,
					'sanitize_callback' => 'absint',
					'dependency'        => array(
						'product_related' => array( 'values' => 1 )
					),
				)
			)
		) );
	}

}
