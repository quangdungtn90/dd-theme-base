<?php

namespace TP_Base\Toolkit\WooCommerce;

/**
 * Minicart class
 * This class is required WooCommerce plugin to work
 *
 * @package Tp_Base
 * @version 1.0
 */

class MiniCart {

	public function __construct() {
		add_action( 'wp_ajax_tp_base_minicart_remove_item', array( $this, 'ajaxRemoveItem' ) );
		add_action( 'wp_ajax_nopriv_tp_base_minicart_remove_item', array( $this, 'ajaxRemoveItem' ) );
	}

	/**
	 * Ajax Remove item in minicart
	 * @since 1.0
	 */
	public function ajaxRemoveItem() {

		if ( ! empty( $_POST['remove_item'] ) && isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'woocommerce-cart' ) ) {
			$cart_item_key = sanitize_text_field( $_POST['remove_item'] );
			if ( $cart_item = WC()->cart->get_cart_item( $cart_item_key ) ) {
				WC()->cart->remove_cart_item( $cart_item_key );
				\WC_AJAX::get_refreshed_fragments();
			}
		}
		wp_send_json_error();
	}

	/**
	 * Display template minicart
	 * @since 1.0
	 */
	public function template() {

		$quantities = WC()->cart->get_cart_item_quantities();
		$quantities = array_sum( $quantities );
		?>
        <div class="minicart <?php echo( ! is_cart() ? 'ajax' : '' ) ?>">

            <a class="minicart__heading" href="<?php echo esc_url( wc_get_cart_url() ) ?>">
                <i class="fa fa-shopping-cart"></i>
                <span class="minicart__count"><?php printf( '<span class="cart_quantity">%d</span>', $quantities) ?>
            </a>

            <div class="minicart__content hide_cart_widget_if_empty">
                <section class="widget woocommerce widget_shopping_cart">
                    <div class="widget_shopping_cart_content">
                    </div>
                </section>
            </div>

        </div>
		<?php
	}

}

