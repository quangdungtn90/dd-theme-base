<?php

namespace TP_Base\Toolkit\WooCommerce;

class Hooks {

	public function __construct() {

		new Admin\Customizer();
		new Admin\Metabox();

		new Query\Customizer();
		new Query\Metabox();

		add_action( 'plugins_loaded', array( $this, 'init' ) );
		add_action( 'wp_queque_scripts', array( $this, 'enqueueScripts' ) );
	}

	public function init() {
		if ( class_exists( '\Vc_Manager' ) && class_exists( '\WooCommerce' ) ) {
			new Vc\Products();
		}
	}

	public function enqueueScripts() {
		if ( class_exists( '\WooCommerce' ) ) {
			wp_enqueue_script( 'wc-add-to-cart-variation' );
		}
	}

}
