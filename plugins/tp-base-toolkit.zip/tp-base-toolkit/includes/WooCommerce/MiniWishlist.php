<?php

namespace TP_Base\Toolkit\WooCommerce;

/**
 * Minicart class
 * This class is required YITH WooCommerce Wishlist plugin to work
 *
 * @package TP_Base
 * @since 1.0
 */


class MiniWishlist {

	function __construct() {

		add_action( 'wp_ajax_tp_base_get_mini_wishlist', array( $this, 'ajaxGetMiniWishlist' ) );
		add_action( 'wp_ajax_nopriv_tp_base_get_mini_wishlist', array( $this, 'ajaxGetMiniWishlist' ) );

		add_action( 'wp_ajax_tp_base_remove_from_wishlist', array( $this, 'ajaxRemoveItem' ) );
		add_action( 'wp_ajax_nopriv_tp_base_remove_from_wishlist', array( $this, 'ajaxRemoveItem' ) );

	}

	/**
	 * Template from plugin
	 * @see YITH_WCWL_Shortcode::wishlist()
	 */
	public function miniWishlist( $atts = array(), $content = null ) {
		global $yith_wcwl_is_wishlist, $yith_wcwl_wishlist_token;
		$atts = shortcode_atts( array(
			'per_page'    => - 1,
			'pagination'  => 'no',
			'wishlist_id' => false
		), $atts );

		$available_views = apply_filters( 'yith_wcwl_available_wishlist_views', array( 'view', 'user' ) );

		extract( $atts );

		// retrieve options from query string
		$action_params = get_query_var( 'wishlist-action', false );
		$action_params = explode( '/', $action_params );
		$action        = ( isset( $action_params[0] ) ) ? $action_params[0] : 'view';

		$user_id = isset( $_GET['user_id'] ) ? $_GET['user_id'] : false;

		// init params needed to load correct tempalte
		$additional_params = array();
		$template_part     = 'view';

		/* === WISHLIST TEMPLATE === */
		if (
			empty( $action ) ||
			( ! empty( $action ) && ( $action == 'view' || $action == 'user' ) ) ||
			( ! empty( $action ) && ( $action == 'manage' || $action == 'create' ) && get_option( 'yith_wcwl_multi_wishlist_enable', false ) != 'yes' ) ||
			( ! empty( $action ) && ! in_array( $action, $available_views ) ) ||
			! empty( $user_id )
		) {
			/*
			 * someone is requesting a wishlist
			 * -if user is not logged in..
			 *  -and no wishlist_id is passed, cookie wishlist is loaded
			 *  -and a wishlist_id is passed, checks if wishlist is public or shared, and shows it only in this case
			 * -if user is logged in..
			 *  -and no wishlist_id is passed, default wishlist is loaded
			 *  -and a wishlist_id is passed, checks owner of the wishlist
			 *   -if wishlist is of the logged user, shows it
			 *   -if wishlist is of another user, checks if wishlist is public or shared, and shows it only in this case (if user is admin, can see all wishlists)
			 */

			if ( empty( $wishlist_id ) ) {
				if ( ! empty( $action ) && $action == 'user' ) {
					$user_id = isset( $action_params[1] ) ? $action_params[1] : false;
					$user_id = ( ! $user_id ) ? get_query_var( $user_id, false ) : $user_id;
					$user_id = ( ! $user_id ) ? get_current_user_id() : $user_id;

					$wishlists = YITH_WCWL()->get_wishlists( array( 'user_id' => $user_id, 'is_default' => 1 ) );

					if ( ! empty( $wishlists ) && isset( $wishlists[0] ) ) {
						$wishlist_id = $wishlists[0]['wishlist_token'];
					} else {
						$wishlist_id = false;
					}
				} else {
					$wishlist_id = isset( $action_params[1] ) ? $action_params[1] : false;
					$wishlist_id = ( ! $wishlist_id ) ? get_query_var( 'wishlist_id', false ) : $wishlist_id;
				}
			}

			$yith_wcwl_wishlist_token = $wishlist_id;

			$is_user_owner = false;
			$query_args    = array();

			if ( ! empty( $user_id ) ) {
				$query_args['user_id']    = $user_id;
				$query_args['is_default'] = 1;

				if ( get_current_user_id() == $user_id ) {
					$is_user_owner = true;
				}
			} elseif ( ! is_user_logged_in() ) {
				if ( empty( $wishlist_id ) ) {
					$query_args['wishlist_id'] = false;
					$is_user_owner             = true;
				} else {
					$is_user_owner = false;

					$query_args['wishlist_token']      = $wishlist_id;
					$query_args['wishlist_visibility'] = 'visible';
				}
			} else {
				if ( empty( $wishlist_id ) ) {
					$query_args['user_id']    = get_current_user_id();
					$query_args['is_default'] = 1;
					$is_user_owner            = true;
				} else {
					$wishlist      = YITH_WCWL()->get_wishlist_detail_by_token( $wishlist_id );
					$is_user_owner = $wishlist['user_id'] == get_current_user_id();

					$query_args['wishlist_token'] = $wishlist_id;

					if ( ! empty( $wishlist ) && $wishlist['user_id'] != get_current_user_id() ) {
						$query_args['user_id'] = false;
						if ( ! current_user_can( 'manage_options' ) ) {
							$query_args['wishlist_visibility'] = 'visible';
						}
					}
				}
			}

			if ( empty( $wishlist_id ) ) {
				$wishlists = YITH_WCWL()->get_wishlists( array(
					'user_id'    => get_current_user_id(),
					'is_default' => 1
				) );
				if ( ! empty( $wishlists ) ) {
					$wishlist_id = $wishlists[0]['wishlist_token'];
				}
			}

			// retrieve items to print
			global $wishlist_items;
			$wishlist_items = YITH_WCWL()->get_products( $query_args );

			// retrieve wishlist information
			$wishlist_meta = YITH_WCWL()->get_wishlist_detail_by_token( $wishlist_id );
		}

		tp_base_toolkit_template( 'miniwishlist' );

		// we're not in wishlist template anymore
		$yith_wcwl_is_wishlist    = false;
		$yith_wcwl_wishlist_token = null;
	}

	/**
	 * Ajax remove item in mini wishlist
	 * @since Tako 1.0
	 * @return void
	 */
	public function ajaxRemoveItem() {

		$wishlist_token = isset( $_GET['wishlist_token'] ) ? sanitize_text_field( $_GET['wishlist_token'] ) : false;
		$count          = yith_wcwl_count_products( $wishlist_token );

		$message = '';

		if ( $count != 0 ) {
			if ( YITH_WCWL()->remove() ) {
				$message = apply_filters( 'yith_wcwl_product_removed_text', esc_html__( 'Product successfully removed.', 'tp-base-toolkit' ) );
				$count --;
			} else {
				$message = apply_filters( 'yith_wcwl_unable_to_remove_product_message', esc_html__( 'Error. Unable to remove the product from the wishlist.', 'tp-base-toolkit' ) );
			}
		} else {
			$message = apply_filters( 'yith_wcwl_no_product_to_remove_message', esc_html__( 'No products were added to the wishlist', 'tp-base-toolkit' ) );
		}

		wc_add_notice( $message );

		$atts = array( 'wishlist_id' => $wishlist_token );
		if ( isset( $_GET['pagination'] ) ) {
			$atts['pagination'] = $_GET['pagination'];
		}

		if ( isset( $_GET['per_page'] ) ) {
			$atts['per_page'] = $_GET['per_page'];
		}

		wp_send_json_success();
	}

	/**
	 * Ajax get miniwish list
	 * @since 1.0
	 * @return void
	 */
	public function ajaxGetMiniWishlist() {

		$wishlist_id = isset( $_POST['wishlist_id'] ) ? absint( $_POST['wishlist_id'] ) : false;

		$atts = array(
			'per_page'    => - 1,
			'pagination'  => 'no',
			'wishlist_id' => $wishlist_id
		);
		ob_start();
		$this->miniWishlist( $atts );
		wp_send_json( ob_get_clean() );
	}

	/**
	 * Display template
	 * @since 1.0
	 * @return void
	 */
	public function template() {

		$count_products = yith_wcwl_count_products();
		?>
        <div class="miniwishlist <?php echo esc_attr( $count_products > 0 ? '' : 'miniwishlist--empty' ) ?>">
            <a class="miniwishlist__heading" href="<?php echo esc_url( YITH_WCWL()->get_wishlist_url() ) ?>">
                <i class="fa fa-heart"></i>
                <span><?php echo esc_html( $count_products ) ?></span>
            </a>

            <div class="miniwishlist__content">
				<?php $this->miniWishlist(); ?>
            </div>

        </div>
		<?php
	}

}

