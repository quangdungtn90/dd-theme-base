<?php

namespace TP_Base\Toolkit\WooCommerce\Query;

class Customizer {

	public function __construct() {
		add_filter( 'tp_base\query', array( $this, 'init' ), 15 );
	}

	public function init( $query ) {

		if ( $query['hook']['id'] == 'product' ) {
			$query = $this->single( $query );
		} else if ( $query['hook']['group'] == 'shop' ) {
			$query = $this->shop( $query );
		}

		return $query;
	}

	public function shop( $query ) {

		$query['breadcrumb']['enable'] = get_theme_mod( 'shop_breadcrumb', 'yes' );
		$query['breadcrumb']['image'] = esc_url( get_theme_mod( 'shop_breadcrumb_image' ) );

		$query['sidebar']['id'] = get_theme_mod( 'shop_sidebar', 'shop_sidebar' );
		$query['sidebar']['position'] = get_theme_mod( 'shop_sidebar_position', 'right' );

		$query['content']['show_price'] = get_theme_mod( 'shop_content_price', true );
		$query['content']['show_rating'] = get_theme_mod( 'shop_content_rating', true );
		$query['content']['show_add_to_cart'] = get_theme_mod( 'shop_content_add_to_cart', true );

		return $query;
	}

	public function single( $query ) {

		$query['breadcrumb']['enable'] = get_theme_mod( 'product_breadcrumb', 'yes' );
		$query['breadcrumb']['image'] = esc_url( get_theme_mod( 'product_breadcrumb_image' ) );

		$query['sidebar']['id'] = get_theme_mod( 'product_sidebar', 'shop_sidebar' );
		$query['sidebar']['position'] = get_theme_mod( 'product_sidebar_position', 'right' );

		$query['content']['show_price'] = get_theme_mod( 'product_price', true );
		$query['content']['show_rating'] = get_theme_mod( 'product_rating', true );
		$query['content']['show_excerpt'] = get_theme_mod( 'product_excerpt', true );
		$query['content']['show_add_to_cart'] = get_theme_mod( 'product_add_to_cart', true );
		$query['content']['show_sku'] = get_theme_mod( 'product_sku', true );
		$query['content']['show_categories'] = get_theme_mod( 'product_cat', true );
		$query['content']['show_tags'] = get_theme_mod( 'product_tag', true );
		$query['content']['show_upsell'] = get_theme_mod( 'product_upsell', true );
		$query['content']['show_related'] = get_theme_mod( 'product_related', true );
		$query['content']['related_by'] = get_theme_mod( 'product_related_get_by', true );
		$query['content']['related_limit'] = get_theme_mod( 'product_related_limit', 3 );


		return $query;
	}

}
