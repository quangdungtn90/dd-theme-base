<?php

namespace TP_Base\Toolkit\WooCommerce\Query;

use TP_Base\Toolkit\Query\Metabox as TP_Base_Query_Metabox;

class Metabox extends TP_Base_Query_Metabox {

	public function __construct() {
		add_filter( 'tp_base\query', array( $this, 'init' ), 15 );
	}

	public function init( $query ) {

		if ( $query['hook']['id'] == 'product' ) {
			$query = $this->shopSingle( $query );
		} else if ( $query['hook']['group'] == 'shop' ) {
			$query = $this->shop( $query );
		}

		return $query;
	}

	public function shop( $query ) {

		$post_id = 0;
		$type = 'term';

		if ( is_shop() ) {
			$post_id = wc_get_page_id( 'shop' );
			$type = 'post';
		} else {
			$post_id = get_queried_object()->term_id;
		}

		if ( get_metadata( $type, $post_id, '_advanced_settings', true ) ) {

			/**
			 * Override Content options
			 */
			if ( $type == 'term' ) {
				$content_options = $this->getContentOptions( $type, $post_id );

				$query['content']['show_rating'] = isset( $content_options['show_rating'] );
				$query['content']['show_price'] = isset( $content_options['show_price'] );
				$query['content']['show_add_to_cart'] = isset( $content_options['show_add_to_cart'] );
				$query = $this->general( $query, 'term', $post_id );
			} else {
				$query = $this->page( $query );
			}
		}

		return $query;
	}

	public function shopSingle( $query ) {

		$post_id = get_the_ID();

		if ( get_post_meta( $post_id, '_advanced_settings', true ) ) {
			
			/**
			 * Override Content options
			 */
			$content_options = $this->getContentOptions( 'post', $post_id );

			$query['content']['show_rating'] = isset( $content_options['show_rating'] );
			$query['content']['show_price'] = isset( $content_options['show_price'] );
			$query['content']['show_excerpt'] = isset( $content_options['show_excerpt'] );
			$query['content']['show_sku'] = isset( $content_options['show_sku'] );
			$query['content']['show_categories'] = isset( $content_options['show_categories'] );
			$query['content']['show_tags'] = isset( $content_options['show_tags'] );
			$query['content']['show_add_to_cart'] = isset( $content_options['show_add_to_cart'] );
			$query['content']['show_upsell'] = isset( $content_options['show_upsell'] );
			$query['content']['show_related'] = isset( $content_options['show_related'] );


			$query = $this->general( $query, 'post', $post_id );
		}
		
		return $query;
	}

}
