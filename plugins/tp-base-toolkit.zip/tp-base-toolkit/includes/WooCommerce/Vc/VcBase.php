<?php

namespace TP_Base\Toolkit\WooCommerce\Vc;

abstract class VcBase {

	/**
	 * Autocomplete search term for product categories
	 * 
	 * Function product categories search
	 * For Visual Composer Autocomplete Param
	 * Provide suggestion result
	 * 
	 * @param string $search_string
	 * @return array categories suggestion result
	 */
	public function categories_search( $search_string ) {
		$data = array();
		$terms = get_terms( array(
			'taxonomy' => 'product_cat',
			'hide_empty' => false,
			'search' => $search_string
				) );

		if ( !empty( $terms ) && is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$data[] = array(
					'label' => $term->name,
					'value' => $term->slug,
					'group_id' => $term->taxonomy,
				);
			}
		}

		return $data;
	}

	/*
	 * Function product categories render
	 * For Visual Composer Autocomplete Param
	 * 
	 * @param string $search_string
	 * @return an array categories( value, label ) selected by user
	 */

	public function categories_render( $query ) {
		$term = get_term_by( 'slug', $query['value'], 'product_cat' );

		if ( $term ) {
			$query['label'] = $term->name;
		}
		return $query;
	}

	/*
	 * Function product tags search
	 * For Visual Composer Autocomplete Param
	 * 
	 * @param string $search_string
	 * @return array  - tags suggestion result
	 */

	public function tags_search( $search_string ) {

		$data = array();

		$terms = get_terms( array(
			'taxonomy' => 'product_tag',
			'hide_empty' => false,
			'search' => $search_string
				) );

		if ( !empty( $terms ) && is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$data[] = array(
					'label' => $term->name,
					'value' => $term->slug,
					'group_id' => $term->taxonomy,
				);
			}
		}

		return $data;
	}

	/*
	 * Function product tags render
	 * For Visual Composer Autocomplete Param
	 * 
	 * @param string $search_string
	 * @return an array tags( value, label ) selected by user
	 */

	public function tags_render( $query ) {
		$term = get_term_by( 'slug', $query['value'], 'product_tag' );
		if ( $term ) {
			$query['label'] = $term->name;
		}
		return $query;
	}

	/**
	 * Autocomplete search term for products
	 * For Visual Composer Autocomplete Param
	 * Provide suggestion result
	 * 
	 * @param string $search_string
	 * @return array posts suggestion result
	 */
	public function products_search( $search_string ) {

		$data = array();

		$posts = get_posts( array(
			'post_type' => 'product',
			'post_status' => 'publish',
			's' => $search_string,
			'posts_per_page' => 10
				) );
		if ( $posts ) {
			foreach ( $posts as $post ) {
				$data[] = array(
					'label' => $post->post_title,
					'value' => $post->ID,
					'group_id' => $post->post_type,
				);
			}
		}

		return $data;
	}

	/**
	 * Autocomplete render term for product
	 * For Visual Composer Autocomplete Param
	 * Display term item as a label
	 * 
	 * @param array $query
	 * @return array post suggestion result
	 */
	public function products_render( $query ) {

		$post = get_post( $query['value'] );

		if ( $post ) {
			$query['label'] = $post->post_title;
		}

		return $query;
	}

	/**
	 * Product query args
	 * @since 1.0
	 * @param array $args
	 * @return array
	 */
	public function queryArgs( $args = array() ) {

		$args = wp_parse_args( $args, array(
			'product_cat' => '',
			'product_tag' => '',
			'relation' => '',
			'orderby' => 'date',
			'order' => 'DESC',
			'posts_per_page' => 6,
			'offset' => 0,
			'datasource' => 'query',
			'include' => '',
			'product_attribute' => '',
			'attribute_relation' => 'or'
				) );

		extract( $args );

		$meta_query = WC()->query->get_meta_query();

		$tax_query = array();

		$args = array(
			'post_type' => 'product',
			'post_status' => 'publish',
			'ignore_sticky_posts' => 1,
			'posts_per_page' => $posts_per_page
		);

		if ( $datasource == 'ids' ) {
			$args['post__in'] = explode( ',', !empty( $include ) ? $include : '' );
			$args['orderby'] = 'post__in';
			return $args;
		}

		if ( $posts_per_page ) {
			$args['offset'] = $offset;
		}

		switch ( $orderby ) {
			case 'featured':
				$tax_query[] = array(
					'taxonomy' => 'product_visibility',
					'field' => 'name',
					'terms' => 'featured',
					'operator' => 'IN',
				);
				break;
			case 'best_seller':
				$tax_query = WC()->query->get_tax_query();
				$args['orderby'] = 'meta_value_num';
				$args['meta_orderby'] = 'total_sales';
				break;
			case 'rated':
				$tax_query = WC()->query->get_tax_query();
				$args['meta_orderby'] = '_wc_average_rating';
				$args['orderby'] = 'meta_value_num';
				$args['order'] = $order;
				break;
			case 'onsale':
				$args['post__in'] = wc_get_product_ids_on_sale();
				$args['no_found_rows'] = 1;
				break;
			case 'comment_count':
				$args['orderby'] = 'comment_count';
				$args['order'] = $order;
				break;
			default :
				$args['orderby'] = 'date';
				$args['order'] = $order;
				break;
		}


		if ( !empty( $product_cat ) ) {
			$tax_query[] = array(
				'taxonomy' => 'product_cat',
				'terms' => explode( ',', $product_cat ),
				'field' => 'slug',
			);
		}

		if ( !empty( $product_tag ) ) {
			$tax_query[] = array(
				'taxonomy' => 'product_tag',
				'terms' => explode( ',', $product_tag ),
				'field' => 'slug',
			);
		}

		if ( !empty( $product_attribute ) ) {

			$product_attribute = explode( ',', $product_attribute );
			$attrbute_query = array(
				'relation' => $attribute_relation
			);

			foreach ( $product_attribute as $value ) {
				$attrbute_query[] = $this->attributeArgs( $value );
			}

			$tax_query[] = $attrbute_query;
		}

		if ( !$relation && !($product_tag || !$product_cat) ) {
			$tax_query['relation'] = $relation;
		}

		$args['meta_query'] = $meta_query;
		$args['tax_query'] = $tax_query;

		return $args;
	}

	/**
	 * @param string $value
	 * @return array Tax Query
	 */
	public function attributeArgs( $value ) {

		$value = trim( $value );
		$taxonomy_attr = explode( '&', $value );
		$taxonomy = $taxonomy_attr[0];
		$attribute = str_replace( 'amp;', '', $taxonomy_attr[1] );

		return array(
			'taxonomy' => $taxonomy,
			'field' => 'slug',
			'terms' => array( $attribute )
		);
	}

	/**
	 * Function product term attributes search
	 * For Visual Composer Autocomplete Param
	 *
	 * @param string $search_string
	 *
	 * @return array  - tags suggestion result
	 */
	public function attributes_search( $search_string ) {

		$taxonomies = wc_get_attribute_taxonomies();

		$attributes_types = array();

		foreach ( $taxonomies as $taxonomy ) {
			$attributes_types[$taxonomy->attribute_label] = wc_attribute_taxonomy_name( $taxonomy->attribute_name );
		}

		$results = array();

		$terms = get_terms( array(
			'taxonomy' => $attributes_types,
			'hide_empty' => false,
			'search' => $search_string
				) );

		if ( is_array( $terms ) && !empty( $terms ) ) {

			$attributes_types = array_flip( $attributes_types );

			foreach ( $terms as $term ) {
				$results[] = array(
					'label' => $term->name,
					'value' => $term->taxonomy . '&' . $term->slug,
					'group_id' => $term->taxonomy,
					'group' => $attributes_types[$term->taxonomy]
				);
			}
		}

		return $results;
	}

	/**
	 * Function product term attributes render
	 * For Visual Composer Autocomplete Param
	 *
	 * @param string $query
	 *
	 * @return array attributes( value, label ) selected by user
	 */
	public function attributes_render( $query ) {

		$arr = explode( '&', $query['value'] );

		if ( isset( $arr[1] ) ) {
			if ( $term = get_term_by( 'slug', $arr[1], $arr[0] ) ) {
				$query['label'] = $term->name;
			}
		}


		return $query;
	}
	
	/**
	 * Order by options to display in select param
	 * @return array
	 */
	public function getOrderbyOpts() {
		$orderby = array(
			esc_attr__( 'Date', 'tp-base-toolkit' ) => 'date',
			esc_attr__( 'Commented', 'tp-base-toolkit' ) => 'comment_count',
			esc_attr__( 'Rated', 'tp-base-toolkit' ) => 'rated',
			esc_attr__( 'Best Sale', 'tp-base-toolkit' ) => 'best_seller',
			esc_attr__( 'On Sale', 'tp-base-toolkit' ) => 'onsale',
			esc_attr__( 'Featured', 'tp-base-toolkit' ) => 'featured',
		);

		return apply_filters( 'tp_base\toolkit\product_orderby_opts', $orderby );
	}

}
