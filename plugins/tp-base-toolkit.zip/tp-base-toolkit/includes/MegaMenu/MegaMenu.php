<?php

namespace TP_Base\Toolkit\MegaMenu;

class MegaMenu {

	public function __construct() {
		add_action( 'init', array( $this, 'postType' ) );
		add_filter( 'tpfw_menu_fields', array( $this, 'fields' ) );
		add_action( 'wp_nav_menu_args', array( $this, 'navMenuArgs' ) );
	}

	/**
	 * Register Custom Post Type
	 */
	public function postType() {

		$labels = array(
			'name' => esc_html_x( 'Megamenu Item', 'Post Type General Name', 'tp-base-toolkit' ),
			'singular_name' => esc_html_x( 'megamenu-item', 'Post Type Singular Name', 'tp-base-toolkit' ),
			'menu_name' => esc_html__( 'Megamenu Item', 'tp-base-toolkit' ),
			'name_admin_bar' => esc_html__( 'Megamenu Content', 'tp-base-toolkit' ),
			'archives' => esc_html__( 'Item Archives', 'tp-base-toolkit' ),
			'attributes' => esc_html__( 'Item Attributes', 'tp-base-toolkit' ),
			'parent_item_colon' => esc_html__( 'Parent Item:', 'tp-base-toolkit' ),
			'all_items' => esc_html__( 'All Items', 'tp-base-toolkit' ),
			'add_new_item' => esc_html__( 'Add New Item', 'tp-base-toolkit' ),
			'add_new' => esc_html__( 'Add New', 'tp-base-toolkit' ),
			'new_item' => esc_html__( 'New Item', 'tp-base-toolkit' ),
			'edit_item' => esc_html__( 'Edit Item', 'tp-base-toolkit' ),
			'update_item' => esc_html__( 'Update Item', 'tp-base-toolkit' ),
			'view_item' => esc_html__( 'View Item', 'tp-base-toolkit' ),
			'view_items' => esc_html__( 'View Items', 'tp-base-toolkit' ),
			'search_items' => esc_html__( 'Search Item', 'tp-base-toolkit' ),
			'not_found' => esc_html__( 'Not found', 'tp-base-toolkit' ),
			'not_found_in_trash' => esc_html__( 'Not found in Trash', 'tp-base-toolkit' ),
			'featured_image' => esc_html__( 'Featured Image', 'tp-base-toolkit' ),
			'set_featured_image' => esc_html__( 'Set featured image', 'tp-base-toolkit' ),
			'remove_featured_image' => esc_html__( 'Remove featured image', 'tp-base-toolkit' ),
			'use_featured_image' => esc_html__( 'Use as featured image', 'tp-base-toolkit' ),
			'insert_into_item' => esc_html__( 'Insert into item', 'tp-base-toolkit' ),
			'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'tp-base-toolkit' ),
			'items_list' => esc_html__( 'Items list', 'tp-base-toolkit' ),
			'items_list_navigation' => esc_html__( 'Items list navigation', 'tp-base-toolkit' ),
			'filter_items_list' => esc_html__( 'Filter items list', 'tp-base-toolkit' ),
		);
		$args = array(
			'label' => esc_html__( 'megamenu-item', 'tp-base-toolkit' ),
			'description' => esc_html__( 'Block content for megamenu', 'tp-base-toolkit' ),
			'labels' => $labels,
			'supports' => array( 'title', 'editor', ),
			'hierarchical' => true,
			'public' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'menu_position' => 30,
			'menu_icon' => 'dashicons-image-rotate-right',
			'show_in_admin_bar' => true,
			'show_in_nav_menus' => true,
			'can_export' => true,
			'has_archive' => true,
			'exclude_from_search' => false,
			'publicly_queryable' => true,
			'capability_type' => 'page',
		);
		register_post_type( 'megamenu', $args );
	}

	/**
	 * Hook to nav menu args
	 * @since 1.0
	 *
	 * @param array $args
	 *
	 * @return array
	 */
	public function navMenuArgs( $args ) {

		if ( isset( $args['theme_location'] ) && $args['theme_location'] == 'primary' ) {
			$args['walker'] = new WalkerMenu();
		}

		return $args;
	}

	/**
	 * Declare Mega menu form field
	 * 
	 * @since 1.0
	 * @param array $fields Form fields
	 * @return array Menu form fields
	 */
	public function fields( $fields ) {

		$fields[] = array(
			'type' => 'checkbox',
			'heading' => esc_html__( 'Enable advanced setting?', 'tp-base-toolkit' ),
			'name' => '_advanced_settings',
			'value' => 0,
		);

		$fields[] = array(
			'type' => 'icon_picker',
			'heading' => esc_html__( 'Navigation Icon', 'tp-base-toolkit' ),
			'name' => '_icon',
			'value' => '',
			'dependency' => array(
				'_advanced_settings' => array( 'values' => 1 )
			)
		);

		$fields[] = array(
			'type' => 'textfield',
			'heading' => esc_html__( 'Tip text', 'tp-base-toolkit' ),
			'name' => '_label',
			'value' => '',
			'dependency' => array(
				'_advanced_settings' => array( 'values' => 1 )
			)
		);

		$fields[] = array(
			'type' => 'color_picker',
			'heading' => esc_html__( 'Tip color', 'tp-base-toolkit' ),
			'name' => '_label_color',
			'value' => '',
			'dependency' => array(
				'_advanced_settings' => array( 'values' => 1 )
			)
		);

		$fields[] = array(
			'type' => 'checkbox',
			'heading' => esc_html__( 'Enable megamenu?', 'tp-base-toolkit' ),
			'name' => '_mega_menu',
			'value' => 0,
		);

		$fields[] = array(
			'type' => 'autocomplete',
			'heading' => esc_html__( 'Mega menu content', 'tp-base-toolkit' ),
			'name' => '_page_id',
			'placeholder' => esc_attr__( 'Search content...', 'tp-base-toolkit' ),
			'data' => array( 'post_type' => array( 'megamenu' ) ),
			'dependency' => array(
				'_mega_menu' => array( 'values' => 1 )
			)
		);

		$fields[] = array(
			'type' => 'select',
			'heading' => esc_html__( 'Mega menu style', 'tp-base-toolkit' ),
			'name' => '_container_style',
			'value' => '',
			'options' => array(
				'' => esc_attr__( 'Default', 'tp-base-toolkit' ),
				'stretch' => esc_attr__( 'Stretch content', 'tp-base-toolkit' )
			),
			'dependency' => array(
				'_mega_menu' => array( 'values' => 1 )
			)
		);


		return $fields;
	}

}
