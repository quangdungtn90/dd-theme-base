jQuery(function ($) {

    $.fn.tpTestimonialSlider = function () {

        var $testimonial = $(this);
        
        /**
         * Testmonial
         */
        $testimonial.find('.testimonial_slider__info').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            asNavFor: '.testimonial_slider__image',
            infinite: true,
            dots: false,
            centerMode: true,
        });

        $testimonial.find('.testimonial_slider__image').slick({
            slidesToShow: 5,
            slidesToScroll: 1,
            asNavFor: '.testimonial_slider__info',
            dots: false,
            centerMode: true,
            focusOnSelect: true,
            infinite: true,
            loop:true,
            centerPadding: 0,
            responsive: [
                {
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: 0,
                        slidesToShow: 3
                    }
                }
            ]
        });
    }

    $.fn.tpMap = function (e) {


        if (!window.hasOwnProperty('google')) {
            return;
        }

        var map = {
            init: function ($map) {
                var data = $map.data();
                var center = {lat: data.lat, lng: data.lng};

                var argMap = {
                    center: center,
                    zoom: data.zoom
                };

                if (data.style) {
                    argMap.styles = data.style;
                }

                var map = new google.maps.Map(document.getElementById($map.attr('id')), argMap);

                var args = {
                    position: center,
                    map: map,
                    animation: google.maps.Animation.DROP
                };

                if (data.icon) {
                    args.icon = {
                        url: data.icon,
                        origin: new google.maps.Point(0, 0),
                        anchor: new google.maps.Point(0, 0)
                    };
                }

                var infowindow = new google.maps.InfoWindow({
                    content: data.description
                });

                var marker = new google.maps.Marker(args);

                marker.addListener('click', function () {
                    infowindow.open(map, marker);
                });

                if (data.height) {
                    $map.height(data.height);
                }
            }
        };

        $(this).each(function () {
            map.init($(this));
        });

    }


    $.fn.tpSingleEventTab = function () {

        var eventMap = function () {

            if (!window.hasOwnProperty('google')) {
                return;
            }

            var $singleMap = $('#event-map');

            var center = {lat: $singleMap.data('lat'), lng: $singleMap.data('lng')};

            var mapArgs = {
                center: center,
                zoom: $singleMap.data('zoom'),
                styles: tp_base_toolkit.event_map_style ? JSON.parse(tp_base_toolkit.event_map_style) : null
            };

            var map = new google.maps.Map(document.getElementById('event-map'), mapArgs);

            var image = {
                url: tp_base_toolkit.event_map_marker,
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(0, 0)
            };

            var infowindow = new google.maps.InfoWindow({
                content: $singleMap.data('address')
            });

            var marker = new google.maps.Marker({
                position: center,
                icon: image,
                map: map,
                animation: google.maps.Animation.DROP
            });

            marker.addListener('click', function () {
                infowindow.open(map, marker);
            });

            $('.event-map').addClass('loaded');
        };

        $(this).each(function () {

            var $el = $(this);

            var $control = $el.find('.event-tab__controls');
            var $content = $el.find('.event-tab__content');

            $control.find('li').eq(0).addClass('active');
            $content.eq(0).show();

            $control.find('li').each(function () {

                var $item = $(this);

                $item.find('a').on('click', function (e) {
                    e.preventDefault();
                    var id = $(this).attr('href');

                    $control.find('li').removeClass('active');
                    $(this).parent().addClass('active');

                    $content.hide();
                    $(id).show();


                    if (id === '#tab-map' && !$('.event-map').hasClass('loaded')) {
                        setTimeout(eventMap, 300);
                    }
                });
            });
        });
    }

    $.fn.tpSingleEventSlider = function () {

        var $this = $(this);

        $this.find('.event-slider-single').slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            fade: true,
            asNavFor: '.event-carousel-nav'
        });

        $this.find('.event-carousel-nav').slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            asNavFor: '.event-slider-single',
            dots: false,
            focusOnSelect: true,
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 3
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2
                    }
                }
            ]
        });
    }

});

jQuery(function ($) {


    'use strict';

    var updateCountInCart = function (fragments) {
        var $cart = $(fragments['div.widget_shopping_cart_content']);
        var $items = $cart.find('li');

        var quantity = 0;
        $items.each(function () {
            var $qty = $(this).find('.quantity');
            if ($qty.length) {
                $qty.find('span').remove();
                quantity += parseInt($qty.text());
            }
        });

        $('.minicart__count .cart_quantity').text(quantity);
    }

    /**
     * Trigger event so themes can refresh other areas
     */
    $('body').on('added_to_cart', function (e, fragments) {
        updateCountInCart(fragments);
    });

    $('body').on('removed_from_cart', function (e, fragments, cart_hash) {
        updateCountInCart(fragments);
    });

    $('body').on('removed_from_wishlist', function (e) {
        var length = $('.wishlist_table tbody tr').length;
        $('.miniwishlist__heading span').text(length);
    });


    /**
     * Add products to wishlist
     */
    $(document).on('added_to_wishlist', 'body', function () {

        $.ajax({
            url: tp_base_var.ajax_url,
            type: 'POST',
            data: {
                action: 'tp_base_get_mini_wishlist',
            },
            beforeSend: function () {
                $(".miniwishlist__content").addClass('loading');
            },
            success: function (html) {

                var length = $(html).find('li').length;
                if (length) {
                    $('.miniwishlist__heading span').text(length);
                    $('.miniwishlist').removeClass('miniwishlist--empty');
                } else {
                    $('.miniwishlist').addClass('miniwishlist--empty');
                    $('.miniwishlist__heading span').text(0);
                }

                $(".miniwishlist__content").removeClass('loading').html(html);

            }
        });

    });

    /**
     * Remove products from wishlist
     */
    $(document).on('click', '.miniwishlist a.remove', function (e) {

        e.preventDefault();

        var $this = $(this);

        var pid = $this.closest('li').attr('data-id');

        $.ajax({
            type: "POST",
            url: tp_base_var.ajax_url,
            data: {
                action: 'tp_base_remove_from_wishlist',
                remove_from_wishlist: $this.closest('li').attr('data-id'),
                pagination: 'no',
                per_page: -1,
                current_page: 1,
                wishlist_id: $this.parents('ul').data('id'),
                wishlist_token: $this.parents('ul').data('token')
            },
            beforeSend: function () {
                $(".miniwishlist__content").addClass('loading');
            },
            success: function (data) {

                if (data.hasOwnProperty('success') && data.success) {

                    $this.closest('li').fadeIn('normal', function () {
                        var length = $this.closest('ul').find('li').length;
                        if (length == 1) {
                            $('body').trigger('added_to_wishlist');
                        } else {
                            $(this).remove();
                            $('.miniwishlist__heading span').text(length - 1);
                        }

                        $('.post-' + pid + ' .yith-wcwl-add-button').removeClass('hide').addClass('show').show();
                        $('.post-' + pid + ' .yith-wcwl-wishlistexistsbrowse, .post-' + pid + ' .yith-wcwl-wishlistaddedbrowse').removeClass('show').addClass('hide').hide();
                    });
                }
                $(".miniwishlist__content").removeClass('loading');
            }
        });
    });


    if ($('.event').length) {
        $('.event').tpSingleEventSlider();
        $('.event-tab').tpSingleEventTab();
    }

    if ($('.map__canvas').length) {
        $('.map__canvas').tpMap();
    }

    if ($('.testimonial_slider').length) {
        $('.testimonial_slider').tpTestimonialSlider();
    }

});
