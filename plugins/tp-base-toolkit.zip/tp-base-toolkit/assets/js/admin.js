jQuery(function ($) {

    $('.event_datetime input[type="text"]').each(function () {

        var data = $(this).data();

        data.minDate = 0;

        $(this).datetimepicker(data);
    });

    $(document).on('click', '.event_datetime .btn-adddate', function (e) {

        var $this = $(this);
        var $item = $('.date-event-custom.clone');
        var html = '<div class="date-event-custom">' + $item.html() + '</div>';
        var $html = $(html);

        $html.find('input').each(function () {
            var data = $(this).data();
            data.minDate = 0;
            $(this).attr('value', '');
            $(this).datetimepicker(data);
        });

        $this.closest('.datetime-row').before($html);
        event_datetime_refresh_index();
        e.preventDefault();
    });

    $(document).on('click', '.event_datetime .btn-removedate', function (e) {
        var $this = $(this);
        var $row = $this.closest('.date-event-custom');
        if (!$row.hasClass('clone')) {
            $row.remove();
        }
        event_datetime_refresh_index();
        e.preventDefault();
    });

    var event_datetime_refresh_index = function () {
        $('.date-event-custom').each(function (index) {
            $(this).find('input').each(function () {
                var name = $(this).attr('name');

                var regex = new RegExp(/[\d]/g);
                regex = regex.exec(name);

                name = name.replace(regex[0], index);
                $(this).attr('name', name);
            });
        })
    }
});